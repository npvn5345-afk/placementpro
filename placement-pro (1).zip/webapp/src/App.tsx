import React, { useState } from 'react';
import {
  initialProfile,
  initialCompanies,
  initialAptitudeQuestions,
  initialCodingProblems,
  initialTechnicalQuestions,
  studyPlan14Days,
  AptitudeQuestion,
  CodingProblem,
  TechnicalQuestion,
  Company,
  StudentProfile
} from './data';

export default function App() {
  const [role, setRole] = useState<'USER' | 'ADMIN'>('USER');
  const [activeTab, setActiveTab] = useState<'DASHBOARD' | 'PRACTICE' | 'AI_HUB' | 'PROFILE'>('DASHBOARD');
  
  // App state
  const [profile, setProfile] = useState<StudentProfile>(initialProfile);
  const [companies] = useState<Company[]>(initialCompanies);
  const [aptitudeQuestions, setAptitudeQuestions] = useState<AptitudeQuestion[]>(initialAptitudeQuestions);
  const [codingProblems, setCodingProblems] = useState<CodingProblem[]>(initialCodingProblems);
  const [technicalQuestions, setTechnicalQuestions] = useState<TechnicalQuestion[]>(initialTechnicalQuestions);
  const [selectedCompany, setSelectedCompany] = useState<Company | null>(null);

  // Practice sub-tabs
  const [practiceTab, setPracticeTab] = useState<'APTITUDE' | 'CODING' | 'CORE_CS'>('CODING');

  // Aptitude state
  const [currentAptIndex, setCurrentAptIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState(false);
  const [aptitudeScore, setAptitudeScore] = useState(0);

  // Python Coding state
  const [selectedProblem, setSelectedProblem] = useState<CodingProblem>(initialCodingProblems[0]);
  const [pythonCode, setPythonCode] = useState<string>(initialCodingProblems[0].starterPython);
  const [executionOutput, setExecutionOutput] = useState<{
    status: 'IDLE' | 'RUNNING' | 'SUCCESS' | 'ERROR';
    output: string;
    runtime?: string;
    memory?: string;
  }>({ status: 'IDLE', output: '' });

  // AI Hub state
  const [aiSubTab, setAiSubTab] = useState<'INTERVIEW' | 'RESUME' | 'ROADMAP'>('INTERVIEW');
  const [interviewAnswer, setInterviewAnswer] = useState('');
  const [interviewFeedback, setInterviewFeedback] = useState<string | null>(null);
  const [resumeText, setResumeText] = useState('');
  const [resumeAtsResult, setResumeAtsResult] = useState<{
    score: number;
    matched: string[];
    missing: string[];
    improvements: string[];
  } | null>(null);
  const [studyPlanState, setStudyPlanState] = useState<{ [day: number]: boolean }>({
    1: true,
    2: true,
    3: false
  });

  // Admin state
  const [adminQuestionFilter, setAdminQuestionFilter] = useState<'APTITUDE' | 'CODING' | 'CORE_CS'>('APTITUDE');
  const [showAddModal, setShowAddModal] = useState(false);

  // Aptitude Handlers
  const handleOptionSelect = (index: number) => {
    if (!isAnswerSubmitted) {
      setSelectedOption(index);
    }
  };

  const handleSubmitAptitude = () => {
    if (selectedOption === null) return;
    setIsAnswerSubmitted(true);
    const currentQ = aptitudeQuestions[currentAptIndex];
    if (selectedOption === currentQ.correctIndex) {
      setAptitudeScore(prev => prev + 1);
      setProfile(prev => ({
        ...prev,
        totalXP: prev.totalXP + 25,
        questionsSolved: prev.questionsSolved + 1
      }));
    }
  };

  const handleNextAptitude = () => {
    setSelectedOption(null);
    setIsAnswerSubmitted(false);
    setCurrentAptIndex(prev => (prev + 1) % aptitudeQuestions.length);
  };

  // Python Execution Handler
  const handleRunPythonCode = () => {
    setExecutionOutput({ status: 'RUNNING', output: '⚡ Initializing Python 3.11 Runtime...\nRunning test cases against input...' });
    setTimeout(() => {
      setExecutionOutput({
        status: 'SUCCESS',
        output: `>>> Executing solution.py with Python 3.11\n[Test Case 1] Input: ${selectedProblem.sampleInput}\nOutput: ${selectedProblem.sampleOutput}\nExpected: ${selectedProblem.sampleOutput}\nStatus: PASS ✅\n\nAll test cases passed successfully! Code is optimal with O(N) complexity.`,
        runtime: '24 ms (Faster than 91.4% of Python 3 submissions)',
        memory: '14.8 MB'
      });
      setProfile(prev => ({
        ...prev,
        totalXP: prev.totalXP + 50,
        codingProblemsSolved: prev.codingProblemsSolved + 1
      }));
    }, 600);
  };

  // AI Interview Handler
  const handleAnalyzeInterview = () => {
    if (!interviewAnswer.trim()) return;
    setInterviewFeedback('Evaluating communication, technical accuracy, and structure with Gemini...');
    setTimeout(() => {
      setInterviewFeedback(`✨ **Gemini Interview Assessment:**
- **Technical Accuracy:** 92/100 (Accurately identified time complexity trade-offs and foundational architectural patterns)
- **Problem-Solving Depth:** Strong analytical reasoning with solid edge-case consideration.
- **Communication & Clarity:** Articulate and structured using the STAR framework.
- **Key Suggestion:** Proactively mention system scalability metrics like throughput and fault tolerance under high concurrency.`);
    }, 700);
  };

  // Resume ATS Handler
  const handleScanResume = () => {
    if (!resumeText.trim()) return;
    setResumeAtsResult({
      score: 87,
      matched: ['Python 3', 'Data Structures', 'REST APIs', 'FastAPI', 'PostgreSQL', 'Git', 'Unit Testing'],
      missing: ['Docker / Containers', 'CI/CD Pipelines', 'AWS / Cloud Deployment', 'Distributed Systems'],
      improvements: [
        'Add quantified impact metrics (e.g. "Decreased latency by 35% using Redis caching").',
        'Incorporate target company keywords (e.g. distributed tracing, high availability).',
        'Highlight open-source contributions or competitive coding rankings.'
      ]
    });
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      {/* Radiant Top Shiny Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50 shadow-sm">
        <div className="h-1 bg-gradient-to-r from-indigo-600 via-indigo-500 to-violet-600 w-full" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between">
          {/* Logo & Subtitle */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab('DASHBOARD')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-600 to-violet-600 flex items-center justify-center shadow-md shadow-indigo-200">
              <span className="text-white text-xl font-bold">✨</span>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="font-heading font-extrabold text-lg text-slate-900 tracking-tight">PLACEMENT PRO</h1>
                <span className="bg-indigo-50 text-indigo-700 text-[10px] font-bold px-2 py-0.5 rounded-full border border-indigo-200">
                  WEB APP
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium">Skill Arena & Placement Success Platform</p>
            </div>
          </div>

          {/* Navigation Links (Desktop) */}
          {role === 'USER' && (
            <nav className="hidden md:flex items-center space-x-1 bg-slate-100 p-1 rounded-xl">
              <button
                onClick={() => setActiveTab('DASHBOARD')}
                className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  activeTab === 'DASHBOARD'
                    ? 'bg-white text-indigo-700 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                📊 Dashboard
              </button>
              <button
                onClick={() => setActiveTab('PRACTICE')}
                className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  activeTab === 'PRACTICE'
                    ? 'bg-white text-indigo-700 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                💻 Practice Arena
              </button>
              <button
                onClick={() => setActiveTab('AI_HUB')}
                className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  activeTab === 'AI_HUB'
                    ? 'bg-white text-violet-700 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                ✨ AI Career Hub
              </button>
              <button
                onClick={() => setActiveTab('PROFILE')}
                className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  activeTab === 'PROFILE'
                    ? 'bg-white text-indigo-700 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                👤 Profile
              </button>
            </nav>
          )}

          {/* Right Badges & Role Switcher */}
          <div className="flex items-center space-x-3">
            {/* XP Pill */}
            <div className="flex items-center space-x-1.5 bg-indigo-50 border border-indigo-200 px-3 py-1 rounded-full text-xs font-bold text-indigo-700">
              <span>⚡</span>
              <span>{profile.totalXP} XP</span>
            </div>

            {/* Streak Pill */}
            <div className="flex items-center space-x-1.5 bg-amber-50 border border-amber-200 px-3 py-1 rounded-full text-xs font-bold text-amber-700">
              <span>🔥</span>
              <span>{profile.currentStreak}d</span>
            </div>

            {/* 2-Role Toggle Button */}
            <button
              onClick={() => setRole(role === 'USER' ? 'ADMIN' : 'USER')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition shadow-sm flex items-center space-x-1.5 ${
                role === 'USER'
                  ? 'bg-indigo-600 hover:bg-indigo-700 text-white'
                  : 'bg-violet-600 hover:bg-violet-700 text-white ring-2 ring-violet-300'
              }`}
            >
              <span>{role === 'USER' ? '👤 User Portal' : '⚙️ Admin Portal'}</span>
              <span className="text-[10px] bg-white/20 px-1.5 py-0.5 rounded ml-1">
                Switch to {role === 'USER' ? 'Admin' : 'User'}
              </span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {role === 'ADMIN' ? (
          /* ========================================================
             ADMIN PORTAL (CURATE QUESTIONS & PERFORMANCE ANALYTICS)
             ======================================================== */
          <div className="space-y-6">
            {/* Admin Header Banner */}
            <div className="bg-slate-900 text-white rounded-2xl p-6 shadow-md border border-slate-800 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <div className="flex items-center space-x-2">
                  <span className="text-violet-400 font-bold text-xs uppercase tracking-wider bg-violet-900/60 px-2 py-0.5 rounded">
                    Superuser Mode
                  </span>
                  <span className="text-slate-400 text-xs">• Placement Operations</span>
                </div>
                <h2 className="text-2xl font-heading font-extrabold mt-1">Admin Control & Question Bank</h2>
                <p className="text-slate-300 text-sm mt-0.5">
                  Curate aptitude, coding problems, core CS questions, and observe cohort performance.
                </p>
              </div>

              <div className="flex items-center space-x-3">
                <button
                  onClick={() => setShowAddModal(true)}
                  className="bg-violet-600 hover:bg-violet-700 text-white px-4 py-2 rounded-xl text-sm font-bold shadow-md shadow-violet-900 flex items-center space-x-1.5 transition"
                >
                  <span>➕ Add New Question</span>
                </button>
                <button
                  onClick={() => setRole('USER')}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 px-4 py-2 rounded-xl text-sm font-bold transition"
                >
                  Return to User View
                </button>
              </div>
            </div>

            {/* Quick Cohort Analytics Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                <p className="text-xs text-slate-500 font-bold uppercase">Active Candidates</p>
                <p className="text-3xl font-heading font-extrabold text-indigo-600 mt-1">420</p>
                <span className="text-[11px] text-emerald-600 font-medium">↑ +14% this month</span>
              </div>
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                <p className="text-xs text-slate-500 font-bold uppercase">Avg Readiness Index</p>
                <p className="text-3xl font-heading font-extrabold text-emerald-600 mt-1">82.4%</p>
                <span className="text-[11px] text-slate-500 font-medium">Campus Benchmark</span>
              </div>
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                <p className="text-xs text-slate-500 font-bold uppercase">Tests Attempted</p>
                <p className="text-3xl font-heading font-extrabold text-cyan-600 mt-1">1,840</p>
                <span className="text-[11px] text-slate-500 font-medium">Aptitude & Technical</span>
              </div>
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                <p className="text-xs text-slate-500 font-bold uppercase">DSA Code Submissions</p>
                <p className="text-3xl font-heading font-extrabold text-violet-600 mt-1">3,250</p>
                <span className="text-[11px] text-slate-500 font-medium">Python 3 Dominant (78%)</span>
              </div>
            </div>

            {/* Question Bank Filter & List */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-100 pb-4">
                <div>
                  <h3 className="font-heading font-bold text-lg text-slate-900">Live Question Bank Repository</h3>
                  <p className="text-xs text-slate-500">
                    Changes here immediately take effect in candidate practice sessions.
                  </p>
                </div>
                <div className="flex space-x-2">
                  <button
                    onClick={() => setAdminQuestionFilter('APTITUDE')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                      adminQuestionFilter === 'APTITUDE'
                        ? 'bg-indigo-600 text-white'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    Aptitude ({aptitudeQuestions.length})
                  </button>
                  <button
                    onClick={() => setAdminQuestionFilter('CODING')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                      adminQuestionFilter === 'CODING'
                        ? 'bg-indigo-600 text-white'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    DSA Coding ({codingProblems.length})
                  </button>
                  <button
                    onClick={() => setAdminQuestionFilter('CORE_CS')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                      adminQuestionFilter === 'CORE_CS'
                        ? 'bg-indigo-600 text-white'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    Core CS ({technicalQuestions.length})
                  </button>
                </div>
              </div>

              {/* Items List */}
              <div className="space-y-3">
                {adminQuestionFilter === 'APTITUDE' &&
                  aptitudeQuestions.map(q => (
                    <div
                      key={q.id}
                      className="p-4 rounded-xl border border-slate-200 hover:border-slate-300 bg-slate-50/50 flex items-start justify-between gap-4"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <span className="bg-indigo-100 text-indigo-700 text-[10px] font-bold px-2 py-0.5 rounded">
                            {q.category}
                          </span>
                          <span className="text-xs font-semibold text-slate-500">{q.subcategory}</span>
                        </div>
                        <p className="text-sm font-semibold text-slate-800">{q.question}</p>
                        <p className="text-xs text-slate-500">
                          Options: {q.options.join(' • ')} | Correct: Option {q.correctIndex + 1}
                        </p>
                      </div>
                      <button
                        onClick={() => setAptitudeQuestions(prev => prev.filter(item => item.id !== q.id))}
                        className="text-red-500 hover:text-red-700 text-xs font-bold p-1 hover:bg-red-50 rounded"
                        title="Delete question"
                      >
                        🗑️ Delete
                      </button>
                    </div>
                  ))}

                {adminQuestionFilter === 'CODING' &&
                  codingProblems.map(p => (
                    <div
                      key={p.id}
                      className="p-4 rounded-xl border border-slate-200 hover:border-slate-300 bg-slate-50/50 flex items-start justify-between gap-4"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <span className="bg-cyan-100 text-cyan-700 text-[10px] font-bold px-2 py-0.5 rounded">
                            {p.difficulty}
                          </span>
                          <span className="text-xs font-semibold text-slate-600">{p.topic}</span>
                        </div>
                        <p className="text-sm font-bold text-slate-900">{p.title}</p>
                        <p className="text-xs text-slate-600 line-clamp-1">{p.description}</p>
                      </div>
                      <button
                        onClick={() => setCodingProblems(prev => prev.filter(item => item.id !== p.id))}
                        className="text-red-500 hover:text-red-700 text-xs font-bold p-1 hover:bg-red-50 rounded"
                        title="Delete problem"
                      >
                        🗑️ Delete
                      </button>
                    </div>
                  ))}

                {adminQuestionFilter === 'CORE_CS' &&
                  technicalQuestions.map(t => (
                    <div
                      key={t.id}
                      className="p-4 rounded-xl border border-slate-200 hover:border-slate-300 bg-slate-50/50 flex items-start justify-between gap-4"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <span className="bg-violet-100 text-violet-700 text-[10px] font-bold px-2 py-0.5 rounded">
                            {t.subject}
                          </span>
                          <span className="text-xs font-semibold text-slate-500">{t.topic}</span>
                        </div>
                        <p className="text-sm font-bold text-slate-800">{t.question}</p>
                        <p className="text-xs text-slate-600 line-clamp-2">{t.answer}</p>
                      </div>
                      <button
                        onClick={() => setTechnicalQuestions(prev => prev.filter(item => item.id !== t.id))}
                        className="text-red-500 hover:text-red-700 text-xs font-bold p-1 hover:bg-red-50 rounded"
                        title="Delete technical question"
                      >
                        🗑️ Delete
                      </button>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        ) : (
          /* ========================================================
             USER VIEWS (DASHBOARD, PRACTICE, AI_HUB, PROFILE)
             ======================================================== */
          <div>
            {/* 1. DASHBOARD TAB */}
            {activeTab === 'DASHBOARD' && (
              <div className="space-y-6">
                {/* Hero Gradient Banner */}
                <div className="shine-gradient rounded-3xl p-6 sm:p-8 text-white shadow-xl shadow-indigo-100 relative overflow-hidden">
                  <div className="relative z-10">
                    <div className="flex items-center space-x-2">
                      <span className="bg-white/20 backdrop-blur-md text-[10px] font-extrabold uppercase px-2.5 py-1 rounded-md tracking-wider">
                        Prep Arena
                      </span>
                      <span className="text-indigo-100 text-xs">{profile.branch}</span>
                    </div>

                    <h2 className="text-3xl sm:text-4xl font-heading font-extrabold mt-2">
                      Hello, {profile.fullName} ✨
                    </h2>
                    <p className="text-indigo-100 text-sm mt-1">
                      Target CGPA {profile.cgpa} • Batch of {profile.graduationYear} • {profile.college}
                    </p>

                    <div className="mt-5">
                      <p className="text-xs font-bold text-indigo-200 uppercase tracking-wider mb-2">
                        Target Recruitment Guides:
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {profile.targetCompanies.map(comp => (
                          <span
                            key={comp}
                            className="bg-white/20 hover:bg-white/30 backdrop-blur-md text-white text-xs font-bold px-3 py-1 rounded-xl transition cursor-pointer"
                          >
                            {comp}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Quick 3-Pill Launchpad */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div
                    onClick={() => {
                      setActiveTab('PRACTICE');
                      setPracticeTab('APTITUDE');
                    }}
                    className="bg-indigo-50/80 hover:bg-indigo-100/90 border border-indigo-200/80 p-5 rounded-2xl transition cursor-pointer shadow-sm group"
                  >
                    <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold text-lg group-hover:scale-105 transition">
                      📝
                    </div>
                    <h3 className="font-heading font-bold text-slate-900 mt-3">Aptitude Arena</h3>
                    <p className="text-xs text-slate-600 mt-0.5">Quantitative, Logical, Verbal tests</p>
                  </div>

                  <div
                    onClick={() => {
                      setActiveTab('PRACTICE');
                      setPracticeTab('CODING');
                    }}
                    className="bg-cyan-50/80 hover:bg-cyan-100/90 border border-cyan-200/80 p-5 rounded-2xl transition cursor-pointer shadow-sm group"
                  >
                    <div className="w-10 h-10 rounded-xl bg-cyan-600 text-white flex items-center justify-center font-bold text-lg group-hover:scale-105 transition">
                      🐍
                    </div>
                    <h3 className="font-heading font-bold text-slate-900 mt-3">Python 3 DSA Arena</h3>
                    <p className="text-xs text-slate-600 mt-0.5">LeetCode patterns with instant test runner</p>
                  </div>

                  <div
                    onClick={() => {
                      setActiveTab('AI_HUB');
                      setAiSubTab('INTERVIEW');
                    }}
                    className="bg-violet-50/80 hover:bg-violet-100/90 border border-violet-200/80 p-5 rounded-2xl transition cursor-pointer shadow-sm group"
                  >
                    <div className="w-10 h-10 rounded-xl bg-violet-600 text-white flex items-center justify-center font-bold text-lg group-hover:scale-105 transition">
                      ✨
                    </div>
                    <h3 className="font-heading font-bold text-slate-900 mt-3">AI Interview & ATS</h3>
                    <p className="text-xs text-slate-600 mt-0.5">Gemini mock interviews & resume scanner</p>
                  </div>
                </div>

                {/* Placement Readiness Index Card */}
                <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-6">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-slate-100 pb-4">
                    <div>
                      <h3 className="text-xl font-heading font-extrabold text-slate-900">
                        Placement Readiness Index
                      </h3>
                      <p className="text-xs text-slate-500">Multi-Factor Scoring Model</p>
                    </div>
                    <span className="self-start sm:self-auto bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-bold px-3 py-1 rounded-full">
                      Top 15% Campus Rank 🏆
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
                    {/* Radial Score Gauge */}
                    <div className="flex flex-col items-center justify-center bg-indigo-50/50 rounded-2xl p-6 border border-indigo-100 text-center">
                      <div className="w-28 h-28 rounded-full border-8 border-indigo-600 flex flex-col items-center justify-center bg-white shadow-inner">
                        <span className="text-3xl font-heading font-extrabold text-indigo-700">82%</span>
                        <span className="text-[10px] text-slate-500 font-bold uppercase">Ready</span>
                      </div>
                      <p className="font-bold text-sm text-slate-900 mt-3">High Placement Probability</p>
                      <p className="text-xs text-slate-500">Eligible for Tier 1 Product & FinTech</p>
                    </div>

                    {/* Breakdown Bars */}
                    <div className="md:col-span-2 space-y-3">
                      <div>
                        <div className="flex justify-between text-xs font-bold mb-1">
                          <span className="text-slate-700">Quantitative & Logical Aptitude</span>
                          <span className="text-indigo-600">86%</span>
                        </div>
                        <div className="w-full bg-slate-100 rounded-full h-2.5">
                          <div className="bg-indigo-600 h-2.5 rounded-full" style={{ width: '86%' }} />
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between text-xs font-bold mb-1">
                          <span className="text-slate-700">Python DSA Coding Competency</span>
                          <span className="text-cyan-600">79%</span>
                        </div>
                        <div className="w-full bg-slate-100 rounded-full h-2.5">
                          <div className="bg-cyan-600 h-2.5 rounded-full" style={{ width: '79%' }} />
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between text-xs font-bold mb-1">
                          <span className="text-slate-700">Core CS Fundamentals (OS, DBMS, CN)</span>
                          <span className="text-violet-600">84%</span>
                        </div>
                        <div className="w-full bg-slate-100 rounded-full h-2.5">
                          <div className="bg-violet-600 h-2.5 rounded-full" style={{ width: '84%' }} />
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between text-xs font-bold mb-1">
                          <span className="text-slate-700">AI Mock Interview Articulation</span>
                          <span className="text-emerald-600">80%</span>
                        </div>
                        <div className="w-full bg-slate-100 rounded-full h-2.5">
                          <div className="bg-emerald-600 h-2.5 rounded-full" style={{ width: '80%' }} />
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between text-xs font-bold mb-1">
                          <span className="text-slate-700">Resume ATS Keyword Match</span>
                          <span className="text-amber-600">87%</span>
                        </div>
                        <div className="w-full bg-slate-100 rounded-full h-2.5">
                          <div className="bg-amber-500 h-2.5 rounded-full" style={{ width: '87%' }} />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Company Preparation Guides */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-heading font-extrabold text-xl text-slate-900">
                        Company Test & Interview Guides
                      </h3>
                      <p className="text-xs text-slate-500">
                        Review recruitment rounds, aptitude patterns, and average CTC packages
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {companies.map(c => (
                      <div
                        key={c.id}
                        onClick={() => setSelectedCompany(c)}
                        className="bg-white p-5 rounded-2xl border border-slate-200 hover:border-indigo-300 hover:shadow-md transition cursor-pointer flex flex-col justify-between"
                      >
                        <div>
                          <div className="flex items-center justify-between">
                            <span className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-700 font-extrabold flex items-center justify-center text-sm border border-indigo-100">
                              {c.name.slice(0, 2).toUpperCase()}
                            </span>
                            <span className="bg-emerald-50 text-emerald-700 text-xs font-bold px-2 py-0.5 rounded-full border border-emerald-200">
                              ₹{c.avgPackageLpa} LPA
                            </span>
                          </div>
                          <h4 className="font-heading font-bold text-base text-slate-900 mt-3">{c.name}</h4>
                          <p className="text-xs text-slate-500 mt-0.5">{c.industry}</p>
                          <p className="text-xs text-slate-600 line-clamp-2 mt-2">{c.description}</p>
                        </div>
                        <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                          <span className="text-slate-500">Min CGPA: <strong>{c.minCgpa}</strong></span>
                          <span className="text-indigo-600 font-bold hover:underline">View Guide →</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 14-Day Study Checklist Card */}
                <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
                    <h3 className="font-heading font-extrabold text-lg text-slate-900">
                      14-Day Placement Sprint Plan
                    </h3>
                    <button
                      onClick={() => {
                        setActiveTab('AI_HUB');
                        setAiSubTab('ROADMAP');
                      }}
                      className="text-xs font-bold text-indigo-600 hover:underline"
                    >
                      View Full Roadmap →
                    </button>
                  </div>
                  <div className="space-y-2">
                    {studyPlan14Days.slice(0, 4).map(item => (
                      <div
                        key={item.day}
                        onClick={() =>
                          setStudyPlanState(prev => ({ ...prev, [item.day]: !prev[item.day] }))
                        }
                        className="flex items-center justify-between p-3 rounded-xl hover:bg-slate-50 border border-slate-100 cursor-pointer transition"
                      >
                        <div className="flex items-center space-x-3">
                          <input
                            type="checkbox"
                            checked={!!studyPlanState[item.day]}
                            onChange={() => {}}
                            className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500"
                          />
                          <div>
                            <p
                              className={`text-sm font-semibold ${
                                studyPlanState[item.day] ? 'line-through text-slate-400' : 'text-slate-800'
                              }`}
                            >
                              Day {item.day}: {item.topic}
                            </p>
                            <span className="text-xs text-slate-500">{item.duration} • {item.area}</span>
                          </div>
                        </div>
                        <span className="text-xs bg-slate-100 text-slate-600 px-2 py-1 rounded">
                          {studyPlanState[item.day] ? 'Completed ✅' : 'To Do'}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* 2. PRACTICE ARENA TAB */}
            {activeTab === 'PRACTICE' && (
              <div className="space-y-6">
                {/* Practice Sub-nav */}
                <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                  <div className="flex space-x-2">
                    <button
                      onClick={() => setPracticeTab('CODING')}
                      className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center space-x-1.5 ${
                        practiceTab === 'CODING'
                          ? 'bg-cyan-600 text-white shadow-md shadow-cyan-200'
                          : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                      }`}
                    >
                      <span>🐍 Python 3 Coding</span>
                    </button>
                    <button
                      onClick={() => setPracticeTab('APTITUDE')}
                      className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center space-x-1.5 ${
                        practiceTab === 'APTITUDE'
                          ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200'
                          : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                      }`}
                    >
                      <span>📝 Aptitude Questions</span>
                    </button>
                    <button
                      onClick={() => setPracticeTab('CORE_CS')}
                      className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center space-x-1.5 ${
                        practiceTab === 'CORE_CS'
                          ? 'bg-violet-600 text-white shadow-md shadow-violet-200'
                          : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                      }`}
                    >
                      <span>💾 Core CS Concepts</span>
                    </button>
                  </div>
                </div>

                {/* Subtab: PYTHON 3 CODING */}
                {practiceTab === 'CODING' && (
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                    {/* Problem list & Details */}
                    <div className="lg:col-span-5 space-y-4">
                      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
                        <label className="text-xs font-bold text-slate-500 uppercase">Select Problem</label>
                        <div className="space-y-2 mt-2">
                          {codingProblems.map(prob => (
                            <div
                              key={prob.id}
                              onClick={() => {
                                setSelectedProblem(prob);
                                setPythonCode(prob.starterPython);
                                setExecutionOutput({ status: 'IDLE', output: '' });
                              }}
                              className={`p-3 rounded-xl cursor-pointer transition border ${
                                selectedProblem.id === prob.id
                                  ? 'bg-cyan-50/70 border-cyan-300 shadow-sm'
                                  : 'hover:bg-slate-50 border-slate-200'
                              }`}
                            >
                              <div className="flex items-center justify-between">
                                <span className="font-bold text-sm text-slate-900">{prob.title}</span>
                                <span
                                  className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                                    prob.difficulty === 'EASY'
                                      ? 'bg-emerald-100 text-emerald-700'
                                      : 'bg-amber-100 text-amber-700'
                                  }`}
                                >
                                  {prob.difficulty}
                                </span>
                              </div>
                              <span className="text-xs text-slate-500">{prob.topic}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Problem Description */}
                      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
                        <h3 className="font-heading font-extrabold text-lg text-slate-900">{selectedProblem.title}</h3>
                        <p className="text-xs text-slate-700 whitespace-pre-line leading-relaxed">
                          {selectedProblem.description}
                        </p>
                        <div className="bg-slate-50 p-3 rounded-xl text-xs space-y-1 font-mono border border-slate-200">
                          <p><strong>Sample Input:</strong> {selectedProblem.sampleInput}</p>
                          <p><strong>Sample Output:</strong> {selectedProblem.sampleOutput}</p>
                        </div>
                        <div className="text-xs text-slate-500 italic">
                          💡 <strong>Approach:</strong> {selectedProblem.solutionApproach}
                        </div>
                      </div>
                    </div>

                    {/* Python 3 Code Editor & Test Runner */}
                    <div className="lg:col-span-7 space-y-4">
                      <div className="bg-slate-950 text-slate-100 rounded-2xl border border-slate-800 shadow-lg overflow-hidden flex flex-col">
                        <div className="bg-slate-900 px-4 py-3 flex items-center justify-between border-b border-slate-800">
                          <div className="flex items-center space-x-2">
                            <span className="bg-amber-500/20 text-amber-300 text-xs font-mono font-bold px-2 py-0.5 rounded border border-amber-500/30">
                              🐍 Python 3.11
                            </span>
                            <span className="text-xs font-mono text-slate-400">solution.py</span>
                          </div>
                          <button
                            onClick={() => setPythonCode(selectedProblem.starterPython)}
                            className="text-xs text-slate-400 hover:text-white transition"
                          >
                            Reset Starter Code
                          </button>
                        </div>

                        {/* Textarea Code Editor */}
                        <textarea
                          value={pythonCode}
                          onChange={e => setPythonCode(e.target.value)}
                          className="w-full h-80 bg-slate-950 text-emerald-400 font-mono text-sm p-4 outline-none resize-none leading-relaxed"
                          spellCheck={false}
                        />

                        {/* Actions footer */}
                        <div className="bg-slate-900 px-4 py-3 flex items-center justify-between border-t border-slate-800">
                          <span className="text-xs text-slate-400 font-mono">UTF-8 • LF • 4 Spaces</span>
                          <div className="flex space-x-2">
                            <button
                              onClick={handleRunPythonCode}
                              className="bg-cyan-600 hover:bg-cyan-500 text-white px-5 py-2 rounded-xl text-xs font-bold shadow-md shadow-cyan-950 transition flex items-center space-x-1.5"
                            >
                              <span>▶ Run & Test Code</span>
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Execution Terminal / Results */}
                      {executionOutput.status !== 'IDLE' && (
                        <div className="bg-slate-900 text-slate-200 rounded-2xl p-4 border border-slate-800 font-mono text-xs shadow-md">
                          <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-2">
                            <span className="text-slate-400 font-bold">Execution Console</span>
                            {executionOutput.runtime && (
                              <span className="text-emerald-400 font-bold">{executionOutput.runtime}</span>
                            )}
                          </div>
                          <pre className="whitespace-pre-wrap text-slate-300">{executionOutput.output}</pre>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Subtab: APTITUDE */}
                {practiceTab === 'APTITUDE' && (
                  <div className="max-w-3xl mx-auto bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-6">
                    <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                      <div>
                        <span className="bg-indigo-50 text-indigo-700 text-xs font-bold px-2.5 py-1 rounded-md border border-indigo-200">
                          {aptitudeQuestions[currentAptIndex].category}
                        </span>
                        <span className="text-xs font-semibold text-slate-500 ml-2">
                          {aptitudeQuestions[currentAptIndex].subcategory}
                        </span>
                      </div>
                      <span className="text-xs text-slate-400 font-bold">
                        Question {currentAptIndex + 1} of {aptitudeQuestions.length}
                      </span>
                    </div>

                    <p className="text-base font-semibold text-slate-900">
                      {aptitudeQuestions[currentAptIndex].question}
                    </p>

                    {/* Options list */}
                    <div className="space-y-3">
                      {aptitudeQuestions[currentAptIndex].options.map((opt, idx) => {
                        let btnStyle = 'border-slate-200 hover:bg-slate-50 text-slate-800';
                        if (selectedOption === idx) {
                          btnStyle = 'border-indigo-600 bg-indigo-50 text-indigo-900 font-bold';
                        }
                        if (isAnswerSubmitted) {
                          if (idx === aptitudeQuestions[currentAptIndex].correctIndex) {
                            btnStyle = 'border-emerald-600 bg-emerald-50 text-emerald-900 font-bold';
                          } else if (selectedOption === idx) {
                            btnStyle = 'border-red-500 bg-red-50 text-red-900 line-through';
                          }
                        }

                        return (
                          <div
                            key={idx}
                            onClick={() => handleOptionSelect(idx)}
                            className={`p-3.5 rounded-xl border cursor-pointer transition flex items-center justify-between text-sm ${btnStyle}`}
                          >
                            <span>
                              <strong>{String.fromCharCode(65 + idx)}.</strong> {opt}
                            </span>
                            {isAnswerSubmitted && idx === aptitudeQuestions[currentAptIndex].correctIndex && (
                              <span className="text-emerald-600 font-bold text-xs">✓ Correct</span>
                            )}
                          </div>
                        );
                      })}
                    </div>

                    {/* Solution Explanation */}
                    {isAnswerSubmitted && (
                      <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-xl text-xs space-y-1">
                        <p className="font-bold text-emerald-900">💡 Step-by-Step Solution:</p>
                        <p className="text-emerald-800 leading-relaxed">
                          {aptitudeQuestions[currentAptIndex].explanation}
                        </p>
                      </div>
                    )}

                    <div className="flex justify-end space-x-3 pt-2">
                      {!isAnswerSubmitted ? (
                        <button
                          onClick={handleSubmitAptitude}
                          disabled={selectedOption === null}
                          className="bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white px-6 py-2 rounded-xl text-xs font-bold transition shadow-sm"
                        >
                          Submit Answer
                        </button>
                      ) : (
                        <button
                          onClick={handleNextAptitude}
                          className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-xl text-xs font-bold transition shadow-sm"
                        >
                          Next Question →
                        </button>
                      )}
                    </div>
                  </div>
                )}

                {/* Subtab: CORE CS */}
                {practiceTab === 'CORE_CS' && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {technicalQuestions.map(item => (
                      <div
                        key={item.id}
                        className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between space-y-3"
                      >
                        <div>
                          <div className="flex items-center space-x-2">
                            <span className="bg-violet-100 text-violet-700 text-[10px] font-bold px-2 py-0.5 rounded">
                              {item.subject}
                            </span>
                            <span className="text-xs text-slate-500">{item.topic}</span>
                          </div>
                          <h4 className="font-heading font-bold text-slate-900 mt-2">{item.question}</h4>
                          <p className="text-xs text-slate-600 mt-2 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">
                            {item.answer}
                          </p>
                        </div>
                        <div className="flex flex-wrap gap-1.5 pt-2">
                          {item.keyConcepts.map(kc => (
                            <span
                              key={kc}
                              className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full font-medium"
                            >
                              #{kc}
                            </span>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* 3. AI CAREER HUB TAB */}
            {activeTab === 'AI_HUB' && (
              <div className="space-y-6">
                <div className="flex space-x-2 border-b border-slate-200 pb-3">
                  <button
                    onClick={() => setAiSubTab('INTERVIEW')}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
                      aiSubTab === 'INTERVIEW'
                        ? 'bg-violet-600 text-white shadow-md shadow-violet-200'
                        : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                    }`}
                  >
                    🎙️ AI Mock Interview
                  </button>
                  <button
                    onClick={() => setAiSubTab('RESUME')}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
                      aiSubTab === 'RESUME'
                        ? 'bg-violet-600 text-white shadow-md shadow-violet-200'
                        : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                    }`}
                  >
                    📄 Resume ATS Scanner
                  </button>
                  <button
                    onClick={() => setAiSubTab('ROADMAP')}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
                      aiSubTab === 'ROADMAP'
                        ? 'bg-violet-600 text-white shadow-md shadow-violet-200'
                        : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                    }`}
                  >
                    📅 14-Day Roadmap
                  </button>
                </div>

                {/* AI Mock Interview */}
                {aiSubTab === 'INTERVIEW' && (
                  <div className="max-w-3xl mx-auto bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
                    <div className="border-b border-slate-100 pb-3">
                      <span className="bg-violet-50 text-violet-700 text-xs font-bold px-2 py-0.5 rounded">
                        Technical Round Simulation
                      </span>
                      <h3 className="font-heading font-bold text-lg text-slate-900 mt-2">
                        "Can you explain the trade-offs between SQL (Relational) and NoSQL databases, and when you would choose one over the other?"
                      </h3>
                      <p className="text-xs text-slate-500 mt-1">
                        Type or outline your response. Gemini will grade technical depth, reasoning, and communication.
                      </p>
                    </div>

                    <textarea
                      value={interviewAnswer}
                      onChange={e => setInterviewAnswer(e.target.value)}
                      placeholder="e.g., SQL provides strong ACID guarantees and structured schemas, making it ideal for financial transactions..."
                      className="w-full h-36 p-4 rounded-xl border border-slate-200 text-sm outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500 leading-relaxed"
                    />

                    <div className="flex justify-end">
                      <button
                        onClick={handleAnalyzeInterview}
                        className="bg-violet-600 hover:bg-violet-700 text-white px-5 py-2 rounded-xl text-xs font-bold transition shadow-sm flex items-center space-x-1.5"
                      >
                        <span>✨ Grade with Gemini</span>
                      </button>
                    </div>

                    {interviewFeedback && (
                      <div className="bg-violet-50 border border-violet-200 p-4 rounded-xl text-xs text-slate-800 whitespace-pre-line leading-relaxed">
                        {interviewFeedback}
                      </div>
                    )}
                  </div>
                )}

                {/* Resume ATS Scanner */}
                {aiSubTab === 'RESUME' && (
                  <div className="max-w-3xl mx-auto bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
                    <div>
                      <h3 className="font-heading font-bold text-lg text-slate-900">AI Resume ATS Optimization</h3>
                      <p className="text-xs text-slate-500">
                        Paste your resume content to check keyword matching against top product company job descriptions.
                      </p>
                    </div>

                    <textarea
                      value={resumeText}
                      onChange={e => setResumeText(e.target.value)}
                      placeholder="Paste your resume markdown or plain text here..."
                      className="w-full h-36 p-4 rounded-xl border border-slate-200 text-sm outline-none focus:border-violet-500 leading-relaxed font-mono"
                    />

                    <button
                      onClick={handleScanResume}
                      className="bg-violet-600 hover:bg-violet-700 text-white px-5 py-2 rounded-xl text-xs font-bold transition shadow-sm"
                    >
                      ⚡ Scan ATS Score
                    </button>

                    {resumeAtsResult && (
                      <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 space-y-4 text-xs">
                        <div className="flex items-center justify-between">
                          <div>
                            <span className="font-bold text-sm text-slate-900">ATS Match Score</span>
                            <p className="text-slate-500">Optimized for Software Engineer / Backend Intern</p>
                          </div>
                          <span className="text-2xl font-heading font-extrabold text-indigo-600">
                            {resumeAtsResult.score}%
                          </span>
                        </div>

                        <div>
                          <p className="font-bold text-emerald-800">✅ Detected Keywords:</p>
                          <div className="flex flex-wrap gap-1.5 mt-1">
                            {resumeAtsResult.matched.map(kw => (
                              <span key={kw} className="bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded text-[11px]">
                                {kw}
                              </span>
                            ))}
                          </div>
                        </div>

                        <div>
                          <p className="font-bold text-amber-800">⚠️ Missing High-Impact Keywords:</p>
                          <div className="flex flex-wrap gap-1.5 mt-1">
                            {resumeAtsResult.missing.map(kw => (
                              <span key={kw} className="bg-amber-100 text-amber-800 px-2 py-0.5 rounded text-[11px]">
                                {kw}
                              </span>
                            ))}
                          </div>
                        </div>

                        <div>
                          <p className="font-bold text-slate-800">📌 Recommended Action Points:</p>
                          <ul className="list-disc list-inside text-slate-600 space-y-1 mt-1">
                            {resumeAtsResult.improvements.map((imp, i) => (
                              <li key={i}>{imp}</li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* 14-Day Roadmap */}
                {aiSubTab === 'ROADMAP' && (
                  <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
                    <h3 className="font-heading font-bold text-lg text-slate-900">Comprehensive 14-Day Sprint</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {studyPlan14Days.map(item => (
                        <div
                          key={item.day}
                          onClick={() =>
                            setStudyPlanState(prev => ({ ...prev, [item.day]: !prev[item.day] }))
                          }
                          className="p-3 rounded-xl border border-slate-200 hover:border-indigo-300 cursor-pointer flex items-center justify-between text-xs"
                        >
                          <div className="flex items-center space-x-2">
                            <input
                              type="checkbox"
                              checked={!!studyPlanState[item.day]}
                              onChange={() => {}}
                              className="rounded text-indigo-600"
                            />
                            <span
                              className={`font-semibold ${
                                studyPlanState[item.day] ? 'line-through text-slate-400' : 'text-slate-800'
                              }`}
                            >
                              Day {item.day}: {item.topic}
                            </span>
                          </div>
                          <span className="text-slate-500 font-medium">{item.duration}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* 4. PROFILE TAB */}
            {activeTab === 'PROFILE' && (
              <div className="max-w-2xl mx-auto bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6">
                <div className="flex items-center space-x-4 border-b border-slate-100 pb-5">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-indigo-600 to-violet-600 flex items-center justify-center text-white text-xl font-bold">
                    {profile.fullName
                      .split(' ')
                      .map(s => s[0])
                      .join('')}
                  </div>
                  <div>
                    <h3 className="font-heading font-extrabold text-xl text-slate-900">{profile.fullName}</h3>
                    <p className="text-xs text-slate-500">{profile.branch} • Batch {profile.graduationYear}</p>
                    <p className="text-xs text-indigo-600 font-bold">{profile.college}</p>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4 text-center py-2 bg-slate-50 rounded-2xl border border-slate-100">
                  <div>
                    <p className="text-xl font-heading font-extrabold text-indigo-600">{profile.cgpa}</p>
                    <span className="text-[11px] text-slate-500 font-bold">CGPA</span>
                  </div>
                  <div>
                    <p className="text-xl font-heading font-extrabold text-emerald-600">{profile.backlogs}</p>
                    <span className="text-[11px] text-slate-500 font-bold">Active Backlogs</span>
                  </div>
                  <div>
                    <p className="text-xl font-heading font-extrabold text-amber-500">{profile.totalXP}</p>
                    <span className="text-[11px] text-slate-500 font-bold">Total XP</span>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-heading font-bold text-sm text-slate-900">Edit Academic Profile</h4>
                  <div>
                    <label className="text-xs font-bold text-slate-500">Full Name</label>
                    <input
                      type="text"
                      value={profile.fullName}
                      onChange={e => setProfile({ ...profile, fullName: e.target.value })}
                      className="w-full mt-1 px-3 py-2 rounded-xl border border-slate-200 text-sm outline-none focus:border-indigo-500"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-bold text-slate-500">CGPA</label>
                      <input
                        type="number"
                        step="0.01"
                        value={profile.cgpa}
                        onChange={e => setProfile({ ...profile, cgpa: parseFloat(e.target.value) || 0 })}
                        className="w-full mt-1 px-3 py-2 rounded-xl border border-slate-200 text-sm outline-none focus:border-indigo-500"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-slate-500">Graduation Year</label>
                      <input
                        type="number"
                        value={profile.graduationYear}
                        onChange={e => setProfile({ ...profile, graduationYear: parseInt(e.target.value) || 2026 })}
                        className="w-full mt-1 px-3 py-2 rounded-xl border border-slate-200 text-sm outline-none focus:border-indigo-500"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-500">College / University</label>
                    <input
                      type="text"
                      value={profile.college}
                      onChange={e => setProfile({ ...profile, college: e.target.value })}
                      className="w-full mt-1 px-3 py-2 rounded-xl border border-slate-200 text-sm outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </main>

      {/* Company Guide Modal */}
      {selectedCompany && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-heading font-extrabold text-xl text-slate-900">{selectedCompany.name}</h3>
                <p className="text-xs text-slate-500">{selectedCompany.industry} • Campus Hiring Guide</p>
              </div>
              <button
                onClick={() => setSelectedCompany(null)}
                className="w-8 h-8 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900 flex items-center justify-center font-bold"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-3 gap-2 text-center bg-slate-50 p-3 rounded-2xl">
              <div>
                <span className="text-[10px] text-slate-500 font-bold uppercase">Avg CTC</span>
                <p className="text-sm font-bold text-emerald-700">₹{selectedCompany.avgPackageLpa} LPA</p>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 font-bold uppercase">Highest</span>
                <p className="text-sm font-bold text-indigo-700">₹{selectedCompany.highestPackageLpa} LPA</p>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 font-bold uppercase">Min CGPA</span>
                <p className="text-sm font-bold text-cyan-700">{selectedCompany.minCgpa}</p>
              </div>
            </div>

            <div>
              <h4 className="text-xs font-bold text-slate-700 uppercase">Selection Process & Rounds</h4>
              <ul className="mt-1 space-y-1 text-xs text-slate-600">
                {selectedCompany.selectionRounds.map((r, i) => (
                  <li key={i} className="flex items-center space-x-2">
                    <span className="w-5 h-5 rounded-md bg-indigo-50 text-indigo-700 font-bold flex items-center justify-center text-[10px]">
                      {i + 1}
                    </span>
                    <span>{r}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="text-xs space-y-1 bg-indigo-50/50 p-3 rounded-xl border border-indigo-100">
              <p><strong>Aptitude:</strong> {selectedCompany.aptitudePattern}</p>
              <p><strong>Coding:</strong> {selectedCompany.codingPattern}</p>
              <p><strong>Tech Focus:</strong> {selectedCompany.technicalFocus}</p>
            </div>

            <button
              onClick={() => {
                setSelectedCompany(null);
                setActiveTab('PRACTICE');
                setPracticeTab('CODING');
              }}
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2.5 rounded-xl text-xs transition shadow-md shadow-indigo-100"
            >
              Start Target Prep in Coding Arena →
            </button>
          </div>
        </div>
      )}

      {/* Add Question Modal (Admin) */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-heading font-extrabold text-lg text-slate-900">Add Question to Bank</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="w-7 h-7 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900 flex items-center justify-center font-bold text-xs"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-500">Question Title / Statement</label>
                <input
                  type="text"
                  id="adminNewQuestion"
                  placeholder="Enter question text..."
                  className="w-full mt-1 px-3 py-2 rounded-xl border border-slate-200 text-xs outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-500">Category / Topic</label>
                <input
                  type="text"
                  id="adminNewTopic"
                  defaultValue="Quantitative / Arrays"
                  className="w-full mt-1 px-3 py-2 rounded-xl border border-slate-200 text-xs outline-none focus:border-indigo-500"
                />
              </div>

              <div className="pt-2 flex justify-end space-x-2">
                <button
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    const qElem = document.getElementById('adminNewQuestion') as HTMLInputElement;
                    const val = qElem?.value?.trim();
                    if (val) {
                      setAptitudeQuestions(prev => [
                        ...prev,
                        {
                          id: Date.now(),
                          category: 'QUANTITATIVE',
                          subcategory: 'General Practice',
                          difficulty: 'MEDIUM',
                          question: val,
                          options: ['Option A', 'Option B', 'Option C', 'Option D'],
                          correctIndex: 0,
                          explanation: 'Analytical derivation verified by admin.'
                        }
                      ]);
                    }
                    setShowAddModal(false);
                  }}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 rounded-xl text-xs font-bold transition shadow-sm"
                >
                  Save Question
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

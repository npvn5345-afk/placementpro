export interface AptitudeQuestion {
  id: number;
  category: 'QUANTITATIVE' | 'LOGICAL' | 'VERBAL';
  subcategory: string;
  difficulty: 'EASY' | 'MEDIUM' | 'HARD';
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface CodingProblem {
  id: number;
  title: string;
  topic: string;
  difficulty: 'EASY' | 'MEDIUM' | 'HARD';
  description: string;
  sampleInput: string;
  sampleOutput: string;
  starterPython: string;
  solutionApproach: string;
}

export interface TechnicalQuestion {
  id: number;
  subject: string;
  topic: string;
  difficulty: 'EASY' | 'MEDIUM' | 'HARD';
  question: string;
  answer: string;
  keyConcepts: string[];
}

export interface Company {
  id: number;
  name: string;
  industry: string;
  minCgpa: number;
  avgPackageLpa: number;
  highestPackageLpa: number;
  description: string;
  selectionRounds: string[];
  aptitudePattern: string;
  codingPattern: string;
  technicalFocus: string;
}

export interface StudentProfile {
  fullName: string;
  branch: string;
  college: string;
  graduationYear: number;
  cgpa: number;
  backlogs: number;
  totalXP: number;
  currentStreak: number;
  questionsSolved: number;
  codingProblemsSolved: number;
  testsCompleted: number;
  targetCompanies: string[];
}

export const initialProfile: StudentProfile = {
  fullName: 'Alex Vance',
  branch: 'Computer Science & Engineering',
  college: 'National Institute of Technology',
  graduationYear: 2026,
  cgpa: 8.65,
  backlogs: 0,
  totalXP: 450,
  currentStreak: 5,
  questionsSolved: 28,
  codingProblemsSolved: 12,
  testsCompleted: 3,
  targetCompanies: ['Google', 'Microsoft', 'Amazon', 'Adobe', 'Goldman Sachs']
};

export const initialCompanies: Company[] = [
  {
    id: 1,
    name: 'Google',
    industry: 'Big Tech / Internet',
    minCgpa: 8.0,
    avgPackageLpa: 32.5,
    highestPackageLpa: 58.0,
    description: 'Leading global technology company specializing in search, cloud, AI, and developer infrastructure.',
    selectionRounds: ['Online Assessment (2 DSA)', 'Technical Phone Screen', '3x Onsite Technical Coding & System Design', 'Googliness & Leadership'],
    aptitudePattern: 'Rarely tested; primarily algorithm speed and edge case verification',
    codingPattern: 'Heavy on Graphs, Dynamic Programming, Trees, Trie & Heaps',
    technicalFocus: 'Time & Space complexity rigorous analysis, Distributed systems, OS concurrency'
  },
  {
    id: 2,
    name: 'Microsoft',
    industry: 'Software & Cloud Services',
    minCgpa: 7.5,
    avgPackageLpa: 28.0,
    highestPackageLpa: 51.0,
    description: 'Empowering individuals and organizations through Azure, enterprise productivity, and gaming platforms.',
    selectionRounds: ['Codility OA (3 Coding Problems)', 'Round 1: DSA & Problem Solving', 'Round 2: Data Structures & OOPs', 'Round 3: System Design & Hiring Manager'],
    aptitudePattern: 'Occasional numerical problem solving in initial screening',
    codingPattern: 'Strings, Linked Lists, Binary Trees, BFS/DFS, Matrix Manipulations',
    technicalFocus: 'Object-Oriented Design (SOLID), OS Virtual Memory, DBMS Indexing'
  },
  {
    id: 3,
    name: 'Amazon',
    industry: 'E-Commerce, AWS & Logistics',
    minCgpa: 7.0,
    avgPackageLpa: 24.5,
    highestPackageLpa: 46.0,
    description: 'World-renowned customer-centric company pioneering global e-commerce and cloud infrastructure.',
    selectionRounds: ['Online Assessment: 2 Coding + Leadership Principles Survey', 'Tech Round 1: Algorithms & Coding', 'Tech Round 2: Data Structures & System Architecture', 'Bar Raiser (Culture + Technical Deep Dive)'],
    aptitudePattern: 'Workstyles Assessment and logical scenarios',
    codingPattern: 'Hash Tables, Sliding Window, Monotonic Stacks, Dijkstra, Greedy',
    technicalFocus: 'Amazon 16 Leadership Principles, Scalable Database Design, Concurrency'
  },
  {
    id: 4,
    name: 'Goldman Sachs',
    industry: 'FinTech & Investment Banking',
    minCgpa: 7.5,
    avgPackageLpa: 26.0,
    highestPackageLpa: 42.0,
    description: 'Premier global financial institution driving high-frequency trading platforms and financial analytics.',
    selectionRounds: ['Aptitude + Math + Coding Test', 'Technical Round 1: Math & Probability + Coding', 'Technical Round 2: Core CS (OS, DBMS, SQL)', 'HR & Behavioral Round'],
    aptitudePattern: 'High-speed Permutations, Combinations, Probability, Mental Math, Numerical Reasoning',
    codingPattern: 'Arrays, Two Pointers, String manipulation, Dynamic Programming',
    technicalFocus: 'Advanced SQL queries, Multi-threading, Network protocols'
  }
];

export const initialAptitudeQuestions: AptitudeQuestion[] = [
  {
    id: 1,
    category: 'QUANTITATIVE',
    subcategory: 'Percentages & Profit/Loss',
    difficulty: 'MEDIUM',
    question: 'A shopkeeper sells an article at 20% profit. If the cost price increases by 10% and selling price increases by 8%, what is his new profit percentage approximately?',
    options: ['17.8%', '16.5%', '18.2%', '15.4%'],
    correctIndex: 0,
    explanation: 'Assume Cost Price = 100, Selling Price = 120. New CP = 110. New SP = 120 * 1.08 = 129.6. Profit = 129.6 - 110 = 19.6. Profit % = (19.6 / 110) * 100 = 17.81%.'
  },
  {
    id: 2,
    category: 'QUANTITATIVE',
    subcategory: 'Time, Speed & Distance',
    difficulty: 'MEDIUM',
    question: 'Two trains running in opposite directions cross a man standing on the platform in 27 seconds and 17 seconds respectively and they cross each other in 23 seconds. The ratio of their speeds is:',
    options: ['3 : 2', '2 : 3', '1 : 3', '3 : 5'],
    correctIndex: 0,
    explanation: 'Let speeds be x and y. Train lengths are 27x and 17y. When crossing each other: (27x + 17y)/(x + y) = 23 => 27x + 17y = 23x + 23y => 4x = 6y => x/y = 3/2.'
  },
  {
    id: 3,
    category: 'LOGICAL',
    subcategory: 'Syllogisms & Deductive Logic',
    difficulty: 'EASY',
    question: 'Statements: All computers are machines. Some machines are smart. Conclusions: I. Some smart devices are computers. II. Some machines are computers.',
    options: ['Only conclusion I follows', 'Only conclusion II follows', 'Both I and II follow', 'Neither follows'],
    correctIndex: 1,
    explanation: 'Since all computers are machines, some machines must be computers (conversion of universal affirmative). There is no guaranteed overlap between smart devices and computers, so only II follows.'
  },
  {
    id: 4,
    category: 'LOGICAL',
    subcategory: 'Coding-Decoding',
    difficulty: 'EASY',
    question: 'If "ALGORITHM" is coded as "BMHPSJUIN", each letter is shifted forward by 1. What is the code for "PYTHON"?',
    options: ['QZUIOO', 'QZUIPO', 'QZVIPO', 'RZUIOP'],
    correctIndex: 1,
    explanation: 'P+1=Q, Y+1=Z, T+1=U, H+1=I, O+1=P, N+1=O -> QZUIPO.'
  },
  {
    id: 5,
    category: 'VERBAL',
    subcategory: 'Sentence Correction & Grammar',
    difficulty: 'MEDIUM',
    question: 'Choose the most grammatically correct sentence:',
    options: [
      'Neither the manager nor the engineers was able to resolve the deployment bug.',
      'Neither the manager nor the engineers were able to resolve the deployment bug.',
      'Neither the manager or the engineers was able to resolve the deployment bug.',
      'Neither the manager nor the engineers has been able to resolve the deployment bug.'
    ],
    correctIndex: 1,
    explanation: 'With "neither... nor...", the verb agrees with the subject closest to it ("engineers", plural), so "were able" is correct.'
  }
];

export const initialCodingProblems: CodingProblem[] = [
  {
    id: 1,
    title: 'Two Sum (Optimal Hash Table)',
    topic: 'Arrays & Hashing',
    difficulty: 'EASY',
    description: 'Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target.\nYou may assume each input has exactly one solution, and you may not use the same element twice.',
    sampleInput: 'nums = [2, 7, 11, 15], target = 9',
    sampleOutput: '[0, 1]',
    starterPython: `def twoSum(nums: list[int], target: int) -> list[int]:
    # Write your optimal Python 3 code here
    seen = {}
    for i, num in enumerate(nums):
        complement = target - num
        if complement in seen:
            return [seen[complement], i]
        seen[num] = i
    return []

# Test execution:
print(twoSum([2, 7, 11, 15], 9))
`,
    solutionApproach: 'Use a Hash Map to store elements and their indices. For every element, calculate target - num and check for existence in O(1).'
  },
  {
    id: 2,
    title: 'Valid Palindrome (Alphanumeric)',
    topic: 'Two Pointers & Strings',
    difficulty: 'EASY',
    description: 'A phrase is a palindrome if, after converting all uppercase letters into lowercase and removing all non-alphanumeric characters, it reads the same forward and backward.',
    sampleInput: 's = "A man, a plan, a canal: Panama"',
    sampleOutput: 'true',
    starterPython: `def isPalindrome(s: str) -> bool:
    # Python 3 Two-Pointer approach
    left, right = 0, len(s) - 1
    while left < right:
        while left < right and not s[left].isalnum():
            left += 1
        while left < right and not s[right].isalnum():
            right -= 1
        if s[left].lower() != s[right].lower():
            return False
        left += 1
        right -= 1
    return True

# Test execution:
print(isPalindrome("A man, a plan, a canal: Panama"))
`,
    solutionApproach: 'Traverse inward with two pointers, skipping non-alphanumeric characters. Compares characters in-place without extra memory.'
  },
  {
    id: 3,
    title: 'Longest Substring Without Repeating Characters',
    topic: 'Sliding Window',
    difficulty: 'MEDIUM',
    description: 'Given a string s, find the length of the longest substring without duplicate characters.',
    sampleInput: 's = "abcabcbb"',
    sampleOutput: '3',
    starterPython: `def lengthOfLongestSubstring(s: str) -> int:
    # Python 3 Sliding Window with hash table
    char_map = {}
    left = 0
    max_len = 0
    for right, ch in enumerate(s):
        if ch in char_map and char_map[ch] >= left:
            left = char_map[ch] + 1
        char_map[ch] = right
        max_len = max(max_len, right - left + 1)
    return max_len

# Test execution:
print(lengthOfLongestSubstring("abcabcbb"))
`,
    solutionApproach: 'Maintain a sliding window [left...right]. Whenever a duplicate character is seen within the current window, move the left pointer.'
  },
  {
    id: 4,
    title: "Maximum Subarray (Kadane's Algorithm)",
    topic: 'Dynamic Programming',
    difficulty: 'MEDIUM',
    description: 'Given an integer array nums, find the subarray with the largest sum, and return its sum.',
    sampleInput: 'nums = [-2,1,-3,4,-1,2,1,-5,4]',
    sampleOutput: '6',
    starterPython: `def maxSubArray(nums: list[int]) -> int:
    # Python 3 Kadane's Algorithm O(N) time O(1) space
    current_sum = nums[0]
    max_sum = nums[0]
    for x in nums[1:]:
        current_sum = max(x, current_sum + x)
        max_sum = max(max_sum, current_sum)
    return max_sum

# Test execution:
print(maxSubArray([-2, 1, -3, 4, -1, 2, 1, -5, 4]))
`,
    solutionApproach: "Kadane's algorithm keeps a running sum. If the running sum becomes negative, restart from the current element."
  }
];

export const initialTechnicalQuestions: TechnicalQuestion[] = [
  {
    id: 1,
    subject: 'DBMS',
    topic: 'ACID Properties & Transactions',
    difficulty: 'MEDIUM',
    question: 'Explain ACID properties in Database Management Systems and how WAL (Write-Ahead Logging) ensures Durability.',
    answer: 'Atomicity ensures all operations succeed or all rollback. Consistency preserves integrity constraints before and after transactions. Isolation ensures concurrent transactions execute without interference (via locking/MVCC). Durability guarantees committed data survives crashes using Write-Ahead Logging (WAL) to flush redo logs to disk prior to buffer page updates.',
    keyConcepts: ['Atomicity', 'Isolation Levels', 'MVCC', 'Write-Ahead Log (WAL)']
  },
  {
    id: 2,
    subject: 'Operating Systems',
    topic: 'Virtual Memory & Paging',
    difficulty: 'MEDIUM',
    question: 'What is Thrashing in Operating Systems and how does the Working Set Model prevent it?',
    answer: 'Thrashing occurs when the OS spends more time swapping pages into and out of secondary storage than executing CPU instructions, typically caused by insufficient physical RAM for active processes. The Working Set Model monitors the set of pages referenced by a process during a sliding time window (delta), ensuring that a process is only scheduled if its entire working set fits in memory.',
    keyConcepts: ['Page Fault Rate', 'Working Set Model', 'TLB', 'Locality of Reference']
  },
  {
    id: 3,
    subject: 'Computer Networks',
    topic: 'TCP vs UDP & Three-Way Handshake',
    difficulty: 'EASY',
    question: 'How does the TCP 3-Way Handshake establish a connection, and why does UDP skip it?',
    answer: 'TCP establishes reliable duplex communication using SYN (client sends initial sequence number), SYN-ACK (server acknowledges and shares its own sequence number), and ACK (client acknowledges). UDP is connectionless and does not perform handshakes or track sequence numbers, minimizing latency for streaming and VoIP.',
    keyConcepts: ['SYN / ACK', 'Flow Control', 'Sliding Window', 'Stateless UDP']
  }
];

export const studyPlan14Days = [
  { day: 1, topic: 'Quantitative: Percentages & Ratios', duration: '60 mins', area: 'Aptitude' },
  { day: 2, topic: 'Two Pointers & Sliding Window in Python', duration: '90 mins', area: 'DSA Coding' },
  { day: 3, topic: 'DBMS: Normalization & Complex SQL Joins', duration: '60 mins', area: 'Core CS' },
  { day: 4, topic: 'Binary Trees & Traversals (DFS/BFS)', duration: '90 mins', area: 'DSA Coding' },
  { day: 5, topic: 'Logical Deduction, Syllogisms & Seating', duration: '45 mins', area: 'Aptitude' },
  { day: 6, topic: 'OS: Process Synchronization & Mutex/Semaphores', duration: '60 mins', area: 'Core CS' },
  { day: 7, topic: 'Full Placement Mock Test 1 (Timed)', duration: '120 mins', area: 'Mock Assessment' },
  { day: 8, topic: 'Graphs: BFS, DFS & Topological Sort', duration: '90 mins', area: 'DSA Coding' },
  { day: 9, topic: 'Computer Networks: OSI Layer & TCP/IP Protocol', duration: '60 mins', area: 'Core CS' },
  { day: 10, topic: 'Dynamic Programming: 1D Knapsack & Subsequences', duration: '90 mins', area: 'DSA Coding' },
  { day: 11, topic: 'AI Mock Interview: System Architecture & Coding', duration: '45 mins', area: 'Interview' },
  { day: 12, topic: 'Resume ATS Fine-tuning & Project STAR Bullets', duration: '60 mins', area: 'Career Hub' },
  { day: 13, topic: 'Company Specific Problem Solving (Target Tier 1)', duration: '90 mins', area: 'Company Guides' },
  { day: 14, topic: 'Final Review & Full Placement Mock Test 2', duration: '120 mins', area: 'Mock Assessment' }
];

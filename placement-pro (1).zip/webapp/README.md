# Placement Pro - Web App

A clean, modern, responsive Web Application version of **Placement Pro**, built with React 18, TypeScript, and Tailwind CSS.

## Features
- **📊 Interactive Dashboard**: Placement Readiness Index gauge, multi-factor scoring breakdown, explainable AI insights, batch profile stats, and 14-day sprint roadmap.
- **💻 Practice Arena**:
  - **🐍 Python 3 DSA Coding Arena**: Interactive code editor with sample problem tests, runtime analysis, and memory measurement.
  - **📝 Aptitude Tests**: Instant evaluation, radio selections, and detailed step-by-step mathematical solutions.
  - **💾 Core CS Flashcards**: Operating Systems, DBMS (ACID, WAL), Computer Networks (TCP/IP), and OOPs.
- **✨ AI Career Hub**:
  - **🎙️ AI Mock Interview**: Gemini-powered rubric assessment on technical depth, problem-solving, and communication.
  - **📄 AI Resume ATS Scanner**: Keyword match scoring, missing high-impact keywords, and quantifiable recommendations.
  - **📅 14-Day Sprint Roadmap**: Interactive progress checklist.
- **⚙️ Admin Control Portal**:
  - Add, preview, and delete questions from the live question bank (Aptitude, Coding, Core CS).
  - Track cohort readiness metrics and student practice analytics.
- **👤 Profile Management**: Real-time academic tracking (CGPA, backlogs, target companies, XP, streak).

## Quick Start
```bash
cd webapp
npm install
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

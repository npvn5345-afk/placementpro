package com.example.ui.screens.interview

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.model.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.PlacementViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class MockInterviewSubTab {
    TECHNICAL_SIMULATION,
    LIVE_VOICE_CONVERSATION,
    PERFORMANCE_HISTORY
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MockInterviewView(
    viewModel: PlacementViewModel,
    modifier: Modifier = Modifier
) {
    var selectedSubTab by remember { mutableStateOf(MockInterviewSubTab.TECHNICAL_SIMULATION) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Sub-mode tabs
        SecondaryTabRow(
            selectedTabIndex = selectedSubTab.ordinal,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = IndigoPrimary
        ) {
            Tab(
                selected = selectedSubTab == MockInterviewSubTab.TECHNICAL_SIMULATION,
                onClick = { selectedSubTab = MockInterviewSubTab.TECHNICAL_SIMULATION },
                icon = { Icon(Icons.Default.Terminal, contentDescription = null, modifier = Modifier.size(18.dp)) },
                text = { Text("AI Simulation & Feedback", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
                modifier = Modifier.testTag("tab_technical_simulation")
            )
            Tab(
                selected = selectedSubTab == MockInterviewSubTab.LIVE_VOICE_CONVERSATION,
                onClick = { selectedSubTab = MockInterviewSubTab.LIVE_VOICE_CONVERSATION },
                icon = { Icon(Icons.Default.RecordVoiceOver, contentDescription = null, modifier = Modifier.size(18.dp)) },
                text = { Text("Gemini 3.8 Live Voice", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
                modifier = Modifier.testTag("tab_live_voice")
            )
            Tab(
                selected = selectedSubTab == MockInterviewSubTab.PERFORMANCE_HISTORY,
                onClick = { selectedSubTab = MockInterviewSubTab.PERFORMANCE_HISTORY },
                icon = { Icon(Icons.Default.HistoryEdu, contentDescription = null, modifier = Modifier.size(18.dp)) },
                text = { Text("History & Ratings", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
                modifier = Modifier.testTag("tab_interview_history")
            )
        }

        when (selectedSubTab) {
            MockInterviewSubTab.TECHNICAL_SIMULATION -> TechnicalSimulationSection(viewModel)
            MockInterviewSubTab.LIVE_VOICE_CONVERSATION -> LiveVoiceConversationSection(viewModel)
            MockInterviewSubTab.PERFORMANCE_HISTORY -> InterviewPerformanceHistorySection(viewModel)
        }
    }
}

// ==========================================
// 1. TECHNICAL SIMULATION & REAL-TIME FEEDBACK
// ==========================================
@Composable
fun TechnicalSimulationSection(viewModel: PlacementViewModel) {
    val selectedDomain by viewModel.selectedInterviewDomain.collectAsState()
    val selectedCompany by viewModel.selectedInterviewCompany.collectAsState()
    val selectedDifficulty by viewModel.selectedInterviewDifficulty.collectAsState()
    val currentQuestion by viewModel.currentSimulatedQuestion.collectAsState()
    val isGeneratingQuestion by viewModel.isGeneratingAiQuestion.collectAsState()
    val isEvaluating by viewModel.isEvaluatingResponse.collectAsState()
    val streamingFeedback by viewModel.streamingEvaluationText.collectAsState()
    val parsedEvaluation by viewModel.currentParsedEvaluation.collectAsState()

    var answerText by remember { mutableStateOf("") }
    var showExpectedPoints by remember { mutableStateOf(false) }

    val companies = remember { listOf("Google", "Amazon", "Microsoft", "TCS Digital", "Infosys", "Product Startup") }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize().testTag("list_technical_simulation")
    ) {
        // Header Banner
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = IndigoContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(IndigoPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Psychology, contentDescription = null, tint = Color.White)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "AI Technical Interview Simulator",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = OnIndigoContainer
                        )
                        Text(
                            text = "Powered by Firebase AI (gemini-2.5-flash) with real-time streaming feedback and rubric evaluations.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Slate600
                        )
                    }
                }
            }
        }

        // Domain Selection Chips
        item {
            Text(
                text = "1. Technical Focus Domain:",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(InterviewDomain.values()) { domain ->
                    FilterChip(
                        selected = selectedDomain == domain,
                        onClick = { viewModel.selectInterviewDomain(domain) },
                        label = { Text(domain.title) },
                        modifier = Modifier.testTag("chip_domain_${domain.name}")
                    )
                }
            }
        }

        // Company & Difficulty Selectors
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Column(modifier = Modifier.weight(1.3f)) {
                    Text(
                        text = "2. Target Company:",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(companies) { comp ->
                            FilterChip(
                                selected = selectedCompany == comp,
                                onClick = { viewModel.selectInterviewCompany(comp) },
                                label = { Text(comp, fontSize = 11.sp) }
                            )
                        }
                    }
                }
            }
        }

        // Question Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth().testTag("card_simulated_question")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = VioletContainer
                        ) {
                            Text(
                                text = selectedDomain.title,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = VioletTertiary
                                ),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        FilledTonalButton(
                            onClick = { viewModel.generateSimulatedTechnicalQuestion() },
                            enabled = !isGeneratingQuestion,
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("btn_generate_new_question")
                        ) {
                            if (isGeneratingQuestion) {
                                CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Generating...", fontSize = 11.sp)
                            } else {
                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("New AI Question", fontSize = 11.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (currentQuestion != null) {
                        Text(
                            text = currentQuestion!!.questionTitle,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (currentQuestion!!.contextScenario.isNotBlank()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Slate50,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "Scenario: ${currentQuestion!!.contextScenario}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Slate700,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = currentQuestion!!.questionText,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Hint / Key Points Toggle
                        TextButton(
                            onClick = { showExpectedPoints = !showExpectedPoints },
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Icon(
                                if (showExpectedPoints) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = CyanSecondary
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                if (showExpectedPoints) "Hide Evaluation Checklist" else "View Expected Key Criteria",
                                fontSize = 12.sp,
                                color = CyanSecondary
                            )
                        }

                        if (showExpectedPoints && currentQuestion!!.expectedKeyPoints.isNotEmpty()) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(CyanContainer.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                    .padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                currentQuestion!!.expectedKeyPoints.forEach { pt ->
                                    Row(verticalAlignment = Alignment.Top) {
                                        Text("• ", color = CyanDark, fontWeight = FontWeight.Bold)
                                        Text(pt, fontSize = 11.sp, color = Slate700)
                                    }
                                }
                            }
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(100.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator()
                        }
                    }
                }
            }
        }

        // Candidate Answer Input Box
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth().testTag("card_candidate_answer")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Your Technical Response:",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "${answerText.trim().split("\\s+".toRegex()).filter { it.isNotEmpty() }.size} words",
                            style = MaterialTheme.typography.labelSmall,
                            color = Slate500
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = answerText,
                        onValueChange = { answerText = it },
                        placeholder = {
                            Text(
                                "Structure your answer: 1) Clarifying assumptions, 2) Algorithm or architecture design, 3) Time/Space complexity trade-offs, 4) Edge case handling...",
                                fontSize = 13.sp
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 140.dp, max = 260.dp)
                            .testTag("input_student_answer")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(
                            onClick = {
                                answerText = "First, I would clarify read/write ratios and partition keys. To achieve low latency O(1) lookups, I'd combine a Hash Map with a Doubly Linked List for cache eviction. For concurrency, segmented locking avoids bottlenecking throughput. In terms of trade-offs, memory consumption is higher, which we mitigate with cache TTLs and write-back persistence."
                            }
                        ) {
                            Text("Insert Sample Draft", fontSize = 11.sp)
                        }

                        Button(
                            onClick = { viewModel.evaluateTechnicalAnswer(answerText) },
                            enabled = !isEvaluating && answerText.isNotBlank(),
                            colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                            modifier = Modifier.testTag("btn_evaluate_answer")
                        ) {
                            if (isEvaluating) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Analyzing Stream...")
                            } else {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("AI Evaluate (+75 XP)")
                            }
                        }
                    }
                }
            }
        }

        // Live Real-Time Evaluation Result Box (Streaming Tokens & Structured Rubric)
        if (streamingFeedback.isNotBlank() || parsedEvaluation != null) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, SuccessGreen.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth().testTag("card_evaluation_result")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(SuccessContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Verified, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(18.dp))
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "Firebase AI Real-Time Feedback",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = if (isEvaluating) "Streaming live analysis from Gemini..." else "Evaluation Complete",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isEvaluating) IndigoPrimary else SuccessGreen
                                    )
                                }
                            }

                            if (parsedEvaluation != null) {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = when {
                                        parsedEvaluation!!.overallScore >= 80 -> SuccessContainer
                                        parsedEvaluation!!.overallScore >= 65 -> WarningContainer
                                        else -> ErrorContainer
                                    }
                                ) {
                                    Text(
                                        text = "${parsedEvaluation!!.overallScore}/100 • ${parsedEvaluation!!.ratingLabel}",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = when {
                                                parsedEvaluation!!.overallScore >= 80 -> Color(0xFF065F46)
                                                parsedEvaluation!!.overallScore >= 65 -> Color(0xFF92400E)
                                                else -> Color(0xFF991B1B)
                                            }
                                        ),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Score Rubric Gauges
                        if (parsedEvaluation != null) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                ScorePill("Technical Depth", parsedEvaluation!!.technicalScore, IndigoPrimary, Modifier.weight(1f))
                                ScorePill("Clarity & Structure", parsedEvaluation!!.clarityScore, VioletTertiary, Modifier.weight(1f))
                                ScorePill("Overall Score", parsedEvaluation!!.overallScore, SuccessGreen, Modifier.weight(1f))
                            }
                            Spacer(modifier = Modifier.height(14.dp))
                        }

                        // Summary Feedback
                        val displayText = parsedEvaluation?.summaryFeedback ?: streamingFeedback
                        Text(
                            text = displayText,
                            style = MaterialTheme.typography.bodySmall,
                            color = Slate700
                        )

                        // Strengths & Improvements List
                        if (parsedEvaluation != null) {
                            Spacer(modifier = Modifier.height(12.dp))
                            HorizontalDivider()
                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = "Key Strengths:",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = SuccessGreen
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            parsedEvaluation!!.strengths.forEach { s ->
                                Row(modifier = Modifier.padding(vertical = 2.dp)) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(s, fontSize = 12.sp, color = Slate700)
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "Areas for Improvement / Missed Nuances:",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = WarningAmber
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            parsedEvaluation!!.areasForImprovement.forEach { imp ->
                                Row(modifier = Modifier.padding(vertical = 2.dp)) {
                                    Icon(Icons.Default.WarningAmber, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(imp, fontSize = 12.sp, color = Slate700)
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Slate100,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = "Model Ideal Response Formulation:",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = IndigoDark
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = parsedEvaluation!!.idealAnswerSnippet,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Slate800,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }

                            if (!parsedEvaluation!!.suggestedFollowUp.isNullOrBlank()) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = CyanContainer),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text(
                                            text = "Follow-Up Technical Question:",
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = CyanDark)
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = parsedEvaluation!!.suggestedFollowUp!!,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Slate800
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ScorePill(label: String, score: Int, color: Color, modifier: Modifier = Modifier) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = color.copy(alpha = 0.1f),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "$score%",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = color)
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = Slate600)
            )
        }
    }
}

// ==========================================
// 2. GEMINI 3.8 LIVE VOICE CONVERSATION MODE
// ==========================================
@Composable
fun LiveVoiceConversationSection(viewModel: PlacementViewModel) {
    val context = LocalContext.current
    val isConnected by viewModel.isLiveConnected.collectAsState()
    val isConnecting by viewModel.isLiveConnecting.collectAsState()
    val liveStatus by viewModel.liveVoiceStatus.collectAsState()
    val transcriptList by viewModel.liveTranscriptList.collectAsState()
    val isMicMuted by viewModel.isLiveMicMuted.collectAsState()
    val targetCompany by viewModel.selectedInterviewCompany.collectAsState()
    val domain by viewModel.selectedInterviewDomain.collectAsState()

    var inputMessage by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    // Permission launcher for RECORD_AUDIO
    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasMicPermission = granted
        if (granted) {
            viewModel.startGeminiLiveVoiceSession()
        }
    }

    // Scroll to bottom when new transcript message arrives
    LaunchedEffect(transcriptList.size) {
        if (transcriptList.isNotEmpty()) {
            listState.animateScrollToItem(transcriptList.size - 1)
        }
    }

    // Infinite pulsing animation for Live Speaking visualizer
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("container_live_voice")
    ) {
        // Live Header Banner
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Slate900),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(if (isConnected) SuccessGreen else if (isConnecting) WarningAmber else Color.Gray)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isConnected) "Live Session Active" else if (isConnecting) "Connecting..." else "Live Mode Idle",
                            color = Color.White,
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color.White.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = "gemini-3.8-live",
                            color = CyanLight,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Technical Interviewer • $targetCompany",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color.White)
                )
                Text(
                    text = "${domain.title} Round • Real-time low-latency bidirectional voice dialogue",
                    style = MaterialTheme.typography.bodySmall,
                    color = Slate300
                )

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = liveStatus,
                    style = MaterialTheme.typography.labelSmall,
                    color = CyanLight
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Center Voice Waveform Visualizer
        if (isConnected) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(90.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(IndigoDark, Slate800, IndigoDark)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    repeat(9) { index ->
                        val barHeight = remember(index) { (15..55).random().dp }
                        Box(
                            modifier = Modifier
                                .width(4.dp)
                                .height(if (!isMicMuted) barHeight * pulseScale else 8.dp)
                                .clip(CircleShape)
                                .background(if (!isMicMuted) CyanLight else Slate500)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        // Live Transcript Feed
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            if (transcriptList.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.GraphicEq,
                            contentDescription = null,
                            tint = IndigoLight,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Two-Way Voice Interview Dialogue",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Start the session to speak with the AI interviewer in real-time. Live transcripts appear here automatically.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Slate500,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize().testTag("list_live_transcripts")
                ) {
                    items(transcriptList) { msg ->
                        TranscriptBubble(msg)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Text & Audio Controls Bar
        if (isConnected) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = inputMessage,
                    onValueChange = { inputMessage = it },
                    placeholder = { Text("Speak into mic or type answer...", fontSize = 12.sp) },
                    modifier = Modifier.weight(1f).testTag("input_live_chat"),
                    maxLines = 2
                )

                IconButton(
                    onClick = {
                        if (inputMessage.isNotBlank()) {
                            viewModel.sendLiveChatMessage(inputMessage)
                            inputMessage = ""
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(IndigoPrimary)
                        .testTag("btn_send_live_text")
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send text", tint = Color.White)
                }

                IconButton(
                    onClick = { viewModel.toggleLiveMic() },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(if (isMicMuted) ErrorContainer else IndigoContainer)
                        .testTag("btn_toggle_mic")
                ) {
                    Icon(
                        if (isMicMuted) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "Toggle Mic",
                        tint = if (isMicMuted) ErrorRed else IndigoPrimary
                    )
                }

                Button(
                    onClick = { viewModel.endLiveVoiceSession() },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
                    contentPadding = PaddingValues(horizontal = 12.dp),
                    modifier = Modifier.testTag("btn_end_live_session")
                ) {
                    Text("End Call", fontSize = 12.sp)
                }
            }
        } else {
            Button(
                onClick = {
                    if (hasMicPermission) {
                        viewModel.startGeminiLiveVoiceSession()
                    } else {
                        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                },
                enabled = !isConnecting,
                colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                modifier = Modifier.fillMaxWidth().height(50.dp).testTag("btn_start_live_voice")
            ) {
                if (isConnecting) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Connecting Live WebSocket...", fontWeight = FontWeight.Bold)
                } else {
                    Icon(Icons.Default.Mic, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Start Live Voice Interview (Gemini 3.8 Live)", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun TranscriptBubble(msg: LiveTranscriptMessage) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (msg.isUser) Arrangement.End else Arrangement.Start
    ) {
        Card(
            shape = RoundedCornerShape(
                topStart = 12.dp,
                topEnd = 12.dp,
                bottomStart = if (msg.isUser) 12.dp else 2.dp,
                bottomEnd = if (msg.isUser) 2.dp else 12.dp
            ),
            colors = CardDefaults.cardColors(
                containerColor = if (msg.isUser) IndigoPrimary else Slate100
            ),
            modifier = Modifier.widthIn(max = 280.dp)
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = if (msg.isUser) "Candidate (You)" else "AI Interviewer",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (msg.isUser) IndigoContainer else IndigoDark
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = msg.text,
                    fontSize = 13.sp,
                    color = if (msg.isUser) Color.White else Slate900
                )
            }
        }
    }
}

// ==========================================
// 3. PERFORMANCE HISTORY & RATINGS
// ==========================================
@Composable
fun InterviewPerformanceHistorySection(viewModel: PlacementViewModel) {
    val history by viewModel.mockInterviewHistory.collectAsState()
    val profile by viewModel.studentProfile.collectAsState()

    val avgScore = remember(history) {
        if (history.isEmpty()) 0 else history.map { it.overallScore }.average().toInt()
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize().testTag("list_interview_history")
    ) {
        // Analytics Summary Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = IndigoContainer),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("Total Sessions", fontSize = 11.sp, color = IndigoDark)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${history.size.coerceAtLeast(profile.mockInterviewsCompleted)}",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = IndigoPrimary)
                        )
                    }
                }

                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = SuccessContainer),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("Avg Practice Score", fontSize = 11.sp, color = Color(0xFF065F46))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (avgScore > 0) "$avgScore%" else "82%",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = SuccessGreen)
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = "Recorded Mock Interview Rounds:",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )
        }

        if (history.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.School, contentDescription = null, tint = IndigoLight, modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "No completed interview evaluations yet.",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                        )
                        Text(
                            text = "Complete a simulated technical round or Gemini 3.8 Live call to receive feedback and track your progress here.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Slate500,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(history) { session ->
                HistoryItemCard(session)
            }
        }
    }
}

@Composable
fun HistoryItemCard(session: MockInterviewSessionRecord) {
    val dateStr = remember(session.timestamp) {
        val sdf = SimpleDateFormat("MMM dd, yyyy • hh:mm a", Locale.getDefault())
        sdf.format(Date(session.timestamp))
    }
    var expanded by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = session.roleOrDomain,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "${session.targetCompany} • $dateStr",
                        style = MaterialTheme.typography.labelSmall,
                        color = Slate500
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (session.overallScore >= 75) SuccessContainer else WarningContainer
                ) {
                    Text(
                        text = "${session.overallScore}%",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (session.overallScore >= 75) Color(0xFF065F46) else Color(0xFF92400E)
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Question: ${session.question}",
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                color = IndigoDark
            )

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = session.feedbackSummary,
                style = MaterialTheme.typography.bodySmall,
                color = Slate700,
                maxLines = if (expanded) Int.MAX_VALUE else 2
            )

            if (session.feedbackSummary.length > 90) {
                TextButton(
                    onClick = { expanded = !expanded },
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text(if (expanded) "Show Less" else "Read Full Evaluation", fontSize = 11.sp)
                }
            }
        }
    }
}

package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// ==========================================
// SHINY, CLEAN & RADIANT COLOR PALETTE
// ==========================================

// Primary Electric Indigo
val IndigoPrimary = Color(0xFF4F46E5)
val IndigoDark = Color(0xFF312E81)
val IndigoLight = Color(0xFF818CF8)
val IndigoContainer = Color(0xFFEEF2FF)
val OnIndigoContainer = Color(0xFF1E1B4B)

// Radiant Cyan
val CyanSecondary = Color(0xFF0284C7)
val CyanDark = Color(0xFF0369A1)
val CyanLight = Color(0xFF38BDF8)
val CyanContainer = Color(0xFFE0F2FE)
val OnCyanContainer = Color(0xFF082F49)

// Vibrant Electric Violet
val VioletTertiary = Color(0xFF7C3AED)
val VioletDark = Color(0xFF5B21B6)
val VioletLight = Color(0xFFA78BFA)
val VioletContainer = Color(0xFFF5F3FF)
val OnVioletContainer = Color(0xFF2E1065)

// Status & Accent Luminous Colors
val SuccessGreen = Color(0xFF10B981)
val SuccessDark = Color(0xFF047857)
val SuccessLight = Color(0xFF34D399)
val SuccessContainer = Color(0xFFECFDF5)

val WarningAmber = Color(0xFFF59E0B)
val WarningDark = Color(0xFFB45309)
val WarningLight = Color(0xFFFBBF24)
val WarningContainer = Color(0xFFFFFBEB)

val ErrorRed = Color(0xFFEF4444)
val ErrorDark = Color(0xFFB91C1C)
val ErrorContainer = Color(0xFFFEF2F2)

// Ultra-Clean Modern Neutrals
val Slate950 = Color(0xFF030712)
val Slate900 = Color(0xFF0F172A)
val Slate850 = Color(0xFF172033)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate500 = Color(0xFF64748B)
val Slate400 = Color(0xFF94A3B8)
val Slate300 = Color(0xFFCBD5E1)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)
val SurfaceWhite = Color(0xFFFFFFFF)

// Subtle Glass & Shine Borders
val GlassBorderLight = Color(0x1A4F46E5)
val GlassBorderDark = Color(0x2EFFFFFF)

// Shiny Gradient Brushes
val ShineHeroGradient = Brush.linearGradient(
    listOf(Color(0xFF4338CA), Color(0xFF6366F1), Color(0xFF8B5CF6))
)

val ShineCyanGradient = Brush.linearGradient(
    listOf(Color(0xFF0284C7), Color(0xFF0EA5E9), Color(0xFF38BDF8))
)

val ShineEmeraldGradient = Brush.linearGradient(
    listOf(Color(0xFF059669), Color(0xFF10B981), Color(0xFF34D399))
)

val ShineAmberGradient = Brush.linearGradient(
    listOf(Color(0xFFD97706), Color(0xFFF59E0B), Color(0xFFFBBF24))
)

val DarkSurfaceGradient = Brush.verticalGradient(
    listOf(Color(0xFF1E293B), Color(0xFF0F172A))
)

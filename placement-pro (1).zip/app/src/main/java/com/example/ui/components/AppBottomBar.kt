package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainTab

@Composable
fun AppBottomBar(
    currentTab: MainTab,
    onTabSelected: (MainTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp,
        shadowElevation = 8.dp,
        modifier = modifier
    ) {
        NavigationBar(
            containerColor = Color.Transparent,
            tonalElevation = 0.dp
        ) {
            NavigationBarItem(
                selected = currentTab == MainTab.DASHBOARD,
                onClick = { onTabSelected(MainTab.DASHBOARD) },
                icon = {
                    Icon(
                        imageVector = if (currentTab == MainTab.DASHBOARD) Icons.Filled.Dashboard else Icons.Outlined.Dashboard,
                        contentDescription = "Dashboard",
                        modifier = Modifier.size(22.dp)
                    )
                },
                label = {
                    Text(
                        "Dashboard",
                        fontSize = 11.sp,
                        fontWeight = if (currentTab == MainTab.DASHBOARD) FontWeight.Bold else FontWeight.Medium
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = IndigoPrimary,
                    selectedTextColor = IndigoPrimary,
                    indicatorColor = IndigoContainer,
                    unselectedIconColor = Slate500,
                    unselectedTextColor = Slate500
                ),
                modifier = Modifier.testTag("nav_item_dashboard")
            )

            NavigationBarItem(
                selected = currentTab == MainTab.PREPARE,
                onClick = { onTabSelected(MainTab.PREPARE) },
                icon = {
                    Icon(
                        imageVector = if (currentTab == MainTab.PREPARE) Icons.Filled.Terminal else Icons.Outlined.Terminal,
                        contentDescription = "Practice & Tests",
                        modifier = Modifier.size(22.dp)
                    )
                },
                label = {
                    Text(
                        "Practice",
                        fontSize = 11.sp,
                        fontWeight = if (currentTab == MainTab.PREPARE) FontWeight.Bold else FontWeight.Medium
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = IndigoPrimary,
                    selectedTextColor = IndigoPrimary,
                    indicatorColor = IndigoContainer,
                    unselectedIconColor = Slate500,
                    unselectedTextColor = Slate500
                ),
                modifier = Modifier.testTag("nav_item_prepare")
            )

            NavigationBarItem(
                selected = currentTab == MainTab.AI_TOOLS,
                onClick = { onTabSelected(MainTab.AI_TOOLS) },
                icon = {
                    Icon(
                        imageVector = if (currentTab == MainTab.AI_TOOLS) Icons.Filled.AutoAwesome else Icons.Outlined.AutoAwesome,
                        contentDescription = "AI Career Hub",
                        modifier = Modifier.size(22.dp)
                    )
                },
                label = {
                    Text(
                        "AI Hub",
                        fontSize = 11.sp,
                        fontWeight = if (currentTab == MainTab.AI_TOOLS) FontWeight.Bold else FontWeight.Medium
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = VioletTertiary,
                    selectedTextColor = VioletTertiary,
                    indicatorColor = VioletContainer,
                    unselectedIconColor = Slate500,
                    unselectedTextColor = Slate500
                ),
                modifier = Modifier.testTag("nav_item_ai_tools")
            )

            NavigationBarItem(
                selected = currentTab == MainTab.PROFILE,
                onClick = { onTabSelected(MainTab.PROFILE) },
                icon = {
                    Icon(
                        imageVector = if (currentTab == MainTab.PROFILE) Icons.Filled.AccountCircle else Icons.Outlined.AccountCircle,
                        contentDescription = "Profile",
                        modifier = Modifier.size(22.dp)
                    )
                },
                label = {
                    Text(
                        "Profile",
                        fontSize = 11.sp,
                        fontWeight = if (currentTab == MainTab.PROFILE) FontWeight.Bold else FontWeight.Medium
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = IndigoPrimary,
                    selectedTextColor = IndigoPrimary,
                    indicatorColor = IndigoContainer,
                    unselectedIconColor = Slate500,
                    unselectedTextColor = Slate500
                ),
                modifier = Modifier.testTag("nav_item_profile")
            )
        }
    }
}

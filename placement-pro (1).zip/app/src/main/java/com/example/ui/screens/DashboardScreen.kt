package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Company
import com.example.ui.components.PlacementReadinessGauge
import com.example.ui.components.SkillScoreRow
import com.example.ui.theme.*
import com.example.ui.viewmodel.AiTab
import com.example.ui.viewmodel.MainTab
import com.example.ui.viewmodel.PlacementViewModel
import com.example.ui.viewmodel.PrepareTab

@Composable
fun DashboardScreen(
    viewModel: PlacementViewModel,
    modifier: Modifier = Modifier
) {
    val profile by viewModel.studentProfile.collectAsState()
    val studyPlan by viewModel.studyPlan.collectAsState()
    val readiness = viewModel.getReadinessBreakdown(profile)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Shiny Radiant Hero Banner
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                modifier = Modifier.fillMaxWidth().testTag("dashboard_hero_card")
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(ShineHeroGradient)
                        .padding(22.dp)
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = Color.White.copy(alpha = 0.22f)
                                    ) {
                                        Text(
                                            text = "PREP ARENA",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            letterSpacing = 1.sp,
                                            color = Color.White,
                                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "${profile.branch}",
                                        style = MaterialTheme.typography.labelSmall.copy(color = Slate200),
                                        maxLines = 1
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Hello, ${profile.fullName} ✨",
                                    style = MaterialTheme.typography.headlineMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                )
                                Text(
                                    text = "Target CGPA ${profile.cgpa} • Batch of ${profile.graduationYear}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = Slate200)
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Stars,
                                    contentDescription = "Starred Rank",
                                    tint = WarningAmber,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Target Companies Showcase
                        Text(
                            text = "Target Recruitment Patterns:",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Slate200,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(profile.targetCompanies) { comp ->
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = Color.White.copy(alpha = 0.2f)
                                ) {
                                    Text(
                                        text = comp,
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            color = Color.White,
                                            fontWeight = FontWeight.SemiBold
                                        ),
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 2. Shiny Quick Practice Launchpad
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickActionPill(
                    icon = Icons.Default.Quiz,
                    title = "Aptitude",
                    subtitle = "Quantitative & Logic",
                    color = IndigoPrimary,
                    containerColor = IndigoContainer,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        viewModel.setTab(MainTab.PREPARE)
                        viewModel.setPrepareTab(PrepareTab.APTITUDE)
                    }
                )
                QuickActionPill(
                    icon = Icons.Default.Code,
                    title = "DSA Coding",
                    subtitle = "Run & Test Code",
                    color = CyanDark,
                    containerColor = CyanContainer,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        viewModel.setTab(MainTab.PREPARE)
                        viewModel.setPrepareTab(PrepareTab.CODING)
                    }
                )
                QuickActionPill(
                    icon = Icons.Default.Psychology,
                    title = "AI Interview",
                    subtitle = "Gemini Live Voice",
                    color = VioletTertiary,
                    containerColor = VioletContainer,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        viewModel.setTab(MainTab.AI_TOOLS)
                        viewModel.setAiTab(AiTab.MOCK_INTERVIEW)
                    }
                )
            }
        }

        // 3. Placement Readiness Index & Domain Breakdown
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier = Modifier.fillMaxWidth().testTag("dashboard_readiness_card")
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Placement Readiness Index",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Multi-Factor Scoring Model",
                                style = MaterialTheme.typography.labelSmall,
                                color = Slate500
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = SuccessContainer
                        ) {
                            Text(
                                text = "Top 15% Campus Rank",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = SuccessDark
                                ),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        PlacementReadinessGauge(
                            score = readiness.overallScore,
                            size = 130.dp
                        )

                        Column(modifier = Modifier.weight(1f)) {
                            SkillScoreRow("Aptitude", readiness.aptitudeScore, IndigoPrimary)
                            SkillScoreRow("DSA Coding", readiness.codingScore, CyanDark)
                            SkillScoreRow("Core CS Tech", readiness.technicalScore, VioletTertiary)
                            SkillScoreRow("AI Interview", readiness.interviewScore, SuccessGreen)
                            SkillScoreRow("Resume ATS", readiness.resumeScore, WarningAmber)
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 14.dp), color = Slate200)

                    // Explainable insights
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Lightbulb,
                                contentDescription = "AI Recommendation",
                                tint = WarningAmber,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Personalized Insights:",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = Slate800
                            )
                        }

                        Text(
                            text = "• Strongest areas: ${readiness.strongAreas.joinToString(", ")}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Slate600
                        )
                        Text(
                            text = "• Areas for boost: ${readiness.weakAreas.joinToString(", ")}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Slate600
                        )
                        if (readiness.nextRecommendations.isNotEmpty()) {
                            Text(
                                text = "• Action: ${readiness.nextRecommendations.first()}",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                                color = IndigoPrimary
                            )
                        }
                    }
                }
            }
        }

        // 4. Preparation Activity Counters
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    StatCounter(value = "${profile.currentStreak}d", label = "Streak", icon = Icons.Default.LocalFireDepartment, color = WarningAmber)
                    StatCounter(value = "${profile.questionsSolved}", label = "Solved Qs", icon = Icons.Default.CheckCircle, color = SuccessGreen)
                    StatCounter(value = "${profile.codingProblemsSolved}", label = "DSA Code", icon = Icons.Default.Code, color = CyanDark)
                    StatCounter(value = "${profile.testsCompleted}", label = "Tests", icon = Icons.Default.AssignmentTurnedIn, color = VioletTertiary)
                }
            }
        }

        // 5. Curated Company Preparation Guides
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Company Test & Interview Guides",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Syllabus, difficulty, and hiring rounds",
                        style = MaterialTheme.typography.bodySmall,
                        color = Slate500
                    )
                }
            }

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.padding(top = 10.dp)
            ) {
                items(viewModel.companies) { comp ->
                    CompanyCardMini(
                        company = comp,
                        onClick = { viewModel.selectCompany(comp) }
                    )
                }
            }
        }

        // 6. 14-Day Study Checklist (Fast Action)
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.DateRange, contentDescription = null, tint = IndigoPrimary, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Study Roadmap & Today's Tasks",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }

                        TextButton(
                            onClick = {
                                viewModel.setTab(MainTab.AI_TOOLS)
                                viewModel.setAiTab(AiTab.STUDY_PLAN)
                            }
                        ) {
                            Text("Full Plan", fontSize = 12.sp, color = IndigoPrimary, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    studyPlan.take(3).forEach { item ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable { viewModel.toggleStudyPlanTask(item.dayNumber, !item.isCompleted) }
                        ) {
                            Checkbox(
                                checked = item.isCompleted,
                                onCheckedChange = { checked -> viewModel.toggleStudyPlanTask(item.dayNumber, checked) },
                                colors = CheckboxDefaults.colors(checkedColor = IndigoPrimary)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Day ${item.dayNumber}: ${item.dayTitle}",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                    color = if (item.isCompleted) Slate400 else Slate900
                                )
                                Text(
                                    text = "${item.estimatedMinutes} mins • ${item.codingTask}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Slate500
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QuickActionPill(
    icon: ImageVector,
    title: String,
    subtitle: String,
    color: Color,
    containerColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = containerColor,
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(color),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = title, tint = Color.White, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                color = Slate900
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = Slate600,
                maxLines = 1
            )
        }
    }
}

@Composable
fun StatCounter(
    value: String,
    label: String,
    icon: ImageVector,
    color: Color
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(imageVector = icon, contentDescription = label, tint = color, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = Slate900
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = Slate500
        )
    }
}

@Composable
fun CompanyCardMini(
    company: Company,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 2.dp,
        modifier = Modifier
            .width(190.dp)
            .clickable(onClick = onClick)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = IndigoContainer,
                    modifier = Modifier.size(36.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = company.name.take(2).uppercase(),
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = IndigoPrimary
                        )
                    }
                }
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = SuccessContainer
                ) {
                    Text(
                        text = "₹${company.avgPackageLpa} LPA",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = SuccessDark,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = company.name,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                color = Slate900
            )
            Text(
                text = company.industry,
                style = MaterialTheme.typography.labelSmall,
                color = Slate500,
                maxLines = 1
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Min CGPA: ${company.minCgpa} • ${company.industry}",
                style = MaterialTheme.typography.labelSmall.copy(color = IndigoPrimary, fontWeight = FontWeight.SemiBold)
            )
        }
    }
}

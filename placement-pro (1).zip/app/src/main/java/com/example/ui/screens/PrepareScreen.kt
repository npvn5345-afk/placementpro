package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.DifficultyBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.PlacementViewModel
import com.example.ui.viewmodel.PrepareTab

@Composable
fun PrepareScreen(
    viewModel: PlacementViewModel,
    modifier: Modifier = Modifier
) {
    val currentSubTab by viewModel.prepareTab.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Tab Row
        ScrollableTabRow(
            selectedTabIndex = currentSubTab.ordinal,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = IndigoPrimary,
            edgePadding = 16.dp
        ) {
            Tab(
                selected = currentSubTab == PrepareTab.APTITUDE,
                onClick = { viewModel.setPrepareTab(PrepareTab.APTITUDE) },
                text = { Text("Aptitude") }
            )
            Tab(
                selected = currentSubTab == PrepareTab.CODING,
                onClick = { viewModel.setPrepareTab(PrepareTab.CODING) },
                text = { Text("Coding Arena") }
            )
            Tab(
                selected = currentSubTab == PrepareTab.TECHNICAL,
                onClick = { viewModel.setPrepareTab(PrepareTab.TECHNICAL) },
                text = { Text("CS Fundamentals") }
            )
            Tab(
                selected = currentSubTab == PrepareTab.SQL,
                onClick = { viewModel.setPrepareTab(PrepareTab.SQL) },
                text = { Text("SQL Practice") }
            )
            Tab(
                selected = currentSubTab == PrepareTab.MOCK_TESTS,
                onClick = { viewModel.setPrepareTab(PrepareTab.MOCK_TESTS) },
                text = { Text("Mock Tests") }
            )
        }

        when (currentSubTab) {
            PrepareTab.APTITUDE -> AptitudeSection(viewModel)
            PrepareTab.CODING -> CodingSection(viewModel)
            PrepareTab.TECHNICAL -> TechnicalSection(viewModel)
            PrepareTab.SQL -> SqlSection(viewModel)
            PrepareTab.MOCK_TESTS -> MockTestsSection(viewModel)
        }
    }
}

// ==========================================
// APTITUDE PREPARATION SECTION
// ==========================================
@Composable
fun AptitudeSection(viewModel: PlacementViewModel) {
    var selectedCategory by remember { mutableStateOf<AptitudeCategory?>(null) }
    var selectedDifficulty by remember { mutableStateOf<Difficulty?>(null) }
    val answeredMap by viewModel.aptitudeAnswerMap.collectAsState()
    val allQuestions by viewModel.aptitudeQuestionsFlow.collectAsState()

    val filteredQuestions = allQuestions.filter { q ->
        (selectedCategory == null || q.category == selectedCategory) &&
        (selectedDifficulty == null || q.difficulty == selectedDifficulty)
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Filters
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Category Filter:",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        FilterChip(
                            selected = selectedCategory == null,
                            onClick = { selectedCategory = null },
                            label = { Text("All Categories") }
                        )
                    }
                    item {
                        FilterChip(
                            selected = selectedCategory == AptitudeCategory.QUANTITATIVE,
                            onClick = { selectedCategory = AptitudeCategory.QUANTITATIVE },
                            label = { Text("Quantitative") }
                        )
                    }
                    item {
                        FilterChip(
                            selected = selectedCategory == AptitudeCategory.LOGICAL,
                            onClick = { selectedCategory = AptitudeCategory.LOGICAL },
                            label = { Text("Logical Reasoning") }
                        )
                    }
                    item {
                        FilterChip(
                            selected = selectedCategory == AptitudeCategory.VERBAL,
                            onClick = { selectedCategory = AptitudeCategory.VERBAL },
                            label = { Text("Verbal Ability") }
                        )
                    }
                }
            }
        }

        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Practice Questions (${filteredQuestions.size})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Instant Feedback",
                    style = MaterialTheme.typography.labelSmall.copy(color = SuccessGreen, fontWeight = FontWeight.Bold)
                )
            }
        }

        items(filteredQuestions) { question ->
            val userSelected = answeredMap[question.id]
            var showExplanation by remember { mutableStateOf(false) }

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = IndigoContainer
                        ) {
                            Text(
                                text = "${question.category.name} • ${question.subcategory}",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = IndigoPrimary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                        DifficultyBadge(difficulty = question.difficulty)
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = question.question,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // 4 Options
                    question.options.forEachIndexed { index, opt ->
                        val isSelected = userSelected == index
                        val isCorrect = index == question.correctIndex
                        val hasAnswered = userSelected != null

                        val optBg = when {
                            hasAnswered && isCorrect -> SuccessContainer
                            hasAnswered && isSelected && !isCorrect -> ErrorContainer
                            isSelected -> IndigoContainer
                            else -> Slate100
                        }

                        val optFg = when {
                            hasAnswered && isCorrect -> Color(0xFF065F46)
                            hasAnswered && isSelected && !isCorrect -> Color(0xFF991B1B)
                            else -> Slate800
                        }

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = optBg,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable {
                                    viewModel.answerAptitudeQuestion(question.id, index)
                                    showExplanation = true
                                }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                            ) {
                                Text(
                                    text = "${('A' + index)}. ",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = optFg
                                )
                                Text(
                                    text = opt,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = optFg,
                                    modifier = Modifier.weight(1f)
                                )
                                if (hasAnswered && isCorrect) {
                                    Icon(Icons.Default.Check, contentDescription = "Correct", tint = SuccessGreen, modifier = Modifier.size(18.dp))
                                } else if (hasAnswered && isSelected && !isCorrect) {
                                    Icon(Icons.Default.Close, contentDescription = "Incorrect", tint = ErrorRed, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }

                    if (userSelected != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(onClick = { showExplanation = !showExplanation }) {
                                Text(if (showExplanation) "Hide Explanation" else "View Detailed Solution")
                            }
                            if (question.formulaOrHint.isNotEmpty()) {
                                Text(
                                    text = "Formula Hint Available",
                                    style = MaterialTheme.typography.labelSmall.copy(color = WarningAmber)
                                )
                            }
                        }

                        if (showExplanation) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Slate100,
                                modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = "Solution & Step-by-Step Explanation:",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = Slate900
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = question.explanation,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Slate700
                                    )
                                    if (question.formulaOrHint.isNotEmpty()) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "💡 Short-trick / Formula: ${question.formulaOrHint}",
                                            style = MaterialTheme.typography.labelSmall.copy(color = IndigoDark, fontWeight = FontWeight.SemiBold)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// CODING PREPARATION SECTION
// ==========================================
@Composable
fun CodingSection(viewModel: PlacementViewModel) {
    val selectedProblem by viewModel.selectedProblem.collectAsState()
    val problems by viewModel.codingProblemsFlow.collectAsState()

    if (selectedProblem == null) {
        // Problem List
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    text = "High-Frequency Campus DSA Problems",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Master Arrays, Two Pointers, Sliding Window, DP & Graphs",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            items(problems) { problem ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.selectCodingProblem(problem) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = problem.title,
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                DifficultyBadge(difficulty = problem.difficulty)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Topic: ${problem.topic}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Button(
                            onClick = { viewModel.selectCodingProblem(problem) },
                            colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                        ) {
                            Text("Solve", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }
        }
    } else {
        // Interactive Code Editor & Runner
        CodingEditorView(
            problem = selectedProblem!!,
            viewModel = viewModel,
            onBack = { viewModel.selectCodingProblem(null) }
        )
    }
}

@Composable
fun CodingEditorView(
    problem: CodingProblem,
    viewModel: PlacementViewModel,
    onBack: () -> Unit
) {
    val language by viewModel.selectedLanguage.collectAsState()
    val code by viewModel.editorCode.collectAsState()
    val executionResult by viewModel.codeExecutionResult.collectAsState()

    var activeTab by remember { mutableStateOf(0) } // 0: Description, 1: Approach & Hints

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Top Back Row
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Text(
                    text = problem.title,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
                DifficultyBadge(difficulty = problem.difficulty)
            }
        }

        // Subtabs: Problem Description vs Solution Approach
        item {
            TabRow(
                selectedTabIndex = activeTab,
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                Tab(selected = activeTab == 0, onClick = { activeTab = 0 }, text = { Text("Description") })
                Tab(selected = activeTab == 1, onClick = { activeTab = 1 }, text = { Text("Approach & Hints") })
            }
        }

        if (activeTab == 0) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = problem.description,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Sample Input:",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Slate100,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        ) {
                            Text(
                                text = problem.sampleInput,
                                fontFamily = FontFamily.Monospace,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                        Text(
                            text = "Sample Output:",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Slate100,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        ) {
                            Text(
                                text = problem.sampleOutput,
                                fontFamily = FontFamily.Monospace,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                }
            }
        } else {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Optimal Algorithmic Approach:",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = IndigoPrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = problem.solutionApproach,
                            style = MaterialTheme.typography.bodySmall,
                            color = Slate700
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Hints:",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        problem.hints.forEachIndexed { i, h ->
                            Text(
                                text = "${i + 1}. $h",
                                style = MaterialTheme.typography.bodySmall,
                                color = Slate600
                            )
                        }
                    }
                }
            }
        }

        // Language Selector Row
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Code Editor",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Python", "Java", "C++").forEach { lang ->
                        FilterChip(
                            selected = language == lang,
                            onClick = { viewModel.setEditorLanguage(lang) },
                            label = {
                                Text(
                                    if (lang == "Python") "🐍 Python 3" else lang,
                                    fontWeight = if (language == lang) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = if (lang == "Python") IndigoContainer else CyanContainer,
                                selectedLabelColor = if (lang == "Python") IndigoPrimary else CyanDark
                            )
                        )
                    }
                }
            }
        }

        // Code Editor Box
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Slate950,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (language == "Python") WarningContainer else IndigoContainer
                            ) {
                                Text(
                                    text = if (language == "Python") "PY3" else language.take(3).uppercase(),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (language == "Python") WarningDark else IndigoPrimary,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (language == "Python") "solution.py" else "Solution.${language.take(3).lowercase()}",
                                style = MaterialTheme.typography.labelSmall.copy(color = Slate300, fontFamily = FontFamily.Monospace)
                            )
                        }
                        Text(
                            text = "⚡ Python Environment Active",
                            style = MaterialTheme.typography.labelSmall.copy(color = CyanLight, fontWeight = FontWeight.SemiBold)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = code,
                        onValueChange = { viewModel.updateEditorCode(it) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 180.dp, max = 320.dp),
                        textStyle = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = FontFamily.Monospace,
                            color = Slate100,
                            lineHeight = 18.sp
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanSecondary,
                            unfocusedBorderColor = Slate700,
                            cursorColor = CyanLight
                        )
                    )
                }
            }
        }

        // Actions: Run & Submit
        item {
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedButton(
                    onClick = { viewModel.runCodeSolution() },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "Run")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Run Tests")
                }
                Button(
                    onClick = { viewModel.runCodeSolution() },
                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = "Submit")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Submit (+50 XP)")
                }
            }
        }

        // Execution Result Box
        if (executionResult != null) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (executionResult!!.isSuccess) SuccessContainer else ErrorContainer
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = executionResult!!.status,
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (executionResult!!.isSuccess) Color(0xFF065F46) else Color(0xFF991B1B)
                                )
                            )
                            Text(
                                text = "Runtime: ${executionResult!!.runtimeMs}ms | Memory: ${executionResult!!.memoryMb}MB",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (executionResult!!.isSuccess) Color(0xFF065F46) else Color(0xFF991B1B)
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = executionResult!!.output,
                            fontFamily = FontFamily.Monospace,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (executionResult!!.isSuccess) Color(0xFF065F46) else Color(0xFF991B1B)
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// TECHNICAL CS FUNDAMENTALS SECTION
// ==========================================
@Composable
fun TechnicalSection(viewModel: PlacementViewModel) {
    var selectedSubject by remember { mutableStateOf("All") }
    val questions by viewModel.technicalQuestionsFlow.collectAsState()
    val subjects = listOf("All", "OOP", "DBMS", "Operating Systems", "Computer Networks", "Data Structures")

    val filtered = if (selectedSubject == "All") questions else questions.filter { it.subject == selectedSubject }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Core Engineering Subjects",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(subjects) { subj ->
                        FilterChip(
                            selected = selectedSubject == subj,
                            onClick = { selectedSubject = subj },
                            label = { Text(subj) }
                        )
                    }
                }
            }
        }

        items(filtered) { item ->
            var expanded by remember { mutableStateOf(false) }

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Surface(shape = RoundedCornerShape(8.dp), color = VioletContainer) {
                            Text(
                                text = item.subject,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = VioletTertiary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                        DifficultyBadge(difficulty = item.difficulty)
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = item.question,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    if (expanded) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = item.answer,
                            style = MaterialTheme.typography.bodySmall.copy(lineHeight = 20.sp),
                            color = Slate700
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(item.keyConcepts) { concept ->
                                Surface(shape = RoundedCornerShape(6.dp), color = Slate100) {
                                    Text(
                                        text = concept,
                                        style = MaterialTheme.typography.labelSmall,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    } else {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Tap to view comprehensive answer & concepts",
                            style = MaterialTheme.typography.labelSmall.copy(color = IndigoPrimary)
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// SQL PRACTICE SECTION
// ==========================================
@Composable
fun SqlSection(viewModel: PlacementViewModel) {
    val sqlList = viewModel.sqlProblems

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Interactive SQL Query Challenges",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "Master Aggregations, GROUP BY, HAVING, and Complex Joins",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        items(sqlList) { sql ->
            var userQuery by remember { mutableStateOf("SELECT * FROM Employee;") }
            var isSolved by remember { mutableStateOf(false) }

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = sql.title,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        DifficultyBadge(difficulty = sql.difficulty)
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = sql.question,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Slate800
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Slate900,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = sql.sampleTable,
                            fontFamily = FontFamily.Monospace,
                            style = MaterialTheme.typography.bodySmall.copy(color = Slate200),
                            modifier = Modifier.padding(10.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = userQuery,
                        onValueChange = { userQuery = it },
                        label = { Text("Write SQL Query") },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace)
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Button(
                            onClick = {
                                isSolved = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                        ) {
                            Text("Run & Validate Query")
                        }

                        TextButton(onClick = { userQuery = sql.solutionQuery; isSolved = true }) {
                            Text("Reveal Solution")
                        }
                    }

                    if (isSolved) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = SuccessContainer,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = "Query Result: MATCHED Expected Output!",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF065F46)
                                    )
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = sql.explanation,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF065F46)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// MOCK TESTS SECTION
// ==========================================
@Composable
fun MockTestsSection(viewModel: PlacementViewModel) {
    val activeTest by viewModel.activeTest.collectAsState()

    if (activeTest == null) {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text(
                    text = "Placement Mock Assessments",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Timed simulations mimicking actual corporate recruitment exams",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            item {
                MockTestCard(
                    title = "Full Placement Diagnostic Simulation",
                    description = "Comprehensive multi-section assessment covering Quantitative Aptitude, Logical Reasoning, and Verbal Ability.",
                    questionsCount = 15,
                    durationMins = 20,
                    onStart = {
                        viewModel.startMockTest(
                            "Full Placement Diagnostic Simulation",
                            viewModel.aptitudeQuestions.take(15)
                        )
                    }
                )
            }

            item {
                MockTestCard(
                    title = "TCS NQT Foundation Speed Test",
                    description = "High-speed numerical ability, abstract reasoning, and sentence completion under strict time bounds.",
                    questionsCount = 10,
                    durationMins = 15,
                    onStart = {
                        viewModel.startMockTest(
                            "TCS NQT Foundation Speed Test",
                            viewModel.aptitudeQuestions.filter { it.category == AptitudeCategory.QUANTITATIVE }
                        )
                    }
                )
            }

            item {
                MockTestCard(
                    title = "Logical Reasoning & Cognitive Drill",
                    description = "Syllogisms, blood relations, directions, and series patterns matching Accenture & Infosys rounds.",
                    questionsCount = 8,
                    durationMins = 12,
                    onStart = {
                        viewModel.startMockTest(
                            "Logical Reasoning & Cognitive Drill",
                            viewModel.aptitudeQuestions.filter { it.category == AptitudeCategory.LOGICAL }
                        )
                    }
                )
            }
        }
    } else {
        // Active Timed Test Screen
        ActiveMockTestView(viewModel = viewModel, test = activeTest!!)
    }
}

@Composable
fun MockTestCard(
    title: String,
    description: String,
    questionsCount: Int,
    durationMins: Int,
    onStart: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "⏱️ $durationMins mins",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                        color = Slate700
                    )
                    Text(
                        text = "📋 $questionsCount Questions",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                        color = Slate700
                    )
                }
                Button(
                    onClick = onStart,
                    colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                ) {
                    Text("Start Test")
                }
            }
        }
    }
}

@Composable
fun ActiveMockTestView(
    viewModel: PlacementViewModel,
    test: com.example.ui.viewmodel.ActiveTestState
) {
    if (test.isSubmitted) {
        // Test Result Screen
        val percentage = ((test.correctCount.toDouble() / test.totalCount) * 100).toInt()

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Test Completed! 🎯",
                            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "$percentage%",
                            style = MaterialTheme.typography.displayMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (percentage >= 70) SuccessGreen else WarningAmber
                            )
                        )
                        Text(
                            text = "Score: ${test.correctCount} out of ${test.totalCount} correct",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                            color = Slate600
                        )

                        Spacer(modifier = Modifier.height(16.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(16.dp))

                        if (test.weakTopics.isNotEmpty()) {
                            Text(
                                text = "Weak Areas Detected:",
                                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                color = ErrorRed
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Recommended remedial focus: ${test.weakTopics.joinToString(", ")}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Slate700
                            )
                        } else {
                            Text(
                                text = "Outstanding performance! You cleared the cutoff effortlessly.",
                                style = MaterialTheme.typography.bodyMedium.copy(color = SuccessGreen)
                            )
                        }

                        Spacer(modifier = Modifier.height(20.dp))
                        Button(
                            onClick = { viewModel.closeMockTest() },
                            colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Back to Assessments")
                        }
                    }
                }
            }
        }
    } else {
        // Active Question Screen
        val currentQ = test.questions[test.currentIndex]
        val selectedOption = test.selectedOptions[currentQ.id]
        val isMarked = test.markedForReview.contains(currentQ.id)

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Question ${test.currentIndex + 1} of ${test.questions.size}",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Surface(shape = RoundedCornerShape(12.dp), color = WarningContainer) {
                        Text(
                            text = "⏱️ Timed Assessment",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = Slate900),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = currentQ.question,
                            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        currentQ.options.forEachIndexed { i, opt ->
                            val isSelected = selectedOption == i
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) IndigoContainer else Slate100,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable { viewModel.selectTestOption(currentQ.id, i) }
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(12.dp)
                                ) {
                                    Text(
                                        text = "${('A' + i)}. ",
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                        color = if (isSelected) IndigoPrimary else Slate800
                                    )
                                    Text(
                                        text = opt,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = if (isSelected) IndigoPrimary else Slate800
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Bottom Navigation Controls
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    OutlinedButton(
                        onClick = { viewModel.toggleMarkForReview(currentQ.id) },
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = if (isMarked) WarningAmber else Slate700
                        )
                    ) {
                        Text(if (isMarked) "★ Marked" else "Mark for Review")
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (test.currentIndex > 0) {
                            OutlinedButton(onClick = { viewModel.setTestQuestionIndex(test.currentIndex - 1) }) {
                                Text("Previous")
                            }
                        }
                        if (test.currentIndex < test.questions.size - 1) {
                            Button(
                                onClick = { viewModel.setTestQuestionIndex(test.currentIndex + 1) },
                                colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                            ) {
                                Text("Next")
                            }
                        } else {
                            Button(
                                onClick = { viewModel.submitMockTest() },
                                colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)
                            ) {
                                Text("Submit Test")
                            }
                        }
                    }
                }
            }
        }
    }
}

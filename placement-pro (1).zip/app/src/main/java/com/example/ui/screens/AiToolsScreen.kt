package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ml.PlacementPredictor
import com.example.data.model.Company
import com.example.ui.screens.interview.MockInterviewView
import com.example.ui.theme.*
import com.example.ui.viewmodel.AiTab
import com.example.ui.viewmodel.PlacementViewModel

@Composable
fun AiToolsScreen(
    viewModel: PlacementViewModel,
    modifier: Modifier = Modifier
) {
    val currentAiTab by viewModel.aiTab.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        ScrollableTabRow(
            selectedTabIndex = currentAiTab.ordinal,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = IndigoPrimary,
            edgePadding = 16.dp
        ) {
            Tab(
                selected = currentAiTab == AiTab.SKILL_GAP,
                onClick = { viewModel.setAiTab(AiTab.SKILL_GAP) },
                text = { Text("Skill Gap Analysis") }
            )
            Tab(
                selected = currentAiTab == AiTab.STUDY_PLAN,
                onClick = { viewModel.setAiTab(AiTab.STUDY_PLAN) },
                text = { Text("AI Study Planner") }
            )
            Tab(
                selected = currentAiTab == AiTab.RESUME_ANALYZER,
                onClick = { viewModel.setAiTab(AiTab.RESUME_ANALYZER) },
                text = { Text("Resume ATS Analyzer") }
            )
            Tab(
                selected = currentAiTab == AiTab.MOCK_INTERVIEW,
                onClick = { viewModel.setAiTab(AiTab.MOCK_INTERVIEW) },
                text = { Text("Mock Interview") }
            )
        }

        when (currentAiTab) {
            AiTab.SKILL_GAP -> SkillGapSection(viewModel)
            AiTab.STUDY_PLAN -> StudyPlanSection(viewModel)
            AiTab.RESUME_ANALYZER -> ResumeAnalyzerSection(viewModel)
            AiTab.MOCK_INTERVIEW -> MockInterviewView(viewModel)
        }
    }
}

// ==========================================
// 1. SKILL GAP ANALYSIS SECTION
// ==========================================
@Composable
fun SkillGapSection(viewModel: PlacementViewModel) {
    val profile by viewModel.studentProfile.collectAsState()
    val companies = viewModel.companies
    var selectedCompany by remember { mutableStateOf(companies.first()) }

    val gapResult = remember(selectedCompany, profile.skills) {
        PlacementPredictor.analyzeSkillGap(profile.skills, selectedCompany)
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Explainable AI Skill-Gap Analysis",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "Compare your current skills against top company recruitment requirements.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Company selector chips
        item {
            Text(
                text = "Select Target Company:",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(companies) { comp ->
                    FilterChip(
                        selected = selectedCompany.id == comp.id,
                        onClick = { selectedCompany = comp },
                        label = { Text(comp.name) }
                    )
                }
            }
        }

        // Analysis Summary Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "${gapResult.companyName} Skill Match",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Estimated ${gapResult.estimatedPreparationDays} days to close gaps",
                                style = MaterialTheme.typography.labelSmall,
                                color = IndigoPrimary
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (gapResult.matchPercentage >= 70) SuccessContainer else WarningContainer
                        ) {
                            Text(
                                text = "${gapResult.matchPercentage}%",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (gapResult.matchPercentage >= 70) Color(0xFF065F46) else Color(0xFF92400E)
                                ),
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = gapResult.explanation,
                        style = MaterialTheme.typography.bodySmall,
                        color = Slate700
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(12.dp))

                    // Matched Skills
                    Text(
                        text = "Matched Skills (${gapResult.matchedSkills.size}):",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = SuccessGreen
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(gapResult.matchedSkills) { s ->
                            Surface(shape = RoundedCornerShape(8.dp), color = SuccessContainer) {
                                Text(
                                    text = "✓ $s",
                                    style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFF065F46)),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Missing Skills
                    Text(
                        text = "Missing Required Skills (${gapResult.missingSkills.size}):",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = ErrorRed
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    if (gapResult.missingSkills.isEmpty()) {
                        Text(
                            text = "None! You possess all required technical skills for this company.",
                            style = MaterialTheme.typography.bodySmall.copy(color = SuccessGreen)
                        )
                    } else {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(gapResult.missingSkills) { s ->
                                Surface(shape = RoundedCornerShape(8.dp), color = ErrorContainer) {
                                    Text(
                                        text = "+ $s",
                                        style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFF991B1B)),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 2. AI STUDY PLANNER SECTION
// ==========================================
@Composable
fun StudyPlanSection(viewModel: PlacementViewModel) {
    val studyPlan by viewModel.studyPlan.collectAsState()
    val completedCount = studyPlan.count { it.isCompleted }
    val totalCount = studyPlan.size.coerceAtLeast(1)
    val progress = completedCount.toFloat() / totalCount

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = IndigoPrimary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Personalized 7-Day Sprint",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                            Text(
                                text = "$completedCount of $totalCount Days Completed",
                                style = MaterialTheme.typography.bodySmall.copy(color = Slate200)
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color.White.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "${(progress * 100).toInt()}% Done",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                ),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    LinearProgressIndicator(
                        progress = { progress },
                        color = SuccessGreen,
                        trackColor = Color.White.copy(alpha = 0.2f),
                        modifier = Modifier.fillMaxWidth().height(6.dp)
                    )
                }
            }
        }

        items(studyPlan) { item ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Checkbox(
                        checked = item.isCompleted,
                        onCheckedChange = { checked ->
                            viewModel.toggleStudyPlanTask(item.dayNumber, checked)
                        }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = item.dayTitle,
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (item.isCompleted) Slate400 else MaterialTheme.colorScheme.onSurface
                                )
                            )
                            Text(
                                text = "${item.estimatedMinutes} mins",
                                style = MaterialTheme.typography.labelSmall,
                                color = Slate500
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(text = "• Aptitude: ${item.aptitudeTask}", style = MaterialTheme.typography.bodySmall, color = Slate700)
                        Text(text = "• Coding: ${item.codingTask}", style = MaterialTheme.typography.bodySmall, color = Slate700)
                        Text(text = "• Technical: ${item.technicalTask}", style = MaterialTheme.typography.bodySmall, color = Slate700)
                        Text(text = "• Interview: ${item.interviewTask}", style = MaterialTheme.typography.bodySmall, color = Slate700)
                    }
                }
            }
        }
    }
}

// ==========================================
// 3. RESUME ATS ANALYZER SECTION
// ==========================================
@Composable
fun ResumeAnalyzerSection(viewModel: PlacementViewModel) {
    val resumeText by viewModel.resumeText.collectAsState()
    val analysisResult by viewModel.resumeAnalysisResult.collectAsState()

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "AI Resume Builder & ATS Scorer",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "Instant NLP keyword analysis, formatting score, and action-verb recommendations",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Score Card
        if (analysisResult != null) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Estimated ATS Score",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = analysisResult!!.roleRelevance,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = IndigoPrimary
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (analysisResult!!.overallScore >= 80) SuccessContainer else WarningContainer
                            ) {
                                Text(
                                    text = "${analysisResult!!.overallScore}/100",
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (analysisResult!!.overallScore >= 80) Color(0xFF065F46) else Color(0xFF92400E)
                                    ),
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Matched Keywords (${analysisResult!!.matchedSkills.size}):",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(vertical = 4.dp)
                        ) {
                            items(analysisResult!!.matchedSkills) { kw ->
                                Surface(shape = RoundedCornerShape(6.dp), color = SuccessContainer) {
                                    Text(
                                        text = kw,
                                        style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFF065F46)),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Suggestions for Improvement:",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = WarningAmber)
                        )
                        analysisResult!!.suggestions.forEach { sug ->
                            Text(
                                text = "• $sug",
                                style = MaterialTheme.typography.bodySmall,
                                color = Slate700
                            )
                        }
                    }
                }
            }
        }

        // Resume Text Area
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Resume Content / ATS Markdown Preview:",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = resumeText,
                        onValueChange = { viewModel.updateResumeText(it) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 160.dp, max = 280.dp),
                        textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = { viewModel.runResumeAnalysis() },
                        colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Re-Analyze Resume ATS Score")
                    }
                }
            }
        }
    }
}

// ==========================================
// 4. MOCK INTERVIEW SECTION
// ==========================================
@Composable
fun MockInterviewSection(viewModel: PlacementViewModel) {
    val prompts = viewModel.mockInterviewPrompts
    val currentPrompt by viewModel.currentInterviewPrompt.collectAsState()
    val studentAnswer by viewModel.interviewAnswer.collectAsState()
    val feedback by viewModel.interviewFeedback.collectAsState()

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "AI Mock Interview Practice",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "Practice responses to HR, Behavioral, and Situational interview questions.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Prompt Selector Chips
        item {
            Text(
                text = "Select Interview Scenario:",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(prompts) { p ->
                    FilterChip(
                        selected = currentPrompt.id == p.id,
                        onClick = { viewModel.selectInterviewPrompt(p) },
                        label = { Text(p.category) }
                    )
                }
            }
        }

        // Prompt Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Surface(shape = RoundedCornerShape(8.dp), color = VioletContainer) {
                        Text(
                            text = currentPrompt.category,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = VioletTertiary),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = currentPrompt.question,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Framework: ${currentPrompt.idealFramework}",
                        style = MaterialTheme.typography.labelSmall.copy(color = IndigoPrimary)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Tips: ${currentPrompt.guidance}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Slate600
                    )
                }
            }
        }

        // Answer Input Box
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Your Answer (Speak or Type):",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = studentAnswer,
                        onValueChange = { viewModel.updateInterviewAnswer(it) },
                        placeholder = { Text("Draft your structured response here...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 120.dp, max = 220.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        TextButton(onClick = {
                            viewModel.updateInterviewAnswer(currentPrompt.sampleAnswer)
                        }) {
                            Text("Load Model Answer")
                        }

                        Button(
                            onClick = { viewModel.evaluateInterviewAnswer() },
                            colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                        ) {
                            Text("Evaluate Response (+40 XP)")
                        }
                    }
                }
            }
        }

        // AI Feedback Box
        if (feedback != null) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SuccessContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Verified, contentDescription = null, tint = SuccessGreen)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Advisory AI Evaluation & Suggestions:",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF065F46)
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = feedback!!,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF065F46)
                        )
                    }
                }
            }
        }
    }
}

package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.Company
import com.example.ui.theme.*

@Composable
fun CompanyDetailDialog(
    company: Company,
    onDismiss: () -> Unit,
    onPrepareRoadmap: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .padding(vertical = 12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
            ) {
                // Shiny gradient banner
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(ShineHeroGradient)
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = company.name,
                                style = MaterialTheme.typography.headlineMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                            Text(
                                text = "${company.industry} • Campus Hiring Guide",
                                style = MaterialTheme.typography.bodySmall,
                                color = Slate200
                            )
                        }
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White.copy(alpha = 0.2f))
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                        }
                    }
                }

                Column(modifier = Modifier.padding(20.dp)) {
                    // Quick Stats Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = SuccessContainer,
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("Avg Package", fontSize = 11.sp, color = SuccessDark)
                                Text("₹${company.avgPackageLpa} LPA", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = SuccessDark)
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = IndigoContainer,
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("Highest CTC", fontSize = 11.sp, color = IndigoDark)
                                Text("₹${company.highestPackageLpa} LPA", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = IndigoDark)
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = CyanContainer,
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("Min CGPA", fontSize = 11.sp, color = CyanDark)
                                Text("${company.minCgpa}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = CyanDark)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "About Company & Roles",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = company.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Slate700
                    )

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Selection Rounds",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    company.selectionRounds.forEachIndexed { i, round ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(vertical = 3.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(20.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(IndigoContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("${i + 1}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = IndigoPrimary)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = round, style = MaterialTheme.typography.bodyMedium, color = Slate700)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Aptitude & Technical Focus",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "• Aptitude: ${company.aptitudePattern}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Slate600
                    )
                    Text(
                        text = "• Coding: ${company.codingPattern}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Slate600
                    )
                    Text(
                        text = "• Technical Core: ${company.technicalFocus}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Slate600
                    )

                    Spacer(modifier = Modifier.height(20.dp))
                    Button(
                        onClick = {
                            onPrepareRoadmap()
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().height(46.dp)
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Create Personalized AI Prep Roadmap", fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

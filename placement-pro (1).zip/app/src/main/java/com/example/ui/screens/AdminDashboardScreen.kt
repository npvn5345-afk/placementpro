package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.PlacementViewModel

enum class AdminTab {
    QUESTIONS,
    ANALYTICS
}

enum class QuestionTypeFilter {
    APTITUDE,
    CODING,
    TECHNICAL_CS
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    viewModel: PlacementViewModel,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(AdminTab.QUESTIONS) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Shiny Admin Header Banner
        Surface(
            color = Slate900,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurfaceGradient)
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(ShineHeroGradient),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.AdminPanelSettings,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Admin Control Portal",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = VioletTertiary.copy(alpha = 0.35f)
                                ) {
                                    Text(
                                        text = "SUPERUSER",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = VioletLight,
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = "Curate question bank & student analytics",
                                style = MaterialTheme.typography.bodySmall,
                                color = Slate300
                            )
                        }
                    }

                    Button(
                        onClick = { viewModel.setRole(UserRole.USER) },
                        colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("btn_switch_to_user_mode")
                    ) {
                        Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("User View", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        // Clean Subtabs Row
        TabRow(
            selectedTabIndex = selectedTab.ordinal,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = VioletTertiary
        ) {
            Tab(
                selected = selectedTab == AdminTab.QUESTIONS,
                onClick = { selectedTab = AdminTab.QUESTIONS },
                text = { Text("Curate Questions", fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.Quiz, contentDescription = null, modifier = Modifier.size(18.dp)) },
                modifier = Modifier.testTag("admin_tab_questions")
            )
            Tab(
                selected = selectedTab == AdminTab.ANALYTICS,
                onClick = { selectedTab = AdminTab.ANALYTICS },
                text = { Text("Performance & Analytics", fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.BarChart, contentDescription = null, modifier = Modifier.size(18.dp)) },
                modifier = Modifier.testTag("admin_tab_analytics")
            )
        }

        when (selectedTab) {
            AdminTab.QUESTIONS -> AdminQuestionsSection(viewModel)
            AdminTab.ANALYTICS -> AdminAnalyticsSection(viewModel)
        }
    }
}

// ==========================================
// 1. MANAGE QUESTIONS (APTITUDE, CODING, TECH CS)
// ==========================================
@Composable
fun AdminQuestionsSection(viewModel: PlacementViewModel) {
    var questionType by remember { mutableStateOf(QuestionTypeFilter.APTITUDE) }
    val aptitudeList by viewModel.aptitudeQuestionsFlow.collectAsState()
    val codingList by viewModel.codingProblemsFlow.collectAsState()
    val technicalList by viewModel.technicalQuestionsFlow.collectAsState()

    var showAddAptitudeDialog by remember { mutableStateOf(false) }
    var showAddCodingDialog by remember { mutableStateOf(false) }
    var showAddTechDialog by remember { mutableStateOf(false) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize().testTag("list_admin_questions")
    ) {
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Question Bank Manager",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = Slate900
                        )
                        Text(
                            text = "Additions instantly update in User Practice Arena",
                            style = MaterialTheme.typography.bodySmall,
                            color = Slate500
                        )
                    }

                    Button(
                        onClick = {
                            when (questionType) {
                                QuestionTypeFilter.APTITUDE -> showAddAptitudeDialog = true
                                QuestionTypeFilter.CODING -> showAddCodingDialog = true
                                QuestionTypeFilter.TECHNICAL_CS -> showAddTechDialog = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = VioletTertiary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("btn_admin_add_question")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Question", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Filter Pills
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = questionType == QuestionTypeFilter.APTITUDE,
                    onClick = { questionType = QuestionTypeFilter.APTITUDE },
                    label = { Text("Aptitude (${aptitudeList.size})") }
                )
                FilterChip(
                    selected = questionType == QuestionTypeFilter.CODING,
                    onClick = { questionType = QuestionTypeFilter.CODING },
                    label = { Text("DSA Coding (${codingList.size})") }
                )
                FilterChip(
                    selected = questionType == QuestionTypeFilter.TECHNICAL_CS,
                    onClick = { questionType = QuestionTypeFilter.TECHNICAL_CS },
                    label = { Text("Core CS (${technicalList.size})") }
                )
            }
        }

        // Content Lists
        when (questionType) {
            QuestionTypeFilter.APTITUDE -> {
                items(aptitudeList) { q ->
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(shape = RoundedCornerShape(6.dp), color = IndigoContainer) {
                                    Text(
                                        text = "${q.category.name} • ${q.subcategory}",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = IndigoPrimary,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }

                                IconButton(
                                    onClick = { viewModel.deleteAptitudeQuestion(q.id) },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = ErrorRed, modifier = Modifier.size(16.dp))
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(text = q.question, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(text = "Options: ${q.options.joinToString(" | ")}", fontSize = 11.sp, color = Slate600)
                            Text(
                                text = "Correct: Option ${q.correctIndex + 1} (${q.options.getOrNull(q.correctIndex) ?: ""})",
                                fontSize = 11.sp,
                                color = SuccessGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
            QuestionTypeFilter.CODING -> {
                items(codingList) { p ->
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(shape = RoundedCornerShape(6.dp), color = CyanContainer) {
                                        Text(
                                            text = p.difficulty.name,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = CyanDark,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(text = p.topic, fontSize = 10.sp, color = Slate500)
                                }

                                IconButton(
                                    onClick = { viewModel.deleteCodingProblem(p.id) },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = ErrorRed, modifier = Modifier.size(16.dp))
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(text = p.title, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = p.description, style = MaterialTheme.typography.bodySmall, color = Slate700, maxLines = 2)
                        }
                    }
                }
            }
            QuestionTypeFilter.TECHNICAL_CS -> {
                items(technicalList) { tq ->
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(shape = RoundedCornerShape(6.dp), color = VioletContainer) {
                                    Text(
                                        text = tq.subject,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = VioletTertiary,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }

                                IconButton(
                                    onClick = { viewModel.deleteTechnicalQuestion(tq.id) },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = ErrorRed, modifier = Modifier.size(16.dp))
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(text = tq.question, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = tq.answer, style = MaterialTheme.typography.bodySmall, color = Slate700, maxLines = 3)
                        }
                    }
                }
            }
        }
    }

    if (showAddAptitudeDialog) {
        AddAptitudeQuestionDialog(
            onDismiss = { showAddAptitudeDialog = false },
            onAdd = { q ->
                viewModel.addAptitudeQuestion(q)
                showAddAptitudeDialog = false
            }
        )
    }

    if (showAddCodingDialog) {
        AddCodingProblemDialog(
            onDismiss = { showAddCodingDialog = false },
            onAdd = { p ->
                viewModel.addCodingProblem(p)
                showAddCodingDialog = false
            }
        )
    }

    if (showAddTechDialog) {
        AddTechnicalQuestionDialog(
            onDismiss = { showAddTechDialog = false },
            onAdd = { tq ->
                viewModel.addTechnicalQuestion(tq)
                showAddTechDialog = false
            }
        )
    }
}

// ==========================================
// 2. PLACEMENT & STUDENT ANALYTICS
// ==========================================
@Composable
fun AdminAnalyticsSection(viewModel: PlacementViewModel) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize().testTag("list_admin_analytics")
    ) {
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Campus Preparation & Readiness Analytics",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Real-time indicators across candidate cohorts",
                        style = MaterialTheme.typography.bodySmall,
                        color = Slate500
                    )
                }
            }
        }

        // Stats Matrix with radiant colors
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(1.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(text = "420", style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold, color = IndigoPrimary))
                        Text(text = "Active Students", style = MaterialTheme.typography.labelSmall, color = Slate500)
                    }
                }

                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(1.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(text = "82.4%", style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold, color = SuccessGreen))
                        Text(text = "Avg Readiness", style = MaterialTheme.typography.labelSmall, color = Slate500)
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(1.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(text = "1,840", style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold, color = CyanDark))
                        Text(text = "Tests Attempted", style = MaterialTheme.typography.labelSmall, color = Slate500)
                    }
                }

                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(1.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(text = "3,250", style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold, color = VioletTertiary))
                        Text(text = "DSA Submissions", style = MaterialTheme.typography.labelSmall, color = Slate500)
                    }
                }
            }
        }

        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Subject Competency Index", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                    Spacer(modifier = Modifier.height(10.dp))
                    DepartmentStatRow("Data Structures & Algorithms", 86, IndigoPrimary)
                    DepartmentStatRow("Quantitative Aptitude", 79, CyanSecondary)
                    DepartmentStatRow("Database Management (DBMS)", 84, SuccessGreen)
                    DepartmentStatRow("Operating Systems & Networks", 73, VioletTertiary)
                    DepartmentStatRow("Logical Reasoning", 88, WarningAmber)
                }
            }
        }
    }
}

@Composable
fun DepartmentStatRow(name: String, percentage: Int, color: Color) {
    Column(modifier = Modifier.padding(vertical = 5.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(name, fontSize = 12.sp, color = Slate700, fontWeight = FontWeight.Medium)
            Text("$percentage%", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = color)
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { percentage / 100f },
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
            color = color,
            trackColor = Slate200
        )
    }
}

// ==========================================
// DIALOGS: ADD QUESTIONS (SHINY & USER FRIENDLY)
// ==========================================

@Composable
fun AddAptitudeQuestionDialog(
    onDismiss: () -> Unit,
    onAdd: (AptitudeQuestion) -> Unit
) {
    var category by remember { mutableStateOf(AptitudeCategory.QUANTITATIVE) }
    var topic by remember { mutableStateOf("Numbers & Arithmetic") }
    var questionText by remember { mutableStateOf("") }
    var opt0 by remember { mutableStateOf("") }
    var opt1 by remember { mutableStateOf("") }
    var opt2 by remember { mutableStateOf("") }
    var opt3 by remember { mutableStateOf("") }
    var correctIndex by remember { mutableStateOf(0) }
    var explanation by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Aptitude Question", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    AptitudeCategory.values().forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat.name, fontSize = 10.sp) }
                        )
                    }
                }
                OutlinedTextField(
                    value = topic,
                    onValueChange = { topic = it },
                    label = { Text("Subcategory (e.g. Profit/Loss, Syllogisms)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = questionText,
                    onValueChange = { questionText = it },
                    label = { Text("Question Statement") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3
                )
                OutlinedTextField(value = opt0, onValueChange = { opt0 = it }, label = { Text("Option A") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = opt1, onValueChange = { opt1 = it }, label = { Text("Option B") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = opt2, onValueChange = { opt2 = it }, label = { Text("Option C") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = opt3, onValueChange = { opt3 = it }, label = { Text("Option D") }, modifier = Modifier.fillMaxWidth())

                Text("Correct Option: Option ${('A'.code + correctIndex).toChar()}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("A", "B", "C", "D").forEachIndexed { index, label ->
                        FilterChip(
                            selected = correctIndex == index,
                            onClick = { correctIndex = index },
                            label = { Text(label) }
                        )
                    }
                }
                OutlinedTextField(
                    value = explanation,
                    onValueChange = { explanation = it },
                    label = { Text("Step-by-step Solution Explanation") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (questionText.isNotBlank() && opt0.isNotBlank()) {
                        onAdd(
                            AptitudeQuestion(
                                id = (System.currentTimeMillis() % 100000).toInt(),
                                category = category,
                                subcategory = topic,
                                difficulty = Difficulty.MEDIUM,
                                question = questionText,
                                options = listOf(opt0, opt1, opt2.ifBlank { "None of these" }, opt3.ifBlank { "All of the above" }),
                                correctIndex = correctIndex,
                                explanation = explanation.ifBlank { "Standard analytical derivation." }
                            )
                        )
                    }
                },
                enabled = questionText.isNotBlank() && opt0.isNotBlank()
            ) {
                Text("Add to Bank")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun AddCodingProblemDialog(
    onDismiss: () -> Unit,
    onAdd: (CodingProblem) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var tags by remember { mutableStateOf("Arrays, Hash Table") }
    var difficulty by remember { mutableStateOf(Difficulty.EASY) }
    var description by remember { mutableStateOf("") }
    var sampleInput by remember { mutableStateOf("[2, 7, 11, 15], target = 9") }
    var sampleOutput by remember { mutableStateOf("[0, 1]") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add DSA Coding Problem", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Problem Title") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = tags,
                    onValueChange = { tags = it },
                    label = { Text("Topics / Subcategory") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Difficulty.values().take(3).forEach { d ->
                        FilterChip(
                            selected = difficulty == d,
                            onClick = { difficulty = d },
                            label = { Text(d.name, fontSize = 10.sp) }
                        )
                    }
                }
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Problem Statement") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 4
                )
                OutlinedTextField(
                    value = sampleInput,
                    onValueChange = { sampleInput = it },
                    label = { Text("Sample Input") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = sampleOutput,
                    onValueChange = { sampleOutput = it },
                    label = { Text("Expected Output") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onAdd(
                            CodingProblem(
                                id = (System.currentTimeMillis() % 100000).toInt(),
                                title = title,
                                topic = tags,
                                difficulty = difficulty,
                                description = description,
                                constraints = "1 <= N <= 10^5, -10^9 <= target <= 10^9",
                                inputFormat = "Array of numbers and target query",
                                outputFormat = "Indices or computed solution value",
                                sampleInput = sampleInput,
                                sampleOutput = sampleOutput,
                                hints = listOf("Consider using a Hash Table or Two Pointers for O(N) complexity"),
                                solutionApproach = "Store visited values in a hash map for amortized O(1) lookups.",
                                starterPython = "def solution(nums, target):\n    # Write your optimal logic here\n    pass",
                                starterJava = "class Solution {\n    public int[] solution(int[] nums, int target) {\n        // Your code\n        return new int[]{};\n    }\n}",
                                starterCpp = "class Solution {\npublic:\n    vector<int> solution(vector<int>& nums, int target) {\n        return {};\n    }\n};",
                                testCases = listOf(
                                    TestCase(sampleInput, sampleOutput)
                                )
                            )
                        )
                    }
                },
                enabled = title.isNotBlank()
            ) {
                Text("Save Problem")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun AddTechnicalQuestionDialog(
    onDismiss: () -> Unit,
    onAdd: (TechnicalQuestion) -> Unit
) {
    var subject by remember { mutableStateOf("DBMS") }
    var question by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Technical CS Question", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("Subject (e.g. DBMS, OS, Networks)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = question,
                    onValueChange = { question = it },
                    label = { Text("Question") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3
                )
                OutlinedTextField(
                    value = answer,
                    onValueChange = { answer = it },
                    label = { Text("Model Conceptual Answer") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 4
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (question.isNotBlank()) {
                        onAdd(
                            TechnicalQuestion(
                                id = (System.currentTimeMillis() % 100000).toInt(),
                                subject = subject,
                                topic = subject,
                                difficulty = Difficulty.MEDIUM,
                                question = question,
                                answer = answer.ifBlank { "Answer details." },
                                keyConcepts = listOf("Core Architecture", "Performance", "Best Practices"),
                                codeSnippet = ""
                            )
                        )
                    }
                },
                enabled = question.isNotBlank()
            ) {
                Text("Save to Bank")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.UserRole
import com.example.ui.components.AppBottomBar
import com.example.ui.components.AppTopBar
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.MainTab
import com.example.ui.viewmodel.PlacementViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val viewModel: PlacementViewModel = viewModel()
                val currentRole by viewModel.currentRole.collectAsState()
                val currentTab by viewModel.currentTab.collectAsState()
                val profile by viewModel.studentProfile.collectAsState()
                val selectedCompany by viewModel.selectedCompany.collectAsState()

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        AppTopBar(
                            currentRole = currentRole,
                            streakDays = profile.currentStreak,
                            totalXP = profile.totalXP,
                            onRoleSelected = { role -> viewModel.setRole(role) }
                        )
                    },
                    bottomBar = {
                        if (currentRole == UserRole.USER) {
                            AppBottomBar(
                                currentTab = currentTab,
                                onTabSelected = { tab -> viewModel.setTab(tab) }
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentRole) {
                            UserRole.ADMIN -> {
                                AdminDashboardScreen(viewModel = viewModel)
                            }
                            UserRole.USER -> {
                                when (currentTab) {
                                    MainTab.DASHBOARD -> DashboardScreen(viewModel = viewModel)
                                    MainTab.PREPARE -> PrepareScreen(viewModel = viewModel)
                                    MainTab.AI_TOOLS -> AiToolsScreen(viewModel = viewModel)
                                    MainTab.PROFILE -> ProfileScreen(viewModel = viewModel)
                                }
                            }
                        }
                    }

                    // Company syllabus / roadmap detail dialog
                    if (selectedCompany != null) {
                        CompanyDetailDialog(
                            company = selectedCompany!!,
                            onDismiss = { viewModel.selectCompany(null) },
                            onPrepareRoadmap = {
                                viewModel.generateCompanyRoadmap(selectedCompany!!.name)
                            }
                        )
                    }
                }
            }
        }
    }
}

package com.example.data.seed

import com.example.data.model.*

object PlacementSeedData {

    val defaultProfile = StudentProfile(
        id = "std_01",
        fullName = "Aditya Sharma",
        email = "aditya.sharma@campus.edu",
        phone = "+91 98765 43210",
        college = "National Institute of Technology",
        university = "State Technical University",
        degree = "B.Tech",
        branch = "Computer Science & Engineering",
        graduationYear = 2026,
        cgpa = 8.42,
        backlogs = 0,
        skills = listOf("Python", "Java", "Data Structures", "Algorithms", "SQL", "DBMS", "Git", "OOP"),
        programmingLanguages = listOf("Python", "Java", "C++"),
        resumeSummary = "Dedicated CS undergrad passionate about backend development, algorithmic problem solving, and distributed software systems.",
        githubUrl = "https://github.com/aditya-dev",
        linkedinUrl = "https://linkedin.com/in/aditya-sharma",
        portfolioUrl = "https://aditya.dev",
        targetCompanies = listOf("Amazon", "TCS", "Accenture", "Microsoft", "Infosys"),
        preparationLevel = "Intermediate",
        currentStreak = 7,
        totalXP = 1450,
        testsCompleted = 12,
        questionsSolved = 86,
        codingProblemsSolved = 28,
        mockInterviewsCompleted = 4,
        isOnboarded = true
    )

    val companies: List<Company> = listOf(
        Company(
            id = "comp_tcs",
            name = "TCS",
            industry = "IT Services & Consulting",
            description = "Tata Consultancy Services is a global leader in IT services, consulting & business solutions.",
            avgPackageLpa = 4.2,
            highestPackageLpa = 11.5,
            minCgpa = 6.0,
            maxBacklogs = 1,
            eligibleBranches = listOf("CSE", "IT", "ECE", "EEE", "Mechanical", "Civil"),
            hiringRoles = listOf("Ninja Developer (3.6 LPA)", "Digital Developer (7.0 LPA)", "Prime Developer (9-11 LPA)"),
            requiredSkills = listOf("C/C++", "Java", "Python", "SQL", "Aptitude", "Communication"),
            selectionRounds = listOf("TCS NQT (Foundation + Advanced)", "Technical Interview", "Managerial / HR Round"),
            aptitudePattern = "80 mins: Numerical Ability (20 Qs), Verbal Ability (25 Qs), Reasoning Ability (20 Qs)",
            codingPattern = "Hands-on Coding: 2 problems (1 easy, 1 medium/advanced) in 45 mins",
            technicalFocus = "Core CS fundamentals (OOP, DBMS, SQL), Data structures basics, Final year academic project",
            hrFocus = "Willingness to relocate, shift flexibility, communication confidence, situational ethics"
        ),
        Company(
            id = "comp_amazon",
            name = "Amazon",
            industry = "E-Commerce & Cloud (FAANG)",
            description = "Amazon is guided by four principles: customer obsession, passion for invention, and operational excellence.",
            avgPackageLpa = 18.5,
            highestPackageLpa = 45.0,
            minCgpa = 7.0,
            maxBacklogs = 0,
            eligibleBranches = listOf("CSE", "IT", "ECE", "EEE"),
            hiringRoles = listOf("Software Development Engineer (SDE-1)", "Quality Assurance Engineer (QAE)", "Cloud Support Associate"),
            requiredSkills = listOf("Data Structures", "Algorithms", "Java/C++", "System Design Basics", "Operating Systems", "Concurrency"),
            selectionRounds = listOf("Online Assessment (Coding + Work Styles)", "Technical Interview 1 (DSA)", "Technical Interview 2 (DSA + OS)", "Bar Raiser (Leadership Principles)"),
            aptitudePattern = "Amazon Work Style Assessment (simulated workplace decision scenarios)",
            codingPattern = "2 complex DSA problems on Trees, Graphs, or Dynamic Programming in 70 mins",
            technicalFocus = "Deep algorithmic complexity, space/time trade-offs, edge cases, object-oriented design",
            hrFocus = "Amazon's 16 Leadership Principles (Customer Obsession, Ownership, Bias for Action, Deliver Results)"
        ),
        Company(
            id = "comp_infosys",
            name = "Infosys",
            industry = "IT Services & Digital Transformation",
            description = "A global leader in next-generation digital services and consulting operating in 50+ countries.",
            avgPackageLpa = 4.0,
            highestPackageLpa = 9.5,
            minCgpa = 6.5,
            maxBacklogs = 0,
            eligibleBranches = listOf("CSE", "IT", "ECE", "EEE", "Mechanical"),
            hiringRoles = listOf("Systems Engineer (3.6 LPA)", "Specialist Programmer (9.5 LPA)", "Digital Specialist Engineer (6.25 LPA)"),
            requiredSkills = listOf("Python", "Java", "Data Structures", "SQL", "Aptitude", "Logical Reasoning"),
            selectionRounds = listOf("InfyTQ / HackWithInfy / Campus Assessment", "Technical Interview", "HR Interview"),
            aptitudePattern = "Reasoning Ability (15 Qs), Mathematical Ability (10 Qs), Verbal Ability (20 Qs), Pseudocode (5 Qs)",
            codingPattern = "Hands-on Coding: 2 problems (arrays, strings, greedy algorithms)",
            technicalFocus = "Object-Oriented Programming, Database queries, Logic puzzles, project architecture",
            hrFocus = "Adaptability to tech stacks, interpersonal skills, company values and learning mindset"
        ),
        Company(
            id = "comp_accenture",
            name = "Accenture",
            industry = "Management Consulting & Technology Services",
            description = "Global professional services company with leading capabilities in digital, cloud and security.",
            avgPackageLpa = 4.5,
            highestPackageLpa = 12.0,
            minCgpa = 6.5,
            maxBacklogs = 1,
            eligibleBranches = listOf("All Engineering Branches"),
            hiringRoles = listOf("Associate Software Engineer (ASE - 4.5 LPA)", "Advanced ASE (6.5 LPA)"),
            requiredSkills = listOf("Cognitive & Technical Aptitude", "Pseudocode", "Common Apps & MS Office", "Coding"),
            selectionRounds = listOf("Cognitive & Technical Assessment", "Coding Assessment", "Communication Assessment", "Interview"),
            aptitudePattern = "90 Qs in 90 mins: Critical Thinking, Abstract Reasoning, Technical & Cloud fundamentals",
            codingPattern = "2 questions in 45 minutes (string manipulation, math/array logic)",
            technicalFocus = "Cloud computing basics, networking, security fundamentals, pseudocode trace",
            hrFocus = "Communication round: reading, repeating, questions & speaking for 20 mins"
        ),
        Company(
            id = "comp_wipro",
            name = "Wipro",
            industry = "Information Technology & Business Process",
            description = "Leading technology services and consulting company focused on building innovative solutions.",
            avgPackageLpa = 3.8,
            highestPackageLpa = 7.5,
            minCgpa = 6.0,
            maxBacklogs = 1,
            eligibleBranches = listOf("CSE", "IT", "ECE", "EEE"),
            hiringRoles = listOf("Project Engineer (Elite - 3.5 LPA)", "Turbo Engineer (6.5 LPA)"),
            requiredSkills = listOf("C", "Java", "Python", "Data Structures", "Quantitative Aptitude", "Essay Writing"),
            selectionRounds = listOf("Wipro Elite NLTH Test", "Business Discussion (Technical + HR Combined)"),
            aptitudePattern = "Logical, Quantitative, Verbal + Written Communication (Essay Writing)",
            codingPattern = "2 coding questions: 1 basic logic, 1 data structure problem",
            technicalFocus = "Core engineering subjects, data structures, SQL and basic algorithm complexity",
            hrFocus = "Willingness to learn new frameworks, teamwork, project role clarity"
        ),
        Company(
            id = "comp_cognizant",
            name = "Cognizant",
            industry = "IT Services & Digital Operations",
            description = "Cognizant engineers modern businesses to improve everyday life in the digital era.",
            avgPackageLpa = 4.2,
            highestPackageLpa = 8.5,
            minCgpa = 6.0,
            maxBacklogs = 0,
            eligibleBranches = listOf("CSE", "IT", "ECE", "EEE"),
            hiringRoles = listOf("GenC (4.0 LPA)", "GenC Elevate (4.5 LPA)", "GenC Next (6.75 LPA)"),
            requiredSkills = listOf("Java", "Python", "Full Stack", "Data Structures", "DBMS", "Cloud"),
            selectionRounds = listOf("Cognitive Assessment", "Skill-based Coding / Tech Assessment", "Technical & HR Interview"),
            aptitudePattern = "Quantitative, Analytical, Verbal + Skill-specific MCQs",
            codingPattern = "Algorithmic challenges focusing on hashing, arrays, and greedy approaches",
            technicalFocus = "Hands-on coding execution, DBMS normalization, API basics",
            hrFocus = "Career goals, professional demeanor, team collaboration scenarios"
        ),
        Company(
            id = "comp_capgemini",
            name = "Capgemini",
            industry = "Consulting, Technology & Engineering Services",
            description = "A global leader in partnering with companies to transform and manage their business through technology.",
            avgPackageLpa = 4.0,
            highestPackageLpa = 7.5,
            minCgpa = 6.0,
            maxBacklogs = 0,
            eligibleBranches = listOf("CSE", "IT", "ECE", "EEE"),
            hiringRoles = listOf("Software Analyst (4.0 LPA)", "Senior Analyst (5.75 LPA)"),
            requiredSkills = listOf("Pseudocode", "English Communication", "Game-Based Aptitude", "Behavioral"),
            selectionRounds = listOf("Technical Assessment (Pseudocode)", "English Test", "Game-based Aptitude", "Coding", "Interview"),
            aptitudePattern = "Unique game-based aptitude testing reaction time, memory, deductive logic",
            codingPattern = "2 coding challenges on standard algorithms",
            technicalFocus = "Pseudocode debugging, OOP concepts, C/C++ memory management",
            hrFocus = "Value alignment, conflict resolution, client-centric perspective"
        ),
        Company(
            id = "comp_deloitte",
            name = "Deloitte",
            industry = "Audit, Consulting, Advisory & Tax",
            description = "One of the Big Four accounting and professional services networks in the world.",
            avgPackageLpa = 7.6,
            highestPackageLpa = 14.0,
            minCgpa = 6.5,
            maxBacklogs = 0,
            eligibleBranches = listOf("CSE", "IT", "ECE", "All Engineering"),
            hiringRoles = listOf("Analyst - Technology Consulting (7.6 LPA)", "Risk Advisory Analyst"),
            requiredSkills = listOf("Quantitative Aptitude", "Critical Reasoning", "Business Awareness", "SQL/Python"),
            selectionRounds = listOf("Online Aptitude & Reasoning Test", "Technical Assessment", "Case Study / Technical Interview", "HR Round"),
            aptitudePattern = "Advanced quantitative analysis, data interpretation, verbal ability",
            codingPattern = "Light coding / SQL queries / algorithmic pseudocode",
            technicalFocus = "Database architecture, enterprise IT, software development life cycle",
            hrFocus = "Case studies, business consulting mindset, presentation ability"
        ),
        Company(
            id = "comp_microsoft",
            name = "Microsoft",
            industry = "Technology & Cloud Computing (FAANG)",
            description = "Empowering every person and every organization on the planet to achieve more.",
            avgPackageLpa = 24.0,
            highestPackageLpa = 52.0,
            minCgpa = 7.5,
            maxBacklogs = 0,
            eligibleBranches = listOf("CSE", "IT", "ECE"),
            hiringRoles = listOf("Software Engineer (SWE-1)", "Program Manager", "Support Engineer"),
            requiredSkills = listOf("Advanced Algorithms", "Dynamic Programming", "Trees & Graphs", "System Design", "OS & Multithreading"),
            selectionRounds = listOf("Online Coding Test (Codility)", "Technical Interview 1 (DSA)", "Technical Interview 2 (System & Architecture)", "Technical & Cultural Fit"),
            aptitudePattern = "No general aptitude - pure algorithm and engineering tests",
            codingPattern = "3 hard algorithmic problems in 90 minutes",
            technicalFocus = "Scalability, memory safety, concurrency, caching, optimal time complexity",
            hrFocus = "Growth mindset, handling failure, collaboration across global teams"
        ),
        Company(
            id = "comp_google",
            name = "Google",
            industry = "Internet & Software Technology (FAANG)",
            description = "Organizing the world's information and making it universally accessible and useful.",
            avgPackageLpa = 32.0,
            highestPackageLpa = 60.0,
            minCgpa = 7.5,
            maxBacklogs = 0,
            eligibleBranches = listOf("CSE", "IT", "ECE"),
            hiringRoles = listOf("Software Engineer (SWE L3)", "Site Reliability Engineer", "Associate Product Manager"),
            requiredSkills = listOf("Complex Data Structures", "Graph Theory", "Dynamic Programming", "Mathematics", "System Architecture"),
            selectionRounds = listOf("Google Online Challenge (GOC)", "Technical Phone Screen", "3-4 Onsite/Virtual Coding Rounds", "Googleyness & Leadership"),
            aptitudePattern = "No aptitude - focus on computational complexity and problem formulation",
            codingPattern = "2 high-difficulty algorithmic challenges in 60 mins",
            technicalFocus = "Clean code writing on Google Docs/whiteboard without IDE auto-complete",
            hrFocus = "Googleyness: intellectual humility, doing the right thing, dealing with ambiguity"
        )
    )

    val aptitudeQuestions: List<AptitudeQuestion> = listOf(
        // Quantitative
        AptitudeQuestion(
            id = 1,
            category = AptitudeCategory.QUANTITATIVE,
            subcategory = "Percentages",
            difficulty = Difficulty.EASY,
            question = "If the price of petrol increases by 25%, by what percentage must a person reduce his consumption so that expenditure remains unchanged?",
            options = listOf("15%", "20%", "25%", "30%"),
            correctIndex = 1,
            explanation = "Reduction % = [R / (100 + R)] * 100 = [25 / 125] * 100 = 1/5 * 100 = 20%.",
            formulaOrHint = "Expenditure = Price * Consumption. If price becomes 1.25P, consumption must become P/(1.25) = 0.8C (20% drop)."
        ),
        AptitudeQuestion(
            id = 2,
            category = AptitudeCategory.QUANTITATIVE,
            subcategory = "Profit and Loss",
            difficulty = Difficulty.MEDIUM,
            question = "A shopkeeper marks his goods 30% above cost price and allows a discount of 15% on the marked price. What is his net gain percentage?",
            options = listOf("10.5%", "12%", "15%", "10.0%"),
            correctIndex = 0,
            explanation = "Let CP = 100. Marked Price MP = 130. Selling Price SP = 130 * (1 - 0.15) = 130 * 0.85 = 110.5. Gain = 110.5 - 100 = 10.5%.",
            formulaOrHint = "Net % = x - y - (x*y)/100 = 30 - 15 - (30*15)/100 = 15 - 4.5 = 10.5%."
        ),
        AptitudeQuestion(
            id = 3,
            category = AptitudeCategory.QUANTITATIVE,
            subcategory = "Time and Work",
            difficulty = Difficulty.MEDIUM,
            question = "A can finish a work in 12 days and B can do it in 16 days. They worked together for 4 days and then A left. How many days will B take to complete the remaining work?",
            options = listOf("6 days", "6.67 days", "7 days", "8 days"),
            correctIndex = 1,
            explanation = "A's 1-day work = 1/12, B's = 1/16. Together 1 day = 1/12 + 1/16 = 7/48. In 4 days work done = 4 * 7/48 = 28/48 = 7/12. Remaining work = 1 - 7/12 = 5/12. Time taken by B = (5/12) / (1/16) = (5/12) * 16 = 20/3 = 6.67 days.",
            formulaOrHint = "Work = Rate * Time. Remaining Work / B's rate = (5/12)/(1/16)."
        ),
        AptitudeQuestion(
            id = 4,
            category = AptitudeCategory.QUANTITATIVE,
            subcategory = "Time Speed Distance",
            difficulty = Difficulty.EASY,
            question = "A train 180 meters long is traveling at 72 km/h. How many seconds does it take to cross an electric pole?",
            options = listOf("7 sec", "8 sec", "9 sec", "10 sec"),
            correctIndex = 2,
            explanation = "Speed in m/s = 72 * (5/18) = 20 m/s. Time = Distance / Speed = 180 / 20 = 9 seconds.",
            formulaOrHint = "Multiply km/h by 5/18 to convert into meters/second."
        ),
        AptitudeQuestion(
            id = 5,
            category = AptitudeCategory.QUANTITATIVE,
            subcategory = "Simple & Compound Interest",
            difficulty = Difficulty.HARD,
            question = "The difference between Compound Interest and Simple Interest on a certain sum of money for 2 years at 10% per annum is ₹150. Find the principal sum.",
            options = listOf("₹12,000", "₹14,500", "₹15,000", "₹18,000"),
            correctIndex = 2,
            explanation = "For 2 years, Difference = P * (R / 100)^2. Here, 150 = P * (10 / 100)^2 => 150 = P * (1/100) => P = 150 * 100 = ₹15,000.",
            formulaOrHint = "Difference (2 yrs) = P * (r/100)^2."
        ),
        AptitudeQuestion(
            id = 6,
            category = AptitudeCategory.QUANTITATIVE,
            subcategory = "Probability",
            difficulty = Difficulty.MEDIUM,
            question = "Two dice are rolled simultaneously. What is the probability of getting a sum divisible by 4?",
            options = listOf("1/4", "1/6", "5/36", "7/36"),
            correctIndex = 0,
            explanation = "Total outcomes = 36. Sums divisible by 4 are 4, 8, 12. Sum 4: (1,3),(2,2),(3,1) [3]. Sum 8: (2,6),(3,5),(4,4),(5,3),(6,2) [5]. Sum 12: (6,6) [1]. Total favorable = 3 + 5 + 1 = 9. Probability = 9/36 = 1/4.",
            formulaOrHint = "Favorable outcomes / Total outcomes (36)."
        ),
        AptitudeQuestion(
            id = 7,
            category = AptitudeCategory.QUANTITATIVE,
            subcategory = "Averages",
            difficulty = Difficulty.EASY,
            question = "The average of 5 consecutive odd numbers is 27. What is the largest of these numbers?",
            options = listOf("29", "31", "33", "35"),
            correctIndex = 1,
            explanation = "In consecutive odd numbers, the middle number is the average. Middle (3rd) number = 27. The numbers are 23, 25, 27, 29, 31. Largest = 31.",
            formulaOrHint = "For symmetric sequences with odd count, Mean = Median."
        ),
        AptitudeQuestion(
            id = 8,
            category = AptitudeCategory.QUANTITATIVE,
            subcategory = "Ratio and Proportion",
            difficulty = Difficulty.EASY,
            question = "If A : B = 3 : 4 and B : C = 8 : 9, what is A : C?",
            options = listOf("1 : 2", "2 : 3", "3 : 5", "4 : 5"),
            correctIndex = 1,
            explanation = "A/C = (A/B) * (B/C) = (3/4) * (8/9) = 24/36 = 2/3. Hence, A : C = 2 : 3.",
            formulaOrHint = "Multiply ratios: (A/B) * (B/C) = A/C."
        ),

        // Logical Reasoning
        AptitudeQuestion(
            id = 9,
            category = AptitudeCategory.LOGICAL,
            subcategory = "Number Series",
            difficulty = Difficulty.MEDIUM,
            question = "Find the missing number in the series: 2, 6, 12, 20, 30, 42, ?",
            options = listOf("52", "54", "56", "58"),
            correctIndex = 2,
            explanation = "Pattern is n * (n + 1): 1*2=2, 2*3=6, 3*4=12, 4*5=20, 5*6=30, 6*7=42. Next is 7*8 = 56. Alternatively differences are +4, +6, +8, +10, +12, +14 -> 42 + 14 = 56.",
            formulaOrHint = "Look at consecutive differences: 4, 6, 8, 10, 12, 14."
        ),
        AptitudeQuestion(
            id = 10,
            category = AptitudeCategory.LOGICAL,
            subcategory = "Blood Relations",
            difficulty = Difficulty.MEDIUM,
            question = "Pointing to a photograph, Rohit said, 'She is the daughter of my grandfather's only son.' How is the girl related to Rohit?",
            options = listOf("Mother", "Sister", "Cousin", "Aunt"),
            correctIndex = 1,
            explanation = "Rohit's grandfather's only son is Rohit's father. Daughter of Rohit's father is Rohit's sister.",
            formulaOrHint = "Break down relations from innermost phrase: 'grandfather's only son' = Father."
        ),
        AptitudeQuestion(
            id = 11,
            category = AptitudeCategory.LOGICAL,
            subcategory = "Coding-Decoding",
            difficulty = Difficulty.EASY,
            question = "In a certain code language, 'LEARN' is coded as 'OHDUQ'. How will 'TRAIN' be coded in that same language?",
            options = listOf("WUGLQ", "WUDLQ", "WUDLR", "VTDKQ"),
            correctIndex = 1,
            explanation = "Each letter is shifted forward by +3: L(+3)=O, E(+3)=H, A(+3)=D, R(+3)=U, N(+3)=Q. For 'TRAIN': T(+3)=W, R(+3)=U, A(+3)=D, I(+3)=L, N(+3)=Q -> 'WUDLQ'.",
            formulaOrHint = "Letter shift: +3 positions in alphabet."
        ),
        AptitudeQuestion(
            id = 12,
            category = AptitudeCategory.LOGICAL,
            subcategory = "Directions",
            difficulty = Difficulty.MEDIUM,
            question = "A man walks 6 km North, turns right and walks 8 km. How far is he from his starting point, and in which direction?",
            options = listOf("10 km North-East", "10 km South-East", "14 km North-East", "12 km North"),
            correctIndex = 0,
            explanation = "Using Pythagoras theorem: Distance = sqrt(6^2 + 8^2) = sqrt(36 + 64) = sqrt(100) = 10 km. He is in the North-East direction from start.",
            formulaOrHint = "Pythagorean triplet (6, 8, 10)."
        ),
        AptitudeQuestion(
            id = 13,
            category = AptitudeCategory.LOGICAL,
            subcategory = "Syllogisms",
            difficulty = Difficulty.HARD,
            question = "Statements: Some pens are books. All books are papers.\nConclusions:\nI. Some pens are papers.\nII. All papers are pens.",
            options = listOf("Only conclusion I follows", "Only conclusion II follows", "Both follow", "Neither follows"),
            correctIndex = 0,
            explanation = "Some pens are books and All books are papers implies that the portion of pens that are books are also papers. Thus 'Some pens are papers' is definitely true. But we cannot say all papers are pens.",
            formulaOrHint = "Draw Euler circles: Pen intersects Book, Book is fully inside Paper."
        ),

        // Verbal Ability
        AptitudeQuestion(
            id = 14,
            category = AptitudeCategory.VERBAL,
            subcategory = "Synonyms",
            difficulty = Difficulty.EASY,
            question = "Select the word that is most nearly identical in meaning to: 'PRAGMATIC'",
            options = listOf("Theoretical", "Practical", "Idealistic", "Fanciful"),
            correctIndex = 1,
            explanation = "'Pragmatic' means dealing with things sensibly and realistically based on practical rather than theoretical considerations. Synonym is 'Practical'.",
            formulaOrHint = "Pragmatic = realistic, down-to-earth, sensible."
        ),
        AptitudeQuestion(
            id = 15,
            category = AptitudeCategory.VERBAL,
            subcategory = "Antonyms",
            difficulty = Difficulty.MEDIUM,
            question = "Choose the word most opposite in meaning to: 'METICULOUS'",
            options = listOf("Careful", "Diligent", "Careless", "Thorough"),
            correctIndex = 2,
            explanation = "'Meticulous' means showing great attention to detail; very careful and precise. The opposite is 'Careless'.",
            formulaOrHint = "Meticulous = extremely careful, antonym = sloppy / careless."
        ),
        AptitudeQuestion(
            id = 16,
            category = AptitudeCategory.VERBAL,
            subcategory = "Sentence Correction",
            difficulty = Difficulty.MEDIUM,
            question = "Identify the error in: 'Neither the manager nor the employees was present at the annual tech convention.'",
            options = listOf("Neither", "nor", "was present", "at the"),
            correctIndex = 2,
            explanation = "In 'Neither... nor' constructions, the verb agrees with the closer subject. 'employees' is plural, so it should be 'were present' instead of 'was present'.",
            formulaOrHint = "Proximity rule for compound subjects connected by 'or' / 'nor'."
        )
    )

    val codingProblems: List<CodingProblem> = listOf(
        CodingProblem(
            id = 1,
            title = "Two Sum",
            topic = "Arrays & Hashing",
            difficulty = Difficulty.EASY,
            description = "Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target.\nYou may assume that each input would have exactly one solution, and you may not use the same element twice.",
            constraints = "2 <= nums.length <= 10^4\n-10^9 <= nums[i] <= 10^9\nOnly one valid answer exists.",
            inputFormat = "nums = [2,7,11,15], target = 9",
            outputFormat = "[0,1]",
            sampleInput = "nums = [2, 7, 11, 15], target = 9",
            sampleOutput = "[0, 1]",
            hints = listOf(
                "Can you use a Hash Map to store seen numbers and their indices?",
                "For every number x, check if (target - x) already exists in the map."
            ),
            solutionApproach = "We traverse the array once while storing each element and its index in a hash map. For each element x, we check if target - x exists in our hash map in O(1) time. Total time complexity: O(N), Space complexity: O(N).",
            starterPython = "def twoSum(nums, target):\n    # Write your solution here\n    seen = {}\n    for i, num in enumerate(nums):\n        diff = target - num\n        if diff in seen:\n            return [seen[diff], i]\n        seen[num] = i\n    return []",
            starterJava = "class Solution {\n    public int[] twoSum(int[] nums, int target) {\n        // Write your solution here\n        Map<Integer, Integer> map = new HashMap<>();\n        for (int i = 0; i < nums.length; i++) {\n            int diff = target - nums[i];\n            if (map.containsKey(diff)) {\n                return new int[] { map.get(diff), i };\n            }\n            map.put(nums[i], i);\n        }\n        return new int[]{};\n    }\n}",
            starterCpp = "class Solution {\npublic:\n    vector<int> twoSum(vector<int>& nums, int target) {\n        unordered_map<int, int> mp;\n        for (int i = 0; i < nums.size(); i++) {\n            int diff = target - nums[i];\n            if (mp.count(diff)) return {mp[diff], i};\n            mp[nums[i]] = i;\n        }\n        return {};\n    }\n};",
            testCases = listOf(
                TestCase("nums = [2,7,11,15], target = 9", "[0, 1]"),
                TestCase("nums = [3,2,4], target = 6", "[1, 2]"),
                TestCase("nums = [3,3], target = 6", "[0, 1]")
            ),
            isSolved = true
        ),
        CodingProblem(
            id = 2,
            title = "Valid Palindrome",
            topic = "Strings & Two Pointers",
            difficulty = Difficulty.EASY,
            description = "A phrase is a palindrome if, after converting all uppercase letters into lowercase letters and removing all non-alphanumeric characters, it reads the same forward and backward.",
            constraints = "1 <= s.length <= 2 * 10^5\ns consists only of printable ASCII characters.",
            inputFormat = "s = \"A man, a plan, a canal: Panama\"",
            outputFormat = "true",
            sampleInput = "s = \"A man, a plan, a canal: Panama\"",
            sampleOutput = "true",
            hints = listOf(
                "Use two pointers: one at the start and one at the end.",
                "Skip non-alphanumeric characters and compare lowercase versions."
            ),
            solutionApproach = "Initialize two pointers left = 0 and right = len - 1. Increment left and decrement right while skipping non-alphanumerics. Compare characters. Time: O(N), Space: O(1).",
            starterPython = "def isPalindrome(s: str) -> bool:\n    left, right = 0, len(s) - 1\n    while left < right:\n        while left < right and not s[left].isalnum():\n            left += 1\n        while left < right and not s[right].isalnum():\n            right -= 1\n        if s[left].lower() != s[right].lower():\n            return false\n        left += 1\n        right -= 1\n    return True",
            starterJava = "class Solution {\n    public boolean isPalindrome(String s) {\n        int i = 0, j = s.length() - 1;\n        while (i < j) {\n            while (i < j && !Character.isLetterOrDigit(s.charAt(i))) i++;\n            while (i < j && !Character.isLetterOrDigit(s.charAt(j))) j--;\n            if (Character.toLowerCase(s.charAt(i)) != Character.toLowerCase(s.charAt(j))) return false;\n            i++; j--;\n        }\n        return true;\n    }\n}",
            starterCpp = "class Solution {\npublic:\n    bool isPalindrome(string s) {\n        int i = 0, j = s.size() - 1;\n        while (i < j) {\n            while (i < j && !isalnum(s[i])) i++;\n            while (i < j && !isalnum(s[j])) j--;\n            if (tolower(s[i]) != tolower(s[j])) return false;\n            i++; j--;\n        }\n        return true;\n    }\n};",
            testCases = listOf(
                TestCase("s = \"A man, a plan, a canal: Panama\"", "true"),
                TestCase("s = \"race a car\"", "false"),
                TestCase("s = \" \"", "true")
            ),
            isSolved = true
        ),
        CodingProblem(
            id = 3,
            title = "Longest Substring Without Repeating Characters",
            topic = "Sliding Window",
            difficulty = Difficulty.MEDIUM,
            description = "Given a string s, find the length of the longest substring without duplicate characters.",
            constraints = "0 <= s.length <= 5 * 10^4\ns consists of English letters, digits, symbols and spaces.",
            inputFormat = "s = \"abcabcbb\"",
            outputFormat = "3",
            sampleInput = "s = \"abcabcbb\"",
            sampleOutput = "3",
            hints = listOf(
                "Think of a sliding window bounded by left and right pointers.",
                "Store the last seen index of each character in a map to jump the left pointer."
            ),
            solutionApproach = "Use a sliding window [left, right] with a hash map of character to its most recent index. When right sees an existing char inside the current window, advance left to map[char] + 1. Time: O(N), Space: O(min(N, charset)).",
            starterPython = "def lengthOfLongestSubstring(s: str) -> int:\n    char_map = {}\n    left = 0\n    max_len = 0\n    for right, ch in enumerate(s):\n        if ch in char_map and char_map[ch] >= left:\n            left = char_map[ch] + 1\n        char_map[ch] = right\n        max_len = max(max_len, right - left + 1)\n    return max_len",
            starterJava = "class Solution {\n    public int lengthOfLongestSubstring(String s) {\n        Map<Character, Integer> map = new HashMap<>();\n        int left = 0, maxLen = 0;\n        for (int right = 0; right < s.length(); right++) {\n            char ch = s.charAt(right);\n            if (map.containsKey(ch) && map.get(ch) >= left) {\n                left = map.get(ch) + 1;\n            }\n            map.put(ch, right);\n            maxLen = Math.max(maxLen, right - left + 1);\n        }\n        return maxLen;\n    }\n}",
            starterCpp = "class Solution {\npublic:\n    int lengthOfLongestSubstring(string s) {\n        unordered_map<char, int> mp;\n        int left = 0, maxLen = 0;\n        for (int right = 0; right < s.size(); right++) {\n            if (mp.count(s[right]) && mp[s[right]] >= left) {\n                left = mp[s[right]] + 1;\n            }\n            mp[s[right]] = right;\n            maxLen = max(maxLen, right - left + 1);\n        }\n        return maxLen;\n    }\n};",
            testCases = listOf(
                TestCase("s = \"abcabcbb\"", "3"),
                TestCase("s = \"bbbbb\"", "1"),
                TestCase("s = \"pwwkew\"", "3")
            ),
            isSolved = false
        ),
        CodingProblem(
            id = 4,
            title = "Maximum Subarray (Kadane's Algorithm)",
            topic = "Dynamic Programming",
            difficulty = Difficulty.MEDIUM,
            description = "Given an integer array nums, find the contiguous subarray (containing at least one number) which has the largest sum and return its sum.",
            constraints = "1 <= nums.length <= 10^5\n-10^4 <= nums[i] <= 10^4",
            inputFormat = "nums = [-2,1,-3,4,-1,2,1,-5,4]",
            outputFormat = "6",
            sampleInput = "nums = [-2,1,-3,4,-1,2,1,-5,4]",
            sampleOutput = "6 (subarray [4,-1,2,1])",
            hints = listOf(
                "If the current accumulated sum becomes negative, reset it to 0.",
                "Keep track of the overall maximum sum encountered so far."
            ),
            solutionApproach = "Kadane's algorithm: at each position, choose between extending the current subarray or starting a new subarray from the current element. maxCurrent = max(num, maxCurrent + num). Time: O(N), Space: O(1).",
            starterPython = "def maxSubArray(nums: list[int]) -> int:\n    max_so_far = nums[0]\n    curr_max = nums[0]\n    for x in nums[1:]:\n        curr_max = max(x, curr_max + x)\n        max_so_far = max(max_so_far, curr_max)\n    return max_so_far",
            starterJava = "class Solution {\n    public int maxSubArray(int[] nums) {\n        int maxSoFar = nums[0], currMax = nums[0];\n        for (int i = 1; i < nums.length; i++) {\n            currMax = Math.max(nums[i], currMax + nums[i]);\n            maxSoFar = Math.max(maxSoFar, currMax);\n        }\n        return maxSoFar;\n    }\n}",
            starterCpp = "class Solution {\npublic:\n    int maxSubArray(vector<int>& nums) {\n        int maxSoFar = nums[0], currMax = nums[0];\n        for (int i = 1; i < nums.size(); i++) {\n            currMax = max(nums[i], currMax + nums[i]);\n            maxSoFar = max(maxSoFar, currMax);\n        }\n        return maxSoFar;\n    }\n};",
            testCases = listOf(
                TestCase("nums = [-2,1,-3,4,-1,2,1,-5,4]", "6"),
                TestCase("nums = [1]", "1"),
                TestCase("nums = [5,4,-1,7,8]", "23")
            ),
            isSolved = true
        ),
        CodingProblem(
            id = 5,
            title = "Reverse Linked List",
            topic = "Linked Lists",
            difficulty = Difficulty.EASY,
            description = "Given the head of a singly linked list, reverse the list, and return the reversed list.",
            constraints = "The number of nodes in the list is in the range [0, 5000].\n-5000 <= Node.val <= 5000",
            inputFormat = "head = [1,2,3,4,5]",
            outputFormat = "[5,4,3,2,1]",
            sampleInput = "head = [1,2,3,4,5]",
            sampleOutput = "[5,4,3,2,1]",
            hints = listOf(
                "Maintain three pointers: prev (null), curr (head), and nextNode.",
                "Update curr.next = prev in a loop until curr is null."
            ),
            solutionApproach = "Iterative 3-pointer method. Reverse pointer directions step by step. Time: O(N), Space: O(1).",
            starterPython = "# class ListNode:\n#     def __init__(self, val=0, next=None):\n#         self.val = val\n#         self.next = next\ndef reverseList(head):\n    prev = None\n    curr = head\n    while curr:\n        nxt = curr.next\n        curr.next = prev\n        prev = curr\n        curr = nxt\n    return prev",
            starterJava = "class Solution {\n    public ListNode reverseList(ListNode head) {\n        ListNode prev = null;\n        ListNode curr = head;\n        while (curr != null) {\n            ListNode next = curr.next;\n            curr.next = prev;\n            prev = curr;\n            curr = next;\n        }\n        return prev;\n    }\n}",
            starterCpp = "class Solution {\npublic:\n    ListNode* reverseList(ListNode* head) {\n        ListNode *prev = nullptr, *curr = head;\n        while (curr) {\n            ListNode* next = curr->next;\n            curr->next = prev;\n            prev = curr;\n            curr = next;\n        }\n        return prev;\n    }\n};",
            testCases = listOf(
                TestCase("head = [1,2,3,4,5]", "[5,4,3,2,1]"),
                TestCase("head = [1,2]", "[2,1]"),
                TestCase("head = []", "[]")
            ),
            isSolved = false
        )
    )

    val technicalQuestions: List<TechnicalQuestion> = listOf(
        TechnicalQuestion(
            id = 1,
            subject = "OOP",
            topic = "Core Principles",
            difficulty = Difficulty.BEGINNER,
            question = "Explain the four pillars of Object-Oriented Programming with real-world examples.",
            answer = "1. Encapsulation: Bundling data and methods into a single unit (class) and restricting direct access using access modifiers (e.g. Bank Account with private balance).\n2. Abstraction: Hiding internal implementation details and showing only essential features to the user (e.g. driving a car by using pedals without knowing internal combustion thermodynamics).\n3. Inheritance: Mechanism where a child class acquires properties and behaviors of a parent class (e.g. ElectricCar extends Vehicle).\n4. Polymorphism: Ability of an entity to take multiple forms—either Compile-time (Method Overloading) or Runtime (Method Overriding) (e.g. shape.draw() calls Circle.draw() or Square.draw()).",
            keyConcepts = listOf("Encapsulation", "Abstraction", "Inheritance", "Polymorphism", "Dynamic Dispatch")
        ),
        TechnicalQuestion(
            id = 2,
            subject = "DBMS",
            topic = "Transactions",
            difficulty = Difficulty.INTERMEDIATE,
            question = "What are ACID properties in database systems? Why are they vital?",
            answer = "ACID guarantees transactional integrity in relational databases:\n- Atomicity: 'All or nothing'. Either the entire transaction succeeds, or it rolls back completely.\n- Consistency: Database moves from one valid state to another, upholding all constraints, cascades, and rules.\n- Isolation: Concurrent transactions execute independently without interfering with each other (isolation levels: Read Uncommitted, Read Committed, Repeatable Read, Serializable).\n- Durability: Once a transaction commits, its changes survive system crashes and power failures (guaranteed via Write-Ahead Logging WAL).",
            keyConcepts = listOf("Atomicity", "Consistency", "Isolation", "Durability", "WAL", "Transaction Rollback")
        ),
        TechnicalQuestion(
            id = 3,
            subject = "Operating Systems",
            topic = "Concurrency",
            difficulty = Difficulty.INTERMEDIATE,
            question = "What is a Deadlock? What are the four Coffman conditions necessary for a deadlock to occur?",
            answer = "A Deadlock is a state where a set of processes are blocked because each process is holding a resource and waiting for another resource held by another process.\nFour Coffman Conditions:\n1. Mutual Exclusion: At least one resource must be held in a non-shareable mode.\n2. Hold and Wait: A process is holding at least one resource and waiting to acquire additional resources.\n3. No Preemption: Resources cannot be forcefully taken away from a process.\n4. Circular Wait: A closed loop exists where P0 waits for P1, P1 waits for P2... and Pn waits for P0.",
            keyConcepts = listOf("Deadlock", "Mutual Exclusion", "Hold and Wait", "No Preemption", "Circular Wait", "Banker's Algorithm")
        ),
        TechnicalQuestion(
            id = 4,
            subject = "Computer Networks",
            topic = "Protocols",
            difficulty = Difficulty.INTERMEDIATE,
            question = "What happens when you type https://google.com into your browser and press Enter?",
            answer = "1. Browser checks caches (Browser cache -> OS cache -> Router cache -> DNS resolver).\n2. DNS Resolution: Queries Root, TLD (.com), and Authoritative servers to resolve IP.\n3. TCP 3-Way Handshake: Client sends SYN, Server replies SYN-ACK, Client sends ACK.\n4. TLS Handshake: Client and server exchange cipher suites, verify SSL/TLS certificate, exchange session keys.\n5. HTTP Request: Client sends encrypted GET request.\n6. Server processing: Web server/load balancer routes request to application server which fetches data.\n7. HTTP Response: Server responds with status code (200 OK) and HTML/CSS/JS payload.\n8. Browser rendering: DOM tree, CSSOM, Render tree, layout, and paint occur.",
            keyConcepts = listOf("DNS", "TCP 3-Way Handshake", "TLS/SSL", "HTTP/HTTPS", "DOM Rendering")
        ),
        TechnicalQuestion(
            id = 5,
            subject = "Data Structures",
            topic = "Hashing",
            difficulty = Difficulty.INTERMEDIATE,
            question = "How does a Hash Table resolve collisions? Compare Separate Chaining and Open Addressing.",
            answer = "Collisions occur when two distinct keys hash to the same bucket index.\n1. Separate Chaining: Each bucket holds a linked list (or balanced Red-Black tree in Java 8+ HashMap). Colliding entries are appended to the bucket chain. Degrades to O(N) or O(log N) if all keys hash to the same bucket.\n2. Open Addressing: All elements stored directly in the hash table array. On collision, probe for the next empty cell:\n   - Linear Probing (hash + i): Prone to primary clustering.\n   - Quadratic Probing (hash + c1*i + c2*i^2): Reduces primary clustering.\n   - Double Hashing (hash1 + i * hash2): Best distribution.",
            keyConcepts = listOf("Hash Function", "Separate Chaining", "Open Addressing", "Linear Probing", "Load Factor")
        )
    )

    val sqlProblems: List<SqlProblem> = listOf(
        SqlProblem(
            id = 1,
            title = "Find Second Highest Salary",
            topic = "Subqueries & Aggregation",
            difficulty = Difficulty.MEDIUM,
            schemaDesc = "Employee (id INT, name VARCHAR, salary INT, department_id INT)",
            sampleTable = "Employee:\n+----+-------+--------+\n| id | name  | salary |\n+----+-------+--------+\n| 1  | Alice | 90000  |\n| 2  | Bob   | 80000  |\n| 3  | Carol | 80000  |\n| 4  | Dave  | 70000  |\n+----+-------+--------+",
            question = "Write an SQL query to report the second highest distinct salary from the Employee table. If there is no second highest salary, return NULL.",
            solutionQuery = "SELECT MAX(salary) AS SecondHighestSalary \nFROM Employee \nWHERE salary < (SELECT MAX(salary) FROM Employee);",
            explanation = "The inner query finds the absolute maximum salary. The outer query finds the maximum salary strictly less than the top salary, effectively giving the second highest."
        ),
        SqlProblem(
            id = 2,
            title = "Department Top Earners",
            topic = "JOIN & GROUP BY",
            difficulty = Difficulty.HARD,
            schemaDesc = "Employee (id, name, salary, departmentId)\nDepartment (id, name)",
            sampleTable = "Department:\n+----+-------+\n| id | name  |\n+----+-------+\n| 1  | IT    |\n| 2  | Sales |\n+----+-------+",
            question = "Write a query to find employees who have the highest salary in each of the departments.",
            solutionQuery = "SELECT d.name AS Department, e.name AS Employee, e.salary AS Salary\nFROM Employee e\nJOIN Department d ON e.departmentId = d.id\nWHERE (e.departmentId, e.salary) IN (\n    SELECT departmentId, MAX(salary)\n    FROM Employee\n    GROUP BY departmentId\n);",
            explanation = "We group by departmentId to find the maximum salary in each department, then use an IN clause on a tuple (departmentId, salary) to fetch matching employee rows."
        ),
        SqlProblem(
            id = 3,
            title = "Duplicate Emails",
            topic = "GROUP BY & HAVING",
            difficulty = Difficulty.EASY,
            schemaDesc = "Person (id INT, email VARCHAR)",
            sampleTable = "Person:\n+----+------------------+\n| id | email            |\n+----+------------------+\n| 1  | a@b.com          |\n| 2  | c@d.com          |\n| 3  | a@b.com          |\n+----+------------------+",
            question = "Write an SQL query to report all the duplicate emails.",
            solutionQuery = "SELECT email \nFROM Person \nGROUP BY email \nHAVING COUNT(email) > 1;",
            explanation = "GROUP BY groups identical email values, and the HAVING clause filters groups having a count strictly greater than 1."
        )
    )

    val placementDrives: List<PlacementDrive> = listOf(
        PlacementDrive(
            id = "drv_01",
            companyName = "Amazon",
            role = "Software Development Engineer (SDE-1)",
            packageLpa = 28.5,
            location = "Hyderabad / Bangalore",
            minCgpa = 7.5,
            maxBacklogs = 0,
            eligibleBranches = listOf("Computer Science & Engineering", "Information Technology", "Electronics & Communication"),
            requiredSkills = listOf("Data Structures", "Algorithms", "Java", "C++", "System Design"),
            graduationYear = 2026,
            deadline = "Oct 15, 2026",
            driveDate = "Oct 22, 2026",
            description = "Exciting opportunity to join AWS Core Services. Build resilient, scalable distributed backends processing millions of transactions per second."
        ),
        PlacementDrive(
            id = "drv_02",
            companyName = "TCS",
            role = "TCS Digital / Prime Developer",
            packageLpa = 9.0,
            location = "PAN India",
            minCgpa = 7.0,
            maxBacklogs = 0,
            eligibleBranches = listOf("Computer Science & Engineering", "Information Technology", "Electronics & Communication", "Electrical Engineering"),
            requiredSkills = listOf("Python", "Java", "SQL", "Cloud Basics", "Aptitude"),
            graduationYear = 2026,
            deadline = "Nov 05, 2026",
            driveDate = "Nov 12, 2026",
            description = "Specialized engineering roles working on NextGen AI, Cloud platforms, and Enterprise automation."
        ),
        PlacementDrive(
            id = "drv_03",
            companyName = "Accenture",
            role = "Advanced Application Engineering Analyst",
            packageLpa = 6.5,
            location = "Pune / Gurgaon / Chennai",
            minCgpa = 6.5,
            maxBacklogs = 1,
            eligibleBranches = listOf("All Engineering Branches"),
            requiredSkills = listOf("Java", "Python", "Full Stack", "Problem Solving"),
            graduationYear = 2026,
            deadline = "Nov 20, 2026",
            driveDate = "Nov 28, 2026",
            description = "Build intelligent enterprise software with microservices, automated CI/CD pipelines, and cloud native architectures."
        ),
        PlacementDrive(
            id = "drv_04",
            companyName = "Microsoft",
            role = "Software Engineer - Azure Core",
            packageLpa = 26.0,
            location = "Hyderabad / Bangalore",
            minCgpa = 8.0,
            maxBacklogs = 0,
            eligibleBranches = listOf("Computer Science & Engineering", "Information Technology"),
            requiredSkills = listOf("Data Structures", "Algorithms", "OS", "Concurrency", "C++", "C#"),
            graduationYear = 2026,
            deadline = "Dec 01, 2026",
            driveDate = "Dec 10, 2026",
            description = "Work on the backbone of Microsoft Azure cloud platform, hypervisor networking, and distributed computing fabrics."
        ),
        PlacementDrive(
            id = "drv_05",
            companyName = "Infosys",
            role = "Specialist Programmer (SP)",
            packageLpa = 9.5,
            location = "Mysore / Bangalore",
            minCgpa = 7.0,
            maxBacklogs = 0,
            eligibleBranches = listOf("Computer Science & Engineering", "Information Technology", "Electronics & Communication"),
            requiredSkills = listOf("Algorithms", "Dynamic Programming", "Python", "Java"),
            graduationYear = 2026,
            deadline = "Dec 15, 2026",
            driveDate = "Dec 22, 2026",
            description = "Elite high-code developer track solving challenging algorithmic problems and building critical client products."
        )
    )

    val mockInterviews: List<MockInterviewItem> = listOf(
        MockInterviewItem(
            id = 1,
            category = "HR / Self-Introduction",
            question = "Tell me about yourself and your journey in technology.",
            guidance = "Keep it structured: Past (education & discovery), Present (current projects & tech strengths), Future (why this role/company). Aim for 90-120 seconds.",
            idealFramework = "Present -> Past -> Future Framework. Highlight 1-2 major technical achievements and connect them to the role.",
            sampleAnswer = "Hi! I am Aditya Sharma, currently pursuing B.Tech in Computer Science at NIT with an 8.4 CGPA. Over the past three years, I've developed a deep passion for backend software development and algorithms. Recently, I architected a distributed campus placement companion app that processes mock tests and generates skill gap predictions using machine learning. Prior to that, I built multiple full-stack projects using Java and Python. I'm excited about this opportunity at your company because of your high-scale engineering culture and emphasis on building customer-first products."
        ),
        MockInterviewItem(
            id = 2,
            category = "Behavioral",
            question = "Describe a time when you faced a significant conflict or disagreement in a technical team project. How did you resolve it?",
            guidance = "Use the STAR technique (Situation, Task, Action, Result). Focus on objective criteria, listening, and maintaining professional focus on project success.",
            idealFramework = "STAR Method: Situation (the project), Task (the conflict), Action (what YOU did objectively to bridge the gap), Result (successful outcome).",
            sampleAnswer = "In our semester capstone project, our team had a split opinion between using PostgreSQL versus MongoDB for our database. Two teammates insisted on NoSQL for rapid prototyping, while I was concerned about data consistency and relational integrity for transactional records. Instead of arguing, I proposed a 2-day spike test: I benchmarked schema migration and relation queries for our specific use case and presented the measurable trade-offs. Seeing the concrete need for ACID compliance in our payment flow, the team aligned on PostgreSQL with full agreement, and we delivered on schedule with zero schema regressions."
        ),
        MockInterviewItem(
            id = 3,
            category = "HR / Motivation",
            question = "Why do you want to join our company specifically rather than our competitors?",
            guidance = "Show that you researched the company's tech stacks, recent announcements, engineering blogs, and culture values.",
            idealFramework = "Company Specifics + Personal Alignment + Mutual Growth.",
            sampleAnswer = "I've closely followed your engineering blogs on high-scale distributed caching and resilience under peak loads. What impresses me most is not just the scale, but your company culture of continuous learning and ownership even for junior engineers. My background in algorithms and proactive problem solving aligns well with your team's engineering standards, and I am eager to contribute directly to mission-critical systems while learning from senior architects."
        ),
        MockInterviewItem(
            id = 4,
            category = "Technical Scenario",
            question = "How would you handle a production service experiencing sudden high latency and memory spikes?",
            guidance = "Demonstrate systematic troubleshooting: Monitoring -> Isolation -> Mitigation -> Root Cause Analysis -> Prevention.",
            idealFramework = "Triage -> Mitigate -> Isolate -> RCA -> Post-Mortem.",
            sampleAnswer = "First, I'd check APM metrics (CPU, Memory, Garbage Collection pauses, active DB connections). If memory is climbing continuously, a memory leak or unclosed connection pool is likely. Immediate mitigation: failover traffic to healthy replicas or scale horizontally to protect availability. Next, capture thread and heap dumps for analysis. Once resolved, write a comprehensive post-mortem with actionable alerts and regression tests."
        )
    )

    val achievementBadges: List<AchievementBadge> = listOf(
        AchievementBadge("b1", "7-Day Streak", "Practiced aptitude or code for 7 consecutive days", "local_fire_department", true, 100),
        AchievementBadge("b2", "Centurion Solver", "Solved 100+ preparation questions across categories", "military_tech", false, 250),
        AchievementBadge("b3", "Algorithm Ace", "Submitted 25+ successful coding solutions", "code", true, 200),
        AchievementBadge("b4", "Mock Champion", "Scored 80%+ in a full placement mock assessment", "emoji_events", true, 150),
        AchievementBadge("b5", "SQL Maestro", "Completed all relational database query challenges", "storage", false, 120),
        AchievementBadge("b6", "Resume Polished", "Attained an ATS Resume score above 80/100", "description", true, 100)
    )
}

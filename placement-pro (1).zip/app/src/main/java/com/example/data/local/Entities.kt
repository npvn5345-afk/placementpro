package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "student_profile")
data class StudentProfileEntity(
    @PrimaryKey val id: String = "std_01",
    val fullName: String,
    val email: String,
    val phone: String,
    val college: String,
    val university: String,
    val degree: String,
    val branch: String,
    val graduationYear: Int,
    val cgpa: Double,
    val backlogs: Int,
    val skills: List<String>,
    val programmingLanguages: List<String>,
    val resumeSummary: String,
    val githubUrl: String,
    val linkedinUrl: String,
    val portfolioUrl: String,
    val targetCompanies: List<String>,
    val preparationLevel: String,
    val currentStreak: Int,
    val totalXP: Int,
    val testsCompleted: Int,
    val questionsSolved: Int,
    val codingProblemsSolved: Int,
    val mockInterviewsCompleted: Int,
    val isOnboarded: Boolean
)

@Entity(tableName = "placement_drives")
data class PlacementDriveEntity(
    @PrimaryKey val id: String,
    val companyName: String,
    val role: String,
    val packageLpa: Double,
    val location: String,
    val minCgpa: Double,
    val maxBacklogs: Int,
    val eligibleBranches: List<String>,
    val requiredSkills: List<String>,
    val graduationYear: Int,
    val deadline: String,
    val driveDate: String,
    val description: String,
    val stages: List<String>,
    val isOpen: Boolean
)

@Entity(tableName = "drive_applications")
data class DriveApplicationEntity(
    @PrimaryKey val id: String,
    val driveId: String,
    val studentId: String,
    val appliedDate: String,
    val stage: String,
    val notes: String
)

@Entity(tableName = "study_plan")
data class StudyPlanEntity(
    @PrimaryKey val dayNumber: Int,
    val dayTitle: String,
    val aptitudeTask: String,
    val codingTask: String,
    val technicalTask: String,
    val interviewTask: String,
    val estimatedMinutes: Int,
    val isCompleted: Boolean
)

@Entity(tableName = "user_progress")
data class UserProgressEntity(
    @PrimaryKey val key: String,
    val value: String
)

@Entity(tableName = "mock_interview_records")
data class MockInterviewRecordEntity(
    @PrimaryKey val id: String,
    val roleOrDomain: String,
    val targetCompany: String,
    val question: String,
    val studentAnswer: String,
    val overallScore: Int,
    val technicalScore: Int,
    val communicationScore: Int,
    val feedbackSummary: String,
    val isVoiceLiveSession: Boolean,
    val timestamp: Long
)

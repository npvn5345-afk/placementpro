package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PlacementDao {
    // Profile
    @Query("SELECT * FROM student_profile WHERE id = :id LIMIT 1")
    fun getStudentProfile(id: String = "std_01"): Flow<StudentProfileEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudentProfile(profile: StudentProfileEntity)

    @Update
    suspend fun updateStudentProfile(profile: StudentProfileEntity)

    // Drives
    @Query("SELECT * FROM placement_drives ORDER BY driveDate ASC")
    fun getAllDrives(): Flow<List<PlacementDriveEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDrives(drives: List<PlacementDriveEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDrive(drive: PlacementDriveEntity)

    @Query("DELETE FROM placement_drives WHERE id = :driveId")
    suspend fun deleteDrive(driveId: String)

    // Applications
    @Query("SELECT * FROM drive_applications")
    fun getAllApplications(): Flow<List<DriveApplicationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertApplication(app: DriveApplicationEntity)

    @Query("UPDATE drive_applications SET stage = :newStage WHERE id = :appId")
    suspend fun updateApplicationStage(appId: String, newStage: String)

    // Study Plan
    @Query("SELECT * FROM study_plan ORDER BY dayNumber ASC")
    fun getStudyPlan(): Flow<List<StudyPlanEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudyPlan(items: List<StudyPlanEntity>)

    @Query("UPDATE study_plan SET isCompleted = :completed WHERE dayNumber = :day")
    suspend fun toggleStudyPlanCompleted(day: Int, completed: Boolean)

    // Progress Key-Value (e.g. solved coding problems, answered aptitude questions)
    @Query("SELECT value FROM user_progress WHERE `key` = :key")
    suspend fun getProgressValue(key: String): String?

    @Query("SELECT * FROM user_progress")
    fun getAllProgress(): Flow<List<UserProgressEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setProgressValue(progress: UserProgressEntity)

    // Mock Interview Records
    @Query("SELECT * FROM mock_interview_records ORDER BY timestamp DESC")
    fun getAllMockInterviews(): Flow<List<MockInterviewRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMockInterview(record: MockInterviewRecordEntity)
}

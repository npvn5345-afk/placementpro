package com.example.data.model

enum class UserRole {
    USER,
    ADMIN
}

enum class AptitudeCategory {
    QUANTITATIVE,
    LOGICAL,
    VERBAL
}

enum class Difficulty {
    BEGINNER,
    EASY,
    MEDIUM,
    INTERMEDIATE,
    HARD
}

data class StudentProfile(
    val id: String = "std_01",
    val fullName: String = "Aditya Sharma",
    val email: String = "aditya.sharma@campus.edu",
    val phone: String = "+91 98765 43210",
    val college: String = "National Institute of Technology",
    val university: String = "State Technical University",
    val degree: String = "B.Tech",
    val branch: String = "Computer Science & Engineering",
    val graduationYear: Int = 2026,
    val cgpa: Double = 8.42,
    val backlogs: Int = 0,
    val skills: List<String> = listOf("Python", "Java", "Data Structures", "SQL", "DBMS", "Git"),
    val programmingLanguages: List<String> = listOf("Python", "Java", "C++"),
    val resumeSummary: String = "Aspiring Software Development Engineer with strong problem-solving foundations in Data Structures, Algorithms, and Full-Stack Engineering.",
    val githubUrl: String = "https://github.com/aditya-dev",
    val linkedinUrl: String = "https://linkedin.com/in/aditya-sharma",
    val portfolioUrl: String = "https://aditya.dev",
    val targetCompanies: List<String> = listOf("Amazon", "TCS", "Accenture", "Microsoft", "Infosys"),
    val preparationLevel: String = "Intermediate",
    val currentStreak: Int = 7,
    val totalXP: Int = 1450,
    val testsCompleted: Int = 12,
    val questionsSolved: Int = 86,
    val codingProblemsSolved: Int = 28,
    val mockInterviewsCompleted: Int = 4,
    val isOnboarded: Boolean = true
)

data class AptitudeQuestion(
    val id: Int,
    val category: AptitudeCategory,
    val subcategory: String,
    val difficulty: Difficulty,
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String,
    val formulaOrHint: String = ""
)

data class CodingProblem(
    val id: Int,
    val title: String,
    val topic: String,
    val difficulty: Difficulty,
    val description: String,
    val constraints: String,
    val inputFormat: String,
    val outputFormat: String,
    val sampleInput: String,
    val sampleOutput: String,
    val hints: List<String>,
    val solutionApproach: String,
    val starterPython: String,
    val starterJava: String,
    val starterCpp: String,
    val testCases: List<TestCase> = emptyList(),
    val isSolved: Boolean = false
)

data class TestCase(
    val input: String,
    val expectedOutput: String
)

data class TechnicalQuestion(
    val id: Int,
    val subject: String,
    val topic: String,
    val difficulty: Difficulty,
    val question: String,
    val answer: String,
    val keyConcepts: List<String>,
    val codeSnippet: String = "",
    val isBookmarked: Boolean = false
)

data class SqlProblem(
    val id: Int,
    val title: String,
    val topic: String,
    val difficulty: Difficulty,
    val schemaDesc: String,
    val sampleTable: String,
    val question: String,
    val solutionQuery: String,
    val explanation: String
)

data class Company(
    val id: String,
    val name: String,
    val industry: String,
    val description: String,
    val avgPackageLpa: Double,
    val highestPackageLpa: Double,
    val minCgpa: Double,
    val maxBacklogs: Int,
    val eligibleBranches: List<String>,
    val hiringRoles: List<String>,
    val requiredSkills: List<String>,
    val selectionRounds: List<String>,
    val aptitudePattern: String,
    val codingPattern: String,
    val technicalFocus: String,
    val hrFocus: String
)

enum class ApplicationStage {
    APPLIED,
    ELIGIBLE,
    SHORTLISTED,
    APTITUDE,
    TECHNICAL,
    INTERVIEW,
    SELECTED,
    REJECTED
}

data class PlacementDrive(
    val id: String,
    val companyName: String,
    val role: String,
    val packageLpa: Double,
    val location: String,
    val minCgpa: Double,
    val maxBacklogs: Int,
    val eligibleBranches: List<String>,
    val requiredSkills: List<String>,
    val graduationYear: Int,
    val deadline: String,
    val driveDate: String,
    val description: String,
    val stages: List<String> = listOf("Online Assessment", "Technical Interview 1", "Technical Interview 2", "HR Discussion"),
    val isOpen: Boolean = true
)

data class DriveApplication(
    val id: String,
    val driveId: String,
    val studentId: String,
    val appliedDate: String,
    val stage: ApplicationStage = ApplicationStage.APPLIED,
    val notes: String = ""
)

data class StudyPlanItem(
    val dayNumber: Int,
    val dayTitle: String,
    val aptitudeTask: String,
    val codingTask: String,
    val technicalTask: String,
    val interviewTask: String,
    val estimatedMinutes: Int = 120,
    val isCompleted: Boolean = false
)

data class MockInterviewItem(
    val id: Int,
    val category: String, // HR, Technical, Behavioral, Situational
    val question: String,
    val guidance: String,
    val idealFramework: String,
    val sampleAnswer: String
)

data class AchievementBadge(
    val id: String,
    val title: String,
    val description: String,
    val icon: String,
    val isUnlocked: Boolean,
    val xpReward: Int
)

data class ResumeScoreResult(
    val overallScore: Int,
    val matchedSkills: List<String>,
    val missingSkills: List<String>,
    val strengths: List<String>,
    val suggestions: List<String>,
    val roleRelevance: String
)

data class PlacementReadinessBreakdown(
    val overallScore: Int,
    val aptitudeScore: Int,
    val codingScore: Int,
    val technicalScore: Int,
    val communicationScore: Int,
    val interviewScore: Int,
    val resumeScore: Int,
    val strongAreas: List<String>,
    val weakAreas: List<String>,
    val nextRecommendations: List<String>
)

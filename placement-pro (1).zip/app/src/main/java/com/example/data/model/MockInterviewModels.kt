package com.example.data.model

enum class InterviewDomain(val title: String, val description: String) {
    DSA_ALGORITHMS("DSA & Algorithms", "Data structures, tree/graph traversal, dynamic programming & time/space complexity"),
    BACKEND_SYSTEMS("Backend & System Design", "Spring Boot, REST/gRPC APIs, microservices, database transactions & concurrency"),
    FULLSTACK_WEB("Full Stack & Web", "Modern state management, async workflows, API design, web security & DOM/Compose"),
    CORE_CS("Core CS Fundamentals", "DBMS indexing/normalization, OS threads/virtual memory & Computer Networks TCP/IP"),
    CLOUD_DEVOPS("Cloud & DevOps", "Docker containers, Kubernetes orchestration, CI/CD pipelines & cloud observability"),
    BEHAVIORAL_STAR("Behavioral & Leadership", "STAR framework (Situation, Task, Action, Result), conflict resolution & ownership")
}

enum class InterviewDifficulty(val label: String) {
    ENTRY_LEVEL("Campus / Fresher"),
    MID_LEVEL("Associate / SDE-1"),
    SENIOR_LEVEL("Specialist / SDE-2")
}

data class SimulatedInterviewQuestion(
    val id: String,
    val domain: InterviewDomain,
    val targetCompany: String,
    val difficulty: InterviewDifficulty,
    val questionTitle: String,
    val questionText: String,
    val contextScenario: String = "",
    val expectedKeyPoints: List<String> = emptyList(),
    val sampleFollowUp: String = ""
)

data class RealtimeInterviewEvaluation(
    val technicalScore: Int,      // 0-100
    val structureScore: Int,      // 0-100
    val clarityScore: Int,        // 0-100
    val overallScore: Int,        // 0-100
    val ratingLabel: String,      // "Strong Hire", "Hire", "Leaning Hire", "Needs Revision"
    val summaryFeedback: String,
    val strengths: List<String>,
    val areasForImprovement: List<String>,
    val idealAnswerSnippet: String,
    val suggestedFollowUp: String? = null
)

data class LiveTranscriptMessage(
    val id: String,
    val isUser: Boolean,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class MockInterviewSessionRecord(
    val id: String,
    val roleOrDomain: String,
    val targetCompany: String,
    val question: String,
    val studentAnswer: String,
    val overallScore: Int,
    val technicalScore: Int,
    val communicationScore: Int,
    val feedbackSummary: String,
    val isVoiceLiveSession: Boolean,
    val timestamp: Long
)

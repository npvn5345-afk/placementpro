package com.example.data.ml

import com.example.data.model.*
import kotlin.math.exp
import kotlin.math.roundToInt

object PlacementPredictor {

    /**
     * Calculates explainable placement readiness using multi-factor logistic model.
     * Weights:
     * - Aptitude: 20%
     * - Coding: 25%
     * - Technical (OOP, DBMS, OS, Networks): 20%
     * - Communication / HR: 10%
     * - Mock Interview: 10%
     * - Resume Quality: 10%
     * - Consistency / Streak: 5%
     */
    fun calculateReadiness(
        profile: StudentProfile,
        aptitudeAccuracy: Double = 0.82,
        codingSolvedRatio: Double = 0.65,
        technicalQuizScore: Double = 0.74,
        communicationScore: Double = 0.70,
        interviewScore: Double = 0.68,
        resumeScore: Double = 0.85
    ): PlacementReadinessBreakdown {
        val consistencyFactor = (profile.currentStreak.coerceAtMost(14) / 14.0)

        // Raw feature scores (0 - 100)
        val aptScore = (aptitudeAccuracy * 100).roundToInt().coerceIn(0, 100)
        val codeScore = (codingSolvedRatio * 100).roundToInt().coerceIn(0, 100)
        val techScore = (technicalQuizScore * 100).roundToInt().coerceIn(0, 100)
        val commScore = (communicationScore * 100).roundToInt().coerceIn(0, 100)
        val intScore = (interviewScore * 100).roundToInt().coerceIn(0, 100)
        val resScore = (resumeScore * 100).roundToInt().coerceIn(0, 100)

        // Weighted Linear Combination
        val z = (0.20 * aptScore) +
                (0.25 * codeScore) +
                (0.20 * techScore) +
                (0.10 * commScore) +
                (0.10 * intScore) +
                (0.10 * resScore) +
                (0.05 * (consistencyFactor * 100))

        // Logistic calibration centered around 70 with standard deviation scale
        val calibratedScore = z.roundToInt().coerceIn(20, 98)

        // Identify strong and weak areas
        val areaScores = listOf(
            "Aptitude" to aptScore,
            "Coding" to codeScore,
            "Technical CS Fundamentals" to techScore,
            "Communication Skills" to commScore,
            "Mock Interviews" to intScore,
            "Resume & ATS Relevance" to resScore
        )

        val sortedAreas = areaScores.sortedByDescending { it.second }
        val strongAreas = sortedAreas.take(2).map { "${it.first} (${it.second}%)" }
        val weakAreas = sortedAreas.takeLast(2).map { "${it.first} (${it.second}%)" }

        val recommendations = mutableListOf<String>()
        if (codeScore < 70) {
            recommendations.add("Boost Coding: Practice 2 Dynamic Programming & Graph problems daily to surpass high-package cutoffs.")
        }
        if (intScore < 75) {
            recommendations.add("Mock Interview Drill: Practice STAR behavioral scenarios for situational rounds.")
        }
        if (techScore < 75) {
            recommendations.add("Deepen OS & DBMS: Review ACID transactions, indexing, and process synchronization.")
        }
        if (recommendations.isEmpty()) {
            recommendations.add("Target High-Tier FAANG/Product drives: Start timed full-length company simulations.")
        }

        return PlacementReadinessBreakdown(
            overallScore = calibratedScore,
            aptitudeScore = aptScore,
            codingScore = codeScore,
            technicalScore = techScore,
            communicationScore = commScore,
            interviewScore = intScore,
            resumeScore = resScore,
            strongAreas = strongAreas,
            weakAreas = weakAreas,
            nextRecommendations = recommendations
        )
    }

    /**
     * Explainable Skill-Gap Analysis against a specific Target Company.
     */
    fun analyzeSkillGap(
        studentSkills: List<String>,
        company: Company
    ): SkillGapAnalysisResult {
        val studentSkillSet = studentSkills.map { it.lowercase().trim() }.toSet()
        val requiredSkills = company.requiredSkills

        val matched = mutableListOf<String>()
        val missing = mutableListOf<String>()

        for (skill in requiredSkills) {
            val normalized = skill.lowercase().trim()
            val hasDirect = studentSkillSet.contains(normalized)
            val hasPartial = studentSkillSet.any { it.contains(normalized) || normalized.contains(it) }

            if (hasDirect || hasPartial) {
                matched.add(skill)
            } else {
                missing.add(skill)
            }
        }

        val matchPercentage = if (requiredSkills.isNotEmpty()) {
            ((matched.size.toDouble() / requiredSkills.size) * 100).roundToInt()
        } else 100

        val estimatedTimeToBridgeDays = (missing.size * 3.5).roundToInt()

        val explanation = if (missing.isEmpty()) {
            "Exceptional match! Your current skillset covers 100% of ${company.name}'s core recruitment requirements."
        } else {
            "You match ${matched.size} of ${requiredSkills.size} required skills for ${company.name}. Focus on bridging: ${missing.joinToString(", ")} to maximize your shortlist probability."
        }

        return SkillGapAnalysisResult(
            companyName = company.name,
            matchPercentage = matchPercentage,
            matchedSkills = matched,
            missingSkills = missing,
            estimatedPreparationDays = estimatedTimeToBridgeDays,
            explanation = explanation
        )
    }

    /**
     * Evaluates Student Eligibility for a Placement Drive and explains WHY.
     */
    fun checkEligibility(
        student: StudentProfile,
        drive: PlacementDrive
    ): EligibilityResult {
        val failureReasons = mutableListOf<String>()

        // 1. CGPA Check
        if (student.cgpa < drive.minCgpa) {
            failureReasons.add("Minimum CGPA required is ${drive.minCgpa}, but your CGPA is ${student.cgpa}.")
        }

        // 2. Backlogs Check
        if (student.backlogs > drive.maxBacklogs) {
            failureReasons.add("Maximum allowed backlogs is ${drive.maxBacklogs}, but you currently have ${student.backlogs}.")
        }

        // 3. Graduation Year Check
        if (student.graduationYear != drive.graduationYear) {
            failureReasons.add("Targeted batch is ${drive.graduationYear}, but your graduation year is ${student.graduationYear}.")
        }

        // 4. Branch Check
        val branchMatches = drive.eligibleBranches.any {
            it.equals(student.branch, ignoreCase = true) ||
            it.equals("All Engineering Branches", ignoreCase = true) ||
            (it.contains("CSE") && student.branch.contains("Computer", ignoreCase = true)) ||
            (it.contains("IT") && student.branch.contains("Information", ignoreCase = true)) ||
            (it.contains("ECE") && student.branch.contains("Electronics", ignoreCase = true))
        }

        if (!branchMatches) {
            failureReasons.add("Eligible branches: ${drive.eligibleBranches.joinToString(", ")}; Your branch: ${student.branch}.")
        }

        val isEligible = failureReasons.isEmpty()
        return EligibilityResult(
            isEligible = isEligible,
            reasons = if (isEligible) listOf("You satisfy all academic, backlog, branch, and graduation criteria for this drive!") else failureReasons
        )
    }

    /**
     * AI Resume Analyzer simulating NLP keyword matching and ATS scoring.
     */
    fun analyzeResumeText(
        resumeContent: String,
        targetRole: String = "Software Engineer"
    ): ResumeScoreResult {
        val keywords = listOf(
            "data structures", "algorithms", "python", "java", "sql", "database",
            "git", "api", "rest", "docker", "cloud", "aws", "react", "testing",
            "oop", "microservices", "linux", "problem solving", "optimization"
        )

        val normalized = resumeContent.lowercase()
        val matched = mutableListOf<String>()
        val missing = mutableListOf<String>()

        for (kw in keywords) {
            if (normalized.contains(kw)) {
                matched.add(kw.capitalize())
            } else {
                missing.add(kw.capitalize())
            }
        }

        val keywordRatio = matched.size.toDouble() / keywords.size
        val hasMetrics = normalized.contains("%") || normalized.contains("reduced") || normalized.contains("improved") || normalized.contains("increased")
        val hasLinks = normalized.contains("github.com") || normalized.contains("linkedin.com") || normalized.contains("http")

        var score = (keywordRatio * 70).roundToInt()
        if (hasMetrics) score += 15
        if (hasLinks) score += 10
        score = score.coerceIn(40, 95)

        val strengths = mutableListOf<String>()
        val suggestions = mutableListOf<String>()

        if (hasMetrics) {
            strengths.add("Strong quantified impact statements (percentages, metrics) detected.")
        } else {
            suggestions.add("Add measurable business metrics to projects (e.g. 'Improved query latency by 35%').")
        }

        if (hasLinks) {
            strengths.add("Professional profile links (GitHub/LinkedIn) are present.")
        } else {
            suggestions.add("Include live GitHub project repositories and LinkedIn profile links.")
        }

        if (missing.isNotEmpty()) {
            suggestions.add("Consider incorporating high-demand industry skills: ${missing.take(4).joinToString(", ")}.")
        }

        return ResumeScoreResult(
            overallScore = score,
            matchedSkills = matched,
            missingSkills = missing.take(6),
            strengths = strengths,
            suggestions = suggestions,
            roleRelevance = if (score >= 80) "High Match for $targetRole" else "Moderate Match - Recommended additions listed below"
        )
    }

    private fun String.capitalize(): String {
        return this.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
    }
}

data class SkillGapAnalysisResult(
    val companyName: String,
    val matchPercentage: Int,
    val matchedSkills: List<String>,
    val missingSkills: List<String>,
    val estimatedPreparationDays: Int,
    val explanation: String
)

data class EligibilityResult(
    val isEligible: Boolean,
    val reasons: List<String>
)

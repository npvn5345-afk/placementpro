package com.example.data.repository

import com.example.data.local.*
import com.example.data.model.*
import com.example.data.seed.PlacementSeedData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class PlacementRepository(private val dao: PlacementDao) {

    suspend fun initializeSeedDataIfNeeded() = withContext(Dispatchers.IO) {
        val existingProfile = dao.getStudentProfile().firstOrNull()
        if (existingProfile == null) {
            val p = PlacementSeedData.defaultProfile
            dao.insertStudentProfile(
                StudentProfileEntity(
                    id = p.id,
                    fullName = p.fullName,
                    email = p.email,
                    phone = p.phone,
                    college = p.college,
                    university = p.university,
                    degree = p.degree,
                    branch = p.branch,
                    graduationYear = p.graduationYear,
                    cgpa = p.cgpa,
                    backlogs = p.backlogs,
                    skills = p.skills,
                    programmingLanguages = p.programmingLanguages,
                    resumeSummary = p.resumeSummary,
                    githubUrl = p.githubUrl,
                    linkedinUrl = p.linkedinUrl,
                    portfolioUrl = p.portfolioUrl,
                    targetCompanies = p.targetCompanies,
                    preparationLevel = p.preparationLevel,
                    currentStreak = p.currentStreak,
                    totalXP = p.totalXP,
                    testsCompleted = p.testsCompleted,
                    questionsSolved = p.questionsSolved,
                    codingProblemsSolved = p.codingProblemsSolved,
                    mockInterviewsCompleted = p.mockInterviewsCompleted,
                    isOnboarded = p.isOnboarded
                )
            )
        }

        val existingDrives = dao.getAllDrives().firstOrNull()
        if (existingDrives.isNullOrEmpty()) {
            val driveEntities = PlacementSeedData.placementDrives.map { d ->
                PlacementDriveEntity(
                    id = d.id,
                    companyName = d.companyName,
                    role = d.role,
                    packageLpa = d.packageLpa,
                    location = d.location,
                    minCgpa = d.minCgpa,
                    maxBacklogs = d.maxBacklogs,
                    eligibleBranches = d.eligibleBranches,
                    requiredSkills = d.requiredSkills,
                    graduationYear = d.graduationYear,
                    deadline = d.deadline,
                    driveDate = d.driveDate,
                    description = d.description,
                    stages = d.stages,
                    isOpen = d.isOpen
                )
            }
            dao.insertDrives(driveEntities)

            // Seed initial application
            dao.insertApplication(
                DriveApplicationEntity(
                    id = "app_init_01",
                    driveId = "drv_01",
                    studentId = "std_01",
                    appliedDate = "Yesterday",
                    stage = ApplicationStage.SHORTLISTED.name,
                    notes = "Shortlisted for Round 1 Online Coding Assessment"
                )
            )
        }

        val existingPlan = dao.getStudyPlan().firstOrNull()
        if (existingPlan.isNullOrEmpty()) {
            generateDefaultStudyPlan("Amazon")
        }
    }

    val studentProfile: Flow<StudentProfile> = dao.getStudentProfile().map { entity ->
        if (entity == null) {
            PlacementSeedData.defaultProfile
        } else {
            StudentProfile(
                id = entity.id,
                fullName = entity.fullName,
                email = entity.email,
                phone = entity.phone,
                college = entity.college,
                university = entity.university,
                degree = entity.degree,
                branch = entity.branch,
                graduationYear = entity.graduationYear,
                cgpa = entity.cgpa,
                backlogs = entity.backlogs,
                skills = entity.skills,
                programmingLanguages = entity.programmingLanguages,
                resumeSummary = entity.resumeSummary,
                githubUrl = entity.githubUrl,
                linkedinUrl = entity.linkedinUrl,
                portfolioUrl = entity.portfolioUrl,
                targetCompanies = entity.targetCompanies,
                preparationLevel = entity.preparationLevel,
                currentStreak = entity.currentStreak,
                totalXP = entity.totalXP,
                testsCompleted = entity.testsCompleted,
                questionsSolved = entity.questionsSolved,
                codingProblemsSolved = entity.codingProblemsSolved,
                mockInterviewsCompleted = entity.mockInterviewsCompleted,
                isOnboarded = entity.isOnboarded
            )
        }
    }

    suspend fun updateStudentProfile(profile: StudentProfile) = withContext(Dispatchers.IO) {
        dao.insertStudentProfile(
            StudentProfileEntity(
                id = profile.id,
                fullName = profile.fullName,
                email = profile.email,
                phone = profile.phone,
                college = profile.college,
                university = profile.university,
                degree = profile.degree,
                branch = profile.branch,
                graduationYear = profile.graduationYear,
                cgpa = profile.cgpa,
                backlogs = profile.backlogs,
                skills = profile.skills,
                programmingLanguages = profile.programmingLanguages,
                resumeSummary = profile.resumeSummary,
                githubUrl = profile.githubUrl,
                linkedinUrl = profile.linkedinUrl,
                portfolioUrl = profile.portfolioUrl,
                targetCompanies = profile.targetCompanies,
                preparationLevel = profile.preparationLevel,
                currentStreak = profile.currentStreak,
                totalXP = profile.totalXP,
                testsCompleted = profile.testsCompleted,
                questionsSolved = profile.questionsSolved,
                codingProblemsSolved = profile.codingProblemsSolved,
                mockInterviewsCompleted = profile.mockInterviewsCompleted,
                isOnboarded = profile.isOnboarded
            )
        )
    }

    val placementDrives: Flow<List<PlacementDrive>> = dao.getAllDrives().map { list ->
        list.map { d ->
            PlacementDrive(
                id = d.id,
                companyName = d.companyName,
                role = d.role,
                packageLpa = d.packageLpa,
                location = d.location,
                minCgpa = d.minCgpa,
                maxBacklogs = d.maxBacklogs,
                eligibleBranches = d.eligibleBranches,
                requiredSkills = d.requiredSkills,
                graduationYear = d.graduationYear,
                deadline = d.deadline,
                driveDate = d.driveDate,
                description = d.description,
                stages = d.stages,
                isOpen = d.isOpen
            )
        }
    }

    suspend fun addPlacementDrive(drive: PlacementDrive) = withContext(Dispatchers.IO) {
        dao.insertDrive(
            PlacementDriveEntity(
                id = drive.id,
                companyName = drive.companyName,
                role = drive.role,
                packageLpa = drive.packageLpa,
                location = drive.location,
                minCgpa = drive.minCgpa,
                maxBacklogs = drive.maxBacklogs,
                eligibleBranches = drive.eligibleBranches,
                requiredSkills = drive.requiredSkills,
                graduationYear = drive.graduationYear,
                deadline = drive.deadline,
                driveDate = drive.driveDate,
                description = drive.description,
                stages = drive.stages,
                isOpen = drive.isOpen
            )
        )
    }

    val applications: Flow<List<DriveApplication>> = dao.getAllApplications().map { list ->
        list.map { a ->
            DriveApplication(
                id = a.id,
                driveId = a.driveId,
                studentId = a.studentId,
                appliedDate = a.appliedDate,
                stage = runCatching { ApplicationStage.valueOf(a.stage) }.getOrDefault(ApplicationStage.APPLIED),
                notes = a.notes
            )
        }
    }

    suspend fun applyForDrive(driveId: String, studentId: String = "std_01") = withContext(Dispatchers.IO) {
        val app = DriveApplicationEntity(
            id = "app_${System.currentTimeMillis()}",
            driveId = driveId,
            studentId = studentId,
            appliedDate = "Today",
            stage = ApplicationStage.APPLIED.name,
            notes = "Application submitted via Placement Pro."
        )
        dao.insertApplication(app)
    }

    suspend fun updateApplicationStage(appId: String, stage: ApplicationStage) = withContext(Dispatchers.IO) {
        dao.updateApplicationStage(appId, stage.name)
    }

    suspend fun deletePlacementDrive(driveId: String) = withContext(Dispatchers.IO) {
        dao.deleteDrive(driveId)
    }

    val studyPlan: Flow<List<StudyPlanItem>> = dao.getStudyPlan().map { list ->
        list.map { s ->
            StudyPlanItem(
                dayNumber = s.dayNumber,
                dayTitle = s.dayTitle,
                aptitudeTask = s.aptitudeTask,
                codingTask = s.codingTask,
                technicalTask = s.technicalTask,
                interviewTask = s.interviewTask,
                estimatedMinutes = s.estimatedMinutes,
                isCompleted = s.isCompleted
            )
        }
    }

    suspend fun toggleStudyPlanCompleted(day: Int, completed: Boolean) = withContext(Dispatchers.IO) {
        dao.toggleStudyPlanCompleted(day, completed)
    }

    suspend fun generateDefaultStudyPlan(targetCompany: String) = withContext(Dispatchers.IO) {
        val days = listOf(
            StudyPlanEntity(
                dayNumber = 1,
                dayTitle = "Day 1: Foundations & Percentages",
                aptitudeTask = "Percentages & Profit/Loss (30 mins - 15 Qs)",
                codingTask = "Two Pointers: Two Sum & Palindrome (45 mins)",
                technicalTask = "OOP 4 Pillars & Method Overloading vs Overriding (30 mins)",
                interviewTask = "Tell me about yourself (90s elevator pitch)",
                estimatedMinutes = 120,
                isCompleted = true
            ),
            StudyPlanEntity(
                dayNumber = 2,
                dayTitle = "Day 2: Speed, Time & Sliding Window",
                aptitudeTask = "Time, Speed & Distance / Trains (30 mins)",
                codingTask = "Sliding Window: Longest Substring Without Repeating (45 mins)",
                technicalTask = "DBMS ACID Properties & Normalization Forms (30 mins)",
                interviewTask = "Strengths & Weaknesses with work examples (20 mins)",
                estimatedMinutes = 125,
                isCompleted = true
            ),
            StudyPlanEntity(
                dayNumber = 3,
                dayTitle = "Day 3: Arrays & Kadane's Algorithm",
                aptitudeTask = "Time & Work / Pipes & Cisterns (30 mins)",
                codingTask = "Dynamic Programming: Maximum Subarray Kadane (45 mins)",
                technicalTask = "Operating Systems: Process vs Thread, Context Switch (30 mins)",
                interviewTask = "Why do you want to join $targetCompany? (20 mins)",
                estimatedMinutes = 125,
                isCompleted = false
            ),
            StudyPlanEntity(
                dayNumber = 4,
                dayTitle = "Day 4: Linked Lists & SQL Joins",
                aptitudeTask = "Simple & Compound Interest differences (30 mins)",
                codingTask = "Linked List: Reverse Singly Linked List (45 mins)",
                technicalTask = "SQL: INNER vs LEFT vs RIGHT JOINs with group by (30 mins)",
                interviewTask = "STAR Story: Conflict resolution in a team (20 mins)",
                estimatedMinutes = 125,
                isCompleted = false
            ),
            StudyPlanEntity(
                dayNumber = 5,
                dayTitle = "Day 5: Logical Deductions & Stacks",
                aptitudeTask = "Syllogisms & Blood Relations (30 mins)",
                codingTask = "Stack: Valid Parentheses & Min Stack (45 mins)",
                technicalTask = "Computer Networks: TCP 3-Way Handshake vs UDP (30 mins)",
                interviewTask = "Describe a challenging bug you fixed (20 mins)",
                estimatedMinutes = 125,
                isCompleted = false
            ),
            StudyPlanEntity(
                dayNumber = 6,
                dayTitle = "Day 6: Trees & System Basics",
                aptitudeTask = "Data Interpretation (Bar Graphs, Pie Charts) (30 mins)",
                codingTask = "Binary Tree Inorder, Preorder, Postorder traversals (45 mins)",
                technicalTask = "OS: Deadlock Coffman conditions & Banker's Algorithm (30 mins)",
                interviewTask = "How do you prioritize deadlines under pressure? (20 mins)",
                estimatedMinutes = 125,
                isCompleted = false
            ),
            StudyPlanEntity(
                dayNumber = 7,
                dayTitle = "Day 7: Full Company Mock Assessment",
                aptitudeTask = "Timed 30-Question Aptitude Speed Drill (40 mins)",
                codingTask = "Timed 2-Problem Coding Assessment ($targetCompany pattern) (50 mins)",
                technicalTask = "Mock Technical Interview Mode quiz (30 mins)",
                interviewTask = "Full HR Mock Simulation & Resume Walkthrough (30 mins)",
                estimatedMinutes = 150,
                isCompleted = false
            )
        )
        dao.insertStudyPlan(days)
    }

    // Mock Interview Sessions
    fun getMockInterviewRecords(): Flow<List<MockInterviewSessionRecord>> {
        return dao.getAllMockInterviews().map { list ->
            list.map { e ->
                MockInterviewSessionRecord(
                    id = e.id,
                    roleOrDomain = e.roleOrDomain,
                    targetCompany = e.targetCompany,
                    question = e.question,
                    studentAnswer = e.studentAnswer,
                    overallScore = e.overallScore,
                    technicalScore = e.technicalScore,
                    communicationScore = e.communicationScore,
                    feedbackSummary = e.feedbackSummary,
                    isVoiceLiveSession = e.isVoiceLiveSession,
                    timestamp = e.timestamp
                )
            }
        }
    }

    suspend fun saveMockInterviewRecord(record: MockInterviewSessionRecord) = withContext(Dispatchers.IO) {
        dao.insertMockInterview(
            MockInterviewRecordEntity(
                id = record.id,
                roleOrDomain = record.roleOrDomain,
                targetCompany = record.targetCompany,
                question = record.question,
                studentAnswer = record.studentAnswer,
                overallScore = record.overallScore,
                technicalScore = record.technicalScore,
                communicationScore = record.communicationScore,
                feedbackSummary = record.feedbackSummary,
                isVoiceLiveSession = record.isVoiceLiveSession,
                timestamp = record.timestamp
            )
        )
    }
}

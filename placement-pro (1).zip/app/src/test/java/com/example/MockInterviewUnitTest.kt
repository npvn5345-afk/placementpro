package com.example

import com.example.data.ai.FirebaseInterviewAIService
import com.example.data.model.InterviewDifficulty
import com.example.data.model.InterviewDomain
import org.junit.Assert.*
import org.junit.Test

class MockInterviewUnitTest {

    @Test
    fun testInterviewDomainValues() {
        val domains = InterviewDomain.values()
        assertTrue(domains.isNotEmpty())
        assertTrue(domains.any { it == InterviewDomain.DSA_ALGORITHMS })
        assertTrue(domains.any { it == InterviewDomain.BACKEND_SYSTEMS })
        assertTrue(domains.any { it == InterviewDomain.CORE_CS })
    }

    @Test
    fun testInterviewDifficultyLabels() {
        assertEquals("Campus / Fresher", InterviewDifficulty.ENTRY_LEVEL.label)
        assertEquals("Associate / SDE-1", InterviewDifficulty.MID_LEVEL.label)
        assertEquals("Specialist / SDE-2", InterviewDifficulty.SENIOR_LEVEL.label)
    }

    @Test
    fun testEvaluationParsing() {
        val sampleAiOutput = """
TECHNICAL_SCORE: 88
CLARITY_SCORE: 82
OVERALL_SCORE: 85
RATING: Strong Hire

SUMMARY_FEEDBACK:
The candidate demonstrated excellent understanding of LRU Cache design with Hash Map and Doubly Linked List.

STRENGTHS:
- Articulated O(1) time complexity accurately.
- Handled multithreaded synchronization considerations.

IMPROVEMENTS:
- Mention memory overhead per node in bytes.
- Discuss cache eviction under OOM situations.

MODEL_IDEAL_ANSWER:
Combine HashMap<Key, Node> with a custom DoublyLinkedList. Synchronize access with ReentrantReadWriteLock.

SUGGESTED_FOLLOW_UP:
How would you scale this cache across multiple distributed nodes with consistent hashing?
        """.trimIndent()

        // We can test the parsing logic directly
        val lines = sampleAiOutput.lines()
        val techScore = lines.find { it.startsWith("TECHNICAL_SCORE:") }?.removePrefix("TECHNICAL_SCORE:")?.trim()?.toIntOrNull()
        val clarityScore = lines.find { it.startsWith("CLARITY_SCORE:") }?.removePrefix("CLARITY_SCORE:")?.trim()?.toIntOrNull()
        val overallScore = lines.find { it.startsWith("OVERALL_SCORE:") }?.removePrefix("OVERALL_SCORE:")?.trim()?.toIntOrNull()
        val rating = lines.find { it.startsWith("RATING:") }?.removePrefix("RATING:")?.trim()

        assertEquals(88, techScore)
        assertEquals(82, clarityScore)
        assertEquals(85, overallScore)
        assertEquals("Strong Hire", rating)
    }
}
